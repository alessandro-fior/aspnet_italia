﻿using System;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Capitolo14.Filters
{
    public class Time2Attribute : Attribute, IFilterFactory
    {
        public int Hour { get; set; }

        public IFilterMetadata CreateInstance(IServiceProvider serviceProvider)
        {
            //IMyService service = serviceProvider.GetRequiredService<IMyService>();
            return new TimeFilter(Hour);
        }

        public bool IsReusable => false;
    }
}