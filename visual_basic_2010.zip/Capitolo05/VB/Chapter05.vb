﻿Imports System.IO

Namespace ASPItalia.Books.Chapter05
    Module Chapter05

        Sub Main()

            ' ****************************************************************************************************
            ' Esempio 5.1
            ' ****************************************************************************************************
            Dim myIntArray() As Integer = {1, 5, 2, 3, 6}

            Dim anotherArray(5) As Integer
            anotherArray(3) = 2

            Dim length = myIntArray.Length    'Recupera il numero di elementi

            Dim index =
              Array.IndexOf(myIntArray, 2)    'Indice di un elemento

            Dim item = myIntArray(3)          'Ritorna il quarto elemento

            Array.Sort(myIntArray)            'Ordina gli elementi

            Array.Resize(myIntArray, 7)       'Modifica il numero di elementi
            myIntArray(6) = 11


            ' ****************************************************************************************************
            ' Esempio 5.2
            ' ****************************************************************************************************
            Dim sample As New ArrayList()      'Creazione di un arraylist
            sample.Add(2)                      'Aggiunta di elementi
            sample.AddRange({1, 4})

            Dim value = sample(1)              'Ritorna il secondo elemento

            Dim count As Integer =
              sample.Count                     'Recupera il numero di elementi

            sample.Remove(2)                   'Rimuove l'intero 2
            sample.Clear()                     'Rimuove tutti gli elementi


            ' ****************************************************************************************************
            ' Esempio 5.3
            ' ****************************************************************************************************
            For index = 0 To sample.Count - 1
                Console.WriteLine(sample(index))
            Next

            For Each element In sample
                Console.WriteLine(element)
            Next


            ' ****************************************************************************************************
            ' Esempio 5.4
            ' ****************************************************************************************************
            Dim myDictionary As New Hashtable()       'Creazione dell'HashTable

            myDictionary.Add("someIntValue", 5)       'Aggiunta di elementi
            myDictionary.Add("someClass", New StringWriter())
            myDictionary.Add(DateTime.Today, "Today's string")

            Dim dictValue = myDictionary("someClass") 'Recupera elemento dalla chiave

            myDictionary.Remove("someClass")          'Rimuove un elemento

            count = myDictionary.Count                'Recupera il numero di elementi
            myDictionary.Clear()                      'Rimuove tutti gli elementi


            ' ****************************************************************************************************
            ' Esempio 5.5
            ' ****************************************************************************************************
            'Enumerazione di tutte le coppie chiave-valore
            For Each dictItem As DictionaryEntry In myDictionary
                Console.WriteLine(dictItem.Key + " " + dictItem.Value)
            Next

            'Enumerazione di tutte le chiavi
            For Each key In myDictionary.Keys
                Console.WriteLine(key)
            Next

            'Enumerazione di tutti i valori
            For Each value In myDictionary.Values
                Console.WriteLine(value)
            Next


            ' ****************************************************************************************************
            ' Esempio 5.6
            ' ****************************************************************************************************
            Console.WriteLine("---Stack---")
            Dim myStack As New Stack()
            myStack.Push("Marco")
            myStack.Push(5)
            myStack.Push(New Object())

            Console.WriteLine(myStack.Pop)
            Console.WriteLine(myStack.Pop)

            Console.WriteLine("---Queue---")
            Dim myQueue As New Queue
            myQueue.Enqueue("Marco")
            myQueue.Enqueue(5)
            myQueue.Enqueue(New Object())

            Console.WriteLine(myQueue.Dequeue)
            Console.WriteLine(myQueue.Dequeue)


            ' ****************************************************************************************************
            ' Esempio 5.7
            ' ****************************************************************************************************
            Dim dateList As New ArrayList
            dateList.Add(DateTime.Now)
            dateList.Add(New DateTime(2000, 1, 10))
            dateList.Add(DateTime.Today.AddYears(-1))

            Dim firstItem =
              DirectCast(dateList(0), DateTime)


            ' ****************************************************************************************************
            ' Esempio 5.8
            ' ****************************************************************************************************
            Dim list As New ArrayList

            list.Add(10)
            list.Add("Some string")
            list.Add(DateTime.Now)
            list.Add(New ArrayList())
            list.Add(New System.Globalization.CultureInfo("en-US"))

            'Il codice seguente solleva una InvalidCastException
            'Dim secondItem As DateTime =
            '  DirectCast(list(1), DateTime)

            ' ****************************************************************************************************
            ' Esempio 5.9
            ' ****************************************************************************************************
            Dim strings As New List(Of String)    'Inizializzazione di List(Of T)
            strings.Add("Marco De Sanctis")       'Possiamo aggiungere solo String
            strings.Add("Visual Basic 10.0")
            strings.Insert(0, "Primo elemento")

            index =
              strings.IndexOf("Marco De Sanctis") 'Ritorna 1

            Dim mySubstring =
              strings(0).Substring(5)             'Già String: cast non necessario


            ' ****************************************************************************************************
            ' Esempio 5.10
            ' ****************************************************************************************************
            Dim feste As New Dictionary(Of String, DateTime)

            feste.Add("Natale", New DateTime(2010, 12, 25))
            feste.Add("Capodanno", New DateTime(2010, 1, 1))
            feste.Add("Compleanno", New DateTime(2010, 7, 10))

            Dim vigiliaCompleanno = feste("Compleanno").AddDays(-1)

            Dim data As DateTime
            If feste.ContainsKey("chiave") Then
                data = feste("chiave")
            Else
                Console.WriteLine("La data cercata non esiste")
            End If

            If Not feste.TryGetValue("chiave", data) Then
                Console.WriteLine("La data cercata non esiste")
            End If


            ' ****************************************************************************************************
            ' Esempio 5.11
            ' ****************************************************************************************************
            Dim holidays As New HashSet(Of DateTime)
            Dim ferieEstive As New List(Of DateTime)

            holidays.Add(New DateTime(2010, 12, 25))
            holidays.Add(New DateTime(2010, 1, 1))
            holidays.Add(New DateTime(2010, 5, 1))
            holidays.UnionWith(ferieEstive)

            Dim someDate = New DateTime(2010, 11, 1)
            Dim willWork =
              holidays.Contains(someDate)

            ' ****************************************************************************************************
            ' Esempio 5.13
            ' ****************************************************************************************************
            Dim a As Integer = 5
            Dim b As Integer = 8

            Utils.Swap(a, b)  ' invece di Utils.Swap(Of Integer)(a, b)


            ' ****************************************************************************************************
            ' Esempio 5.15
            ' ****************************************************************************************************
            Dim int As Integer = Nothing
            Dim nullableInt As Nullable(Of Integer) = Nothing

            Console.WriteLine(int)            ' Stampa 0
            Console.WriteLine(nullableInt)    ' Stampa una riga vuota

            int = 5
            nullableInt = 7                   ' Assegnazione di un valore intero

            Dim res = int + nullableInt       ' res è di tipo Nullable(Of Integer)

            If nullableInt.HasValue Then      ' Verifica presenza di un valore
                Dim theValue = nullableInt.Value   ' Contiene il valore Integer
            End If

        End Sub

    End Module
End Namespace