﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Capitolo6.Scenarios
{
    public static class Scenario7
    {
        /// <summary>
        /// Esempio 6.8
        /// </summary>
        public static void Run()
        {
            var myEcho = new SampleDelegate(VeryLongEchoFunction);
            var results = new List<IAsyncResult>();
            results.Add(myEcho.BeginInvoke("Marco", null, null));
            results.Add(myEcho.BeginInvoke("Daniele", null, null));
            results.Add(myEcho.BeginInvoke("Riccardo", null, null));

            // Recupero dei risultati e stampa sulla console.
            foreach (IAsyncResult result in results)
            {
                Console.WriteLine(myEcho.EndInvoke(result));
            }
        }

        delegate string SampleDelegate(string input);

        public static string VeryLongEchoFunction(string input)
        {
            Thread.Sleep(3000);
            return "Hello " + input;
        }
    }
}