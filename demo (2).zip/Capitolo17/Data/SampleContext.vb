﻿
Imports System.ComponentModel.DataAnnotations
Imports System.Data.Entity

Public Class SampleContext
    Inherits DbContext
    Public Property Customers() As DbSet(Of Customer)
        Get
            Return m_Customers
        End Get
        Set
            m_Customers = Value
        End Set
    End Property
    Private m_Customers As DbSet(Of Customer)
End Class

Public Class Customer
    Public Property Id() As Integer
        Get
            Return m_Id
        End Get
        Set
            m_Id = Value
        End Set
    End Property
    Private m_Id As Integer

    <Required>
    <MaxLength(200)>
    Public Property FirstName() As String
        Get
            Return m_FirstName
        End Get
        Set
            m_FirstName = Value
        End Set
    End Property
    Private m_FirstName As String

    <Required>
    <MaxLength(200)>
    Public Property LastName() As String
        Get
            Return m_LastName
        End Get
        Set
            m_LastName = Value
        End Set
    End Property
    Private m_LastName As String
End Class

