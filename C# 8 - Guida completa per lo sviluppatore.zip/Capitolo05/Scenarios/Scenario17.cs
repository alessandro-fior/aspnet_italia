﻿using System;

namespace Capitolo5.Scenarios
{
    public static class Scenario17
    {
        /// <summary>
        /// Esempio 5.26
        /// </summary>
        public static void Run()
        {
            var peopleArray = new string[]
            {
                "Daniele Bochicchio",
                "Stefano Mostarda",
                "Matteo Tumiati",
                "Cristian Civera"
            };

            Span<string> span = new Span<string>(peopleArray);

            for (var i = 0; i < peopleArray.Length; i = i + 2)
            {
                Span<string> slice = span.Slice(start: i, length: 2);
                Console.WriteLine($"Coppia: {slice[0]}, {slice[1]}");
            }
        }
    }
}