﻿using System;
using System.Collections.Generic;
using System.Text;
using Capitolo14.Library;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;

[assembly: HostingStartup(typeof(MyHostingStartup))]

namespace Capitolo14.Library
{
    public class MyHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices(s =>
            {
                // Configurazione di un servizio della libreria
                s.AddTransient<MyService>();
                // Configurazione dell'application
                s.AddTransient<IStartupFilter, MyStartupFilter>();
            });
        }
    }

    public class MyStartupFilter : IStartupFilter
    {
        public Action<IApplicationBuilder> Configure(Action<IApplicationBuilder> next)
        {
            return builder =>
            {
                // Chiamo le altre configurazioni
                next(builder);

                // Aggiungo in coda i miei middleware
                builder.UseMvc();
            };
        }
    }

    public class MyService
    {

    }
}
