﻿using System;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario23
    {
        private static int _bufferedCount;
        private static byte[] _buffer;

        /// <summary>
        /// Esempio 8.28
        /// </summary>
        public static void Run()
        {

        }

        public static async Task WriteAsync(byte value)
        {
            if (_bufferedCount == _buffer.Length)
            {
                await FlushAsync();
            }

            _buffer[_bufferedCount++] = value;
        }

        public static async ValueTask WriteAsyncWithValueTask(byte value)
        {
            if (_bufferedCount == _buffer.Length)
            {
                await FlushAsync();
            }

            _buffer[_bufferedCount++] = value;
        }

        private static Task FlushAsync()
        {
            throw new NotImplementedException();
        }
    }
}