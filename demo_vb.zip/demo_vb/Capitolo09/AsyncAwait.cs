﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ASPItalia.Books.Chapter09
{
    public class AsyncAwait
    {
        // ***************************************************************************************************
        // Esempio 09.25
        // ***************************************************************************************************

        public static void Download()
        {
            Console.WriteLine("---- Download ----");

            WebRequest client = HttpWebRequest.Create("http://www.google.com");
            var response = client.GetResponse();

            using (var reader = new StreamReader(response.GetResponseStream()))
            {
                // esecuzione sincrona della richiesta
                var result = reader.ReadToEnd();

                Console.WriteLine(result);
            }
        }

        // ***************************************************************************************************
        // Esempio 09.26
        // ***************************************************************************************************

        public static async Task DownloadAsync()
        {
            Console.WriteLine("---- DownloadAsync ----");

            WebRequest client = HttpWebRequest.Create("http://www.google.com");
            var response = client.GetResponse();

            using (var reader = new StreamReader(response.GetResponseStream()))
            {
                // esecuzione asincrona della richiesta
                var result = await reader.ReadToEndAsync();

                Console.WriteLine(result);
            }
        }

        // ***************************************************************************************************
        // Esempio 09.27
        // ***************************************************************************************************

        public static async Task SequentialOperations()
        {
            Console.WriteLine("---- SequentialOperations ----");

            HttpClient client = new HttpClient();

            var firstResult = await client.GetStringAsync("http://www.google.com");
            Console.WriteLine(firstResult);

            var secondResult = await client.GetStringAsync("http://www.yahoo.com");
            Console.WriteLine(secondResult);

            var thirdResult = await client.GetStringAsync("http://www.bing.com");
            Console.WriteLine(thirdResult);
        }

        // ***************************************************************************************************
        // Esempio 09.28
        // ***************************************************************************************************

        public static async Task ParallelOperations()
        {
            Console.WriteLine("---- ParallelOperations ----");

            HttpClient client = new HttpClient();

            var tasks = new List<Task<string>>() 
            {
                client.GetStringAsync("http://www.google.com"),
                client.GetStringAsync("http://www.yahoo.com"),
                client.GetStringAsync("http://www.bing.com")
            };

            await Task.WhenAll(tasks);

            foreach (var task in tasks)
            {
                Console.WriteLine(task.Result);
            }
        }

        // ***************************************************************************************************
        // Esempio 09.29
        // ***************************************************************************************************

        public static Task<string> SomeMethodAsync()
        {
            return Task.Run(() => SomeMethod());
        }

        public static string SomeMethod()
        {
            // codice qui...
            Thread.Sleep(3000);

            return "test";
        }

        public static async void Execute()
        {
            AsyncAwait.Download();
            await AsyncAwait.DownloadAsync();
            await AsyncAwait.SequentialOperations();
            await AsyncAwait.ParallelOperations();

            var result = await SomeMethodAsync();

            Console.WriteLine(result);
        }
    }
}
