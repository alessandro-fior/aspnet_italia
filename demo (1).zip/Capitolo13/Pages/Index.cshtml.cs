﻿using System;
using System.Linq;
using System.Net;
using Capitolo13.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Capitolo13.Pages
{
    public class IndexModel : PageModel
    {

        public void OnPost(string type)
        {
            try
            {
                switch (type)
                {
                    case "fatal":
                        throw new ApplicationException("Test");
                    case "database":
                        var customersContext = new CustomersContext();
                        customersContext.Customers.ToArray();
                        break;
                    default:
                        throw new WebException("Test");
                }
            }
            catch (WebException)
            {
                ModelState.AddModelError("", "Errore nella chiamata ai servizi, riprovare.");
            }
        }
    }
}
