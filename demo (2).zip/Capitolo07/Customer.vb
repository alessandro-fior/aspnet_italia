﻿Namespace ASPItalia.Books.Chapter07
    Public Class Customer

    End Class
End Namespace