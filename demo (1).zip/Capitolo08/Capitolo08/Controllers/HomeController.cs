﻿using Capitolo08.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.FileProviders.Physical;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using System.Threading.Tasks;

namespace Capitolo08.Controllers
{
	public class HomeController : Controller
	{
		IDistributedCache _cache;

		public HomeController(IDistributedCache cache)
		{
			_cache = cache;
		}

		public IActionResult Hidden()
		{
			var model = new HiddenViewModel() { Id = 5 };
			return View(model);
		}

		[HttpPost]
		public IActionResult Hidden(HiddenViewModel model)
		{
			return Content(model.Id.ToString());
		}

		public IActionResult ReadCookie()
		{
			Dictionary<string, string> model = new Dictionary<string, string>();
			foreach (var item in Request.Cookies)
			{
				model.Add(item.Key, item.Value);
			}

			var value = Request.Cookies["CookieKey"];
			Request.Cookies.TryGetValue("CookieKey", out var tryvalue);
			return View();
		}

		public IActionResult WriteCookie()
		{
			return View();
		}

		[HttpPost]
		public IActionResult WriteCookie(WriteCookieViewModel model)
		{
			if (ModelState.IsValid)
			{
				Response.Cookies.Append(model.Key, model.Value);
			}
			return RedirectToAction("WriteCookie");
		}

		[HttpPost]
		public IActionResult DeleteCookie(WriteCookieViewModel model)
		{
			Response.Cookies.Delete(model.Key);
			return RedirectToAction("WriteCookie");
		}

		public IActionResult Session()
		{
			HttpContext.Session.SetString("key", "value");
			_cache.SetString("my", "ciao");
			return View("Session", HttpContext.Session.GetString("key"));
		}

		public IActionResult TempDataAdd()
		{
			TempData.Add("Key", "value");
			return Content(String.Empty);
		}

		public IActionResult TempDataPeek()
		{
			var value = TempData.Peek("Key");
			return Content((string)value);
		}

		public IActionResult TempDataGet()
		{
			var value = TempData["Key"];
			return Content((string)value);
		}

		public IActionResult HttpItems()
		{
			var sw = (Stopwatch)HttpContext.Items["sw"];
			return Content(sw.ElapsedMilliseconds.ToString());
		}

		public async Task<IActionResult> Cache([FromServices] IMemoryCache cache)
		{
			var cts = new CancellationTokenSource();
			cache.Set("keyDep", cts);

			var value = cache.GetOrCreate("key", e =>
			{
				e.SetAbsoluteExpiration(DateTime.Now.AddMinutes(10));
				e.SetSlidingExpiration(TimeSpan.FromMinutes(1));
				e.ExpirationTokens.Add(new CancellationChangeToken(cts.Token));
				e.ExpirationTokens.Add(new PollingFileChangeToken(new FileInfo(@"c:\work\file.txt")));
				e.RegisterPostEvictionCallback(OnEviction);
				return "value";
			});

			var valueAsync = await cache.GetOrCreateAsync("key2", e =>
			{
				e.AbsoluteExpiration = DateTime.Now.AddMinutes(10);
				return Task.FromResult(10);
			});

			return Content(value + "-" + valueAsync);
		}

		private void OnEviction(object key, object value, EvictionReason reason, object state)
		{
			Debug.WriteLine($"{key} removed. Reason:{reason}");
		}

		public IActionResult CacheGet([FromServices] IMemoryCache cache)
		{
			var x = cache.Get("key");
			return Content((string)x);
		}

		public IActionResult CacheExpire([FromServices] IMemoryCache cache)
		{
			cache.Get<CancellationTokenSource>("keyDep").Cancel();
			return Content("cancelled");
		}

		public IActionResult QS(int key, string v)
		{
			var model = new QSModel();
			model.KeyFromParam = key;
			model.VFromParam = v;
			model.KeyFromQS = Request.Query["key"];
			model.VFromQS = Request.Query["v"];
			return View(model);
		}

		public async Task<IActionResult> WriteDistributedCache([FromServices] IDistributedCache cache)
		{
			// elemento senza opzioni
			await cache.SetAsync("key", Serialize("value"));
			// elemento che scade dopo un'ora
			await cache.SetAsync("key", Serialize("value"),
			new DistributedCacheEntryOptions
			{
				AbsoluteExpiration = DateTime.Now.AddHours(1)
			});
			// elemento che scade dopo 10 minuti dall'ultimo accesso
			await cache.SetAsync("key", Serialize("value"),
			new DistributedCacheEntryOptions
			{
				SlidingExpiration = TimeSpan.FromMinutes(10)
			});
			// elemento inserito usando SetString
			await cache.SetStringAsync("key", "value");

			// elemento con un oggetto inserito usando SetString
			await cache.SetStringAsync("key", SerializeJson(new { Prop = 1 }));
			return View();
		}

		private byte[] Serialize(object obj)
		{
			if (obj == null)
				return null;
			var bf = new BinaryFormatter();
			using (var ms = new MemoryStream())
			{
				bf.Serialize(ms, obj);
				return ms.ToArray();
			}
		}

		private string SerializeJson(object obj)
		{
			return JsonConvert.SerializeObject(obj);
		}


		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}

		private class Person
		{
			public string FirstName { get; set; }
			public string LastName { get; set; }
		}
	}
}
