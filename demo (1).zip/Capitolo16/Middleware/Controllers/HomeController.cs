﻿using System.Text;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Middleware.Middleware;

namespace Middleware.Controllers
{
    [MiddlewareFilter(typeof(CustomRouteLocalizationMiddleware))]
    public class HomeController : ControllerBase
    {
        IStringLocalizer localizer;

        public HomeController(IStringLocalizer<HomeController> localizer)
        {
            this.localizer = localizer;
        }

        public IActionResult Index(string value)
        {
            IRequestCultureFeature feature = HttpContext.Features.Get<IRequestCultureFeature>();

            var builder = new StringBuilder();
            builder.AppendLine($"Culture: {feature.RequestCulture.Culture}");
            builder.AppendLine($"UI Culture: {feature.RequestCulture.UICulture}");
            builder.AppendLine($"Provider: {feature.Provider}");

            if (!string.IsNullOrEmpty(value))
                builder.AppendLine($"Value: {localizer[value]}");

            return Ok(builder.ToString());
        }

        public IActionResult SetCulture(string value)
        {
            var requestedCulture = new RequestCulture(value);
            var cookie = CookieRequestCultureProvider.MakeCookieValue(requestedCulture);

            Response.Cookies.Append(CookieRequestCultureProvider.DefaultCookieName, cookie);

            return Ok();
        }
    }
}