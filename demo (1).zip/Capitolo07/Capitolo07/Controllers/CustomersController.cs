﻿using Capitolo07.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Capitolo07.Controllers
{
    public class CustomersController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            var model = new CustomerModel();
            model.Countries.AddRange(GetCountries()); //recupera gli stati
            return View(model);
        }

        private IEnumerable<CountryModel> GetCountries()
        {
            return new[]
            {
                new CountryModel { Id = 1, Name = "Italia" },
                new CountryModel { Id = 2, Name = "USA" },
                new CountryModel { Id = 3, Name = "San Marino" },
            };
        }

        [HttpPost]
        public IActionResult Create(CustomerModel model)
        {
            if (ModelState.IsValid)
            {
                //Salva dati
                return RedirectToAction(nameof(Index));
            }

            // ricarico form
            model.Countries.AddRange(GetCountries()); //recupera gli stati
            return View(model);
        }

        [AcceptVerbs("Get", "Post")]
        public IActionResult IsNameValid(string name)
        {
            var isValid = !name.ToLower().Contains("daniele");
            //Logica di validazione
            return Json(isValid);
        }
    }
}