# Gestione di file statici
Questo progetto è un'applicazione ASP.NET Core minimale creata con il comando `dotnet new web`, composta di soli file statici (html, css e jpg) situati nella directory `wwwroot`.

Alla riga 29 del file [Startup.cs](Startup.cs) viene usato il middleware che aggiunge il supporto ai file statici.