﻿
Imports System.Data.Entity.Infrastructure
Imports System.Net
Imports System.Web.Http
Imports System.Web.Http.ModelBinding
Imports System.Web.Http.OData

Public Class ODataCustomersController
    Inherits ODataController
    Private db As New SampleContext()

    ' GET: odata/ODataCustomers
    <EnableQuery>
    Public Function GetODataCustomers() As IQueryable(Of Customer)
        Return db.Customers
    End Function

    ' GET: odata/ODataCustomers(5)
    <EnableQuery>
    Public Function GetCustomer(<FromODataUri> key As Integer) As SingleResult(Of Customer)
        Return SingleResult.Create(db.Customers.Where(Function(customer) customer.Id = key))
    End Function

    ' PUT: odata/ODataCustomers(5)
    Public Function Put(<FromODataUri> key As Integer, patch As Delta(Of Customer)) As IHttpActionResult
        Validate(patch.GetEntity())

        If Not ModelState.IsValid Then
            Return BadRequest(ModelState)
        End If

        Dim customer As Customer = db.Customers.Find(key)
        If customer Is Nothing Then
            Return NotFound()
        End If

        patch.Put(customer)

        Try
            db.SaveChanges()
        Catch generatedExceptionName As DbUpdateConcurrencyException
            If Not CustomerExists(key) Then
                Return NotFound()
            Else
                Throw
            End If
        End Try

        Return Updated(customer)
    End Function

    ' POST: odata/ODataCustomers
    Public Function Post(customer As Customer) As IHttpActionResult
        If Not ModelState.IsValid Then
            Return BadRequest(ModelState)
        End If

        db.Customers.Add(customer)
        db.SaveChanges()

        Return Created(customer)
    End Function

    ' PATCH: odata/ODataCustomers(5)
    <AcceptVerbs("PATCH", "MERGE")>
    Public Function Patch(<FromODataUri> key As Integer, patch__1 As Delta(Of Customer)) As IHttpActionResult
        Validate(patch__1.GetEntity())

        If Not ModelState.IsValid Then
            Return BadRequest(ModelState)
        End If

        Dim customer As Customer = db.Customers.Find(key)
        If customer Is Nothing Then
            Return NotFound()
        End If

        patch__1.Patch(customer)

        Try
            db.SaveChanges()
        Catch generatedExceptionName As DbUpdateConcurrencyException
            If Not CustomerExists(key) Then
                Return NotFound()
            Else
                Throw
            End If
        End Try

        Return Updated(customer)
    End Function

    ' DELETE: odata/ODataCustomers(5)
    Public Function Delete(<FromODataUri> key As Integer) As IHttpActionResult
        Dim customer As Customer = db.Customers.Find(key)
        If customer Is Nothing Then
            Return NotFound()
        End If

        db.Customers.Remove(customer)
        db.SaveChanges()

        Return StatusCode(HttpStatusCode.NoContent)
    End Function

    Protected Overrides Sub Dispose(disposing As Boolean)
        If disposing Then
            db.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private Function CustomerExists(key As Integer) As Boolean
        Return db.Customers.Count(Function(e) e.Id = key) > 0
    End Function
End Class

