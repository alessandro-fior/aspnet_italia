﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace CS {
	class Program {
		static void Main(string[] args) {
			FindCustomersByCountry();
			//FindCustomersById();
			//ProjectCustomers();
			//CreateOrder();
			//CreateCustomer();
			//FindCustomerById();
			//UpdateCustomerDisconnected();
			//DeleteCustomer();
			//DeleteCustomerDisconnected();
			Console.ReadLine();
		}
		static void FindCustomersByCountry() {
			using (NorthwindEntities ctx = new NorthwindEntities()) {
				var customers = from c in ctx.Customers
												where c.Address.Country == "Italy"
												select c;
				foreach (var c in customers) {
					Console.WriteLine(c.CustomerID + " - " + c.CompanyName);
				}
			}
		}

		static void FindCustomersById() {
			using (NorthwindEntities ctx = new NorthwindEntities()) {
				var customer = ctx.Customers.First(c => c.CustomerID == "ALFKI");

				Console.WriteLine(customer.CustomerID + " - " + customer.CompanyName);
			}
		}

		static void ProjectCustomers() {
			using (NorthwindEntities ctx = new NorthwindEntities()) {
				var customers = ctx.Customers.Select(c => new { c.CustomerID, c.CompanyName });

				foreach (var c in customers) {
					Console.WriteLine(c.CustomerID + " - " + c.CompanyName);
				}
			}
		}

		static void CreateOrder() {
			using (NorthwindEntities ctx = new NorthwindEntities()) {
				var o = new Order {
					CustomerID = "STEMO",
					EmployeeID = 1,
					OrderDate = DateTime.Now,
					RequiredDate = DateTime.Now.AddDays(10),
					ShipAddress = new AddressInfo {
						Address = "Via Del Corso 14",
						City = "Roma",
						Country = "Italy",
						PostalCode = "00100",
						Region = "Lazio"
					},
					ShipName = "Stefano Mostarda",
					ShipVia = 1,
					Freight = (decimal)8.53
				};

				o.Order_Details.Add(new Order_Detail { ProductID = 1, Discount = 0, Quantity = 10, UnitPrice = 20 });
				o.Order_Details.Add(new Order_Detail { ProductID = 2, Discount = 0, Quantity = 30, UnitPrice = 100 });
				o.Order_Details.Add(new Order_Detail { ProductID = 3, Discount = 0, Quantity = 20, UnitPrice = 40 });
				ctx.Orders.AddObject(o);
				ctx.SaveChanges();

				Console.WriteLine("OrderCreated");
			}
		}

		static void CreateCustomer() {
			using (NorthwindEntities ctx = new NorthwindEntities()) {
				var c = new Customer {
					CustomerID = "STEMO",
					CompanyName = "Stefano Mostarda",
					ContactName = "Stefano Mostarda",
					Address = new AddressInfo {
						Address = "Via Del Corso 14",
						City = "Roma",
						Country = "Italy",
						PostalCode = "00100",
						Region = "Lazio"
					},
					ContactTitle = "Sig",
					Phone = "00000",
					Fax = "00000"
				};

				ctx.Customers.AddObject(c);
				ctx.SaveChanges();
				Console.WriteLine("CustomerCreated");
			}
		}

		static void UpdateCustomer() {
			using (NorthwindEntities ctx = new NorthwindEntities()) {
				var cust = ctx.Customers.First(c => c.CustomerID == "STEMO");
				cust.Address.Address = "Piazza del popolo 1";
				ctx.SaveChanges();
				Console.WriteLine("Customer Updated");
			}
		}

		static void UpdateCustomerDisconnected() {
			Customer Cust = default(Customer);
			using (NorthwindEntities ctx = new NorthwindEntities()) {
				Cust = ctx.Customers.First(c => c.CustomerID == "STEMO");
			}

			Cust.Address.Address = "Piazza Venezia 10";
			using (NorthwindEntities ctx = new NorthwindEntities()) {
				ctx.Customers.Attach(Cust);
				ctx.ObjectStateManager.ChangeObjectState(Cust, EntityState.Modified);
				ctx.SaveChanges();
			}
			Console.WriteLine("Customer updated");
		}

		static void DeleteCustomer() {
			using (NorthwindEntities ctx = new NorthwindEntities()) {
				var Cust = ctx.Customers.First(c => c.CustomerID == "STEMO");
				ctx.Customers.DeleteObject(Cust);
			}
			Console.WriteLine("Customer deleted");
		}

		static void DeleteCustomerDisconnected() {
			Customer Cust = default(Customer);
			using (NorthwindEntities ctx = new NorthwindEntities()) {
				Cust = ctx.Customers.First(c => c.CustomerID == "STEMO");
			}

			using (NorthwindEntities ctx = new NorthwindEntities()) {
				ctx.Customers.Attach(Cust);
				ctx.Customers.DeleteObject(Cust);
			}
			Console.WriteLine("Customer Deleted");
		}
	}
}
