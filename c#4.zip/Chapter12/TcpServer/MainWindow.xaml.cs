﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using Microsoft.Win32;

namespace TcpServer
{
  public partial class MainWindow : Window
  {
public delegate void ManageDataDelegate(MemoryStream result);

public MainWindow()
{
  InitializeComponent();

  new Thread(new ThreadStart(this.ReiceveData)) { IsBackground = true }.Start();
}

private void Button1_Click(object sender, RoutedEventArgs e)
{
  using (Stream fileStream = File.OpenRead(this.TextBlock1.Tag.ToString()))
  {
    TcpClient client = new TcpClient();
    client.Connect("localhost", 1234);
    NetworkStream netStream = client.GetStream();
    byte[] sendBuffer = new byte[1024];
    int bytesRead = 0;
    do
    {
      bytesRead = fileStream.Read(sendBuffer, 0, 1024);
      if (bytesRead > 0)
      {
        netStream.Write(sendBuffer, 0, bytesRead);
      }
    }
    while (bytesRead > 0);
    netStream.Close();
  }
}

private void Button2_Click(object sender, RoutedEventArgs e)
{
  OpenFileDialog fileDialog = new OpenFileDialog
  {
    Filter = "immagini (*.jpg)|*.jpg"
  };
  bool? show = fileDialog.ShowDialog();
  if (show.HasValue & show.Value)
  {
    using (fileDialog.OpenFile())
    {
      this.TextBlock1.Tag = fileDialog.FileName;
      this.TextBlock1.Text = fileDialog.SafeFileName;
    }
  }
}

private void ReiceveData()
{
  TcpListener server = new TcpListener(new IPEndPoint(IPAddress.Any, 0x4d2));
  server.Start();
  while (true)
  {
    if (server.Pending())
    {
      TcpClient localClient = server.AcceptTcpClient();
      NetworkStream netStream = localClient.GetStream();
      if (netStream.CanRead)
      {
        MemoryStream dataStream = new MemoryStream();
        byte[] dataByte = new byte[1024];
        int i = 0;
        do
        {
          i = netStream.Read(dataByte, 0, 1024);
          if (i > 0)
          {
            dataStream.Write(dataByte, 0, i);
          }
        }
        while (i > 0);
        dataStream.Seek(0, SeekOrigin.Begin);
        this.Dispatcher.BeginInvoke(new ManageDataDelegate(this.ViewData), new object[] { dataStream });
      }
      localClient.Close();
      netStream.Close();
    }
  }
}

private void ViewData(MemoryStream datas)
{
  BitmapImage bmpImage = new BitmapImage();
  bmpImage.BeginInit();
  bmpImage.StreamSource = datas;
  bmpImage.EndInit();
  Image img = new Image
  {
    Stretch = Stretch.Uniform,
    Source = bmpImage
  };
  this.StackPanel1.Children.Add(img);
}
  }
}
