﻿
Public Class DateToColorConverter
    Implements IValueConverter

    Public Shared ReadOnly Instance As New DateToColorConverter

    Public Function Convert(ByVal value As Object, ByVal targetType As System.Type, ByVal parameter As Object, ByVal culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.Convert
        Dim d As Date = CDate(value)
        If d.Day Mod 2 = 0 Then
            Return Brushes.Green
        Else
            Return Brushes.Red
        End If
    End Function

    Public Function ConvertBack(ByVal value As Object, ByVal targetType As System.Type, ByVal parameter As Object, ByVal culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.ConvertBack
        Throw New NotImplementedException()
    End Function
End Class
