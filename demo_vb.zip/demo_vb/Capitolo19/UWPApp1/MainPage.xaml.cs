﻿using DataModel;
using Newtonsoft.Json;
using System;
using System.Net.Http;
//using Windows.Web.Http;
using System.Text;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace UWPApp1
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class MainPage : Page
	{
		StringBuilder log = new StringBuilder();
		Uri baseUri = new Uri("http://localhost:18974/");

		public MainPage()
		{
			this.InitializeComponent();
			this.Loaded += MainWindow_Loaded;
		}

		private void MainWindow_Loaded(object sender, RoutedEventArgs e)
		{
			TextBox1.Text = "api/products/5";
		}

		private async void ButtonGet_Click(object sender, RoutedEventArgs e)
		{
			using (var client = new HttpClient())
			{
				try
				{
					client.BaseAddress = baseUri;
					client.MaxResponseContentBufferSize = 1024;

					string data = await client.GetStringAsync(TextBox1.Text);
					log.AppendLine(data);

					using (HttpResponseMessage response = await client.GetAsync(TextBox1.Text))
					{
						if (response.IsSuccessStatusCode)
						{
							Product product = await response.Content.ReadAsAsync<Product>();

							log.AppendLine(product.ToString());
						}
						else
						{
							log.AppendLine(response.ReasonPhrase);

							response.EnsureSuccessStatusCode();
						}
					}
				}
				catch (Exception ex)
				{
					log.AppendLine(ex.ToString());
				}
				finally
				{
					log.AppendLine("------------");
					TextBox2.Text = log.ToString();
				}
			}
		}

		private async void ButtonPost_Click(object sender, RoutedEventArgs e)
		{
			using (var client = new HttpClient())
			{
				try
				{
					client.BaseAddress = baseUri;

					var product = JsonConvert.DeserializeObject<Product>(TextBox2.Text);

					using (var response = await client.PostAsJsonAsync("api/products", product))
					{
						if (response.IsSuccessStatusCode)
						{
							Uri productUrl = response.Headers.Location;

							log.AppendLine(product.ToString());

							log.AppendLine(productUrl.ToString());
						}
						else
						{
							log.AppendLine(response.ReasonPhrase);
							response.EnsureSuccessStatusCode();
						}
					}
				}
				catch (Exception ex)
				{
					log.AppendLine(ex.ToString());
				}
				finally
				{
					log.AppendLine("------------");
					TextBox2.Text = log.ToString();
				}
			}
		}

		private async void ButtonPut_Click(object sender, RoutedEventArgs e)
		{
			using (var client = new HttpClient())
			{
				try
				{
					client.BaseAddress = baseUri;

					using (HttpResponseMessage response = await client.GetAsync(TextBox1.Text))
					{
						if (response.IsSuccessStatusCode)
						{
							Product product = await response.Content.ReadAsAsync<Product>();

							product.Name = TextBox2.Text;
							using (var response2 = await client.PutAsJsonAsync(TextBox1.Text, product))
							{
								Product product2 = await response.Content.ReadAsAsync<Product>();
								log.AppendLine(product2.ToString());
							}
						}
						else
						{
							log.AppendLine(response.ReasonPhrase);
							response.EnsureSuccessStatusCode();
						}
					}
				}
				catch (Exception ex)
				{
					log.AppendLine(ex.ToString());
				}
				finally
				{
					log.AppendLine("------------");
					TextBox2.Text = log.ToString();
				}
			}
		}

		private async void ButtonDelete_Click(object sender, RoutedEventArgs e)
		{
			using (var client = new HttpClient())
			{
				try
				{
					client.BaseAddress = baseUri;

					using (var response = await client.DeleteAsync(TextBox1.Text))
					{
						if (response.IsSuccessStatusCode)
						{
							Product product = await response.Content.ReadAsAsync<Product>();

							log.AppendLine(product.ToString());
						}
						else
						{
							log.AppendLine(response.ReasonPhrase);
							response.EnsureSuccessStatusCode();
						}
					}
				}
				catch (Exception ex)
				{
					log.AppendLine(ex.ToString());
				}
				finally
				{
					log.AppendLine("------------");
					TextBox2.Text = log.ToString();
				}
			}
		}
	}
}
