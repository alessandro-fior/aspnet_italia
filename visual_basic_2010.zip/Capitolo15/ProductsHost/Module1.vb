﻿Imports System.ServiceModel
Imports ASPItalia.Books.Chapter15.ProductsService

Module Module1

    Sub Main()
        ' Apro l'hosting del servizio
        Dim host As New ServiceHost(GetType(Products))
        host.Open()

        Console.WriteLine("Listening! Press return to exit")

        ' Attendo fino a quando l'utente preme invio
        Console.ReadLine()

        ' Chiudo l'hosting
        host.Close()
    End Sub

End Module
