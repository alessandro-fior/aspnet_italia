﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Dynamic;

namespace ASPItalia.Books.Chapter07
{
    public class MyDynamicObject : DynamicObject
    {
        public override bool TryGetMember(
          GetMemberBinder binder, out object result)
        {
            result = "Property " + binder.Name;
            return true;
        }

        public override bool TryInvokeMember(
          InvokeMemberBinder binder, object[] args, out object result)
        {
            result = "Method " + binder.Name;
            return true;
        }
    }

}
