﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Diagnostics;

namespace Capitolo08
{
	public class Startup
	{
		public Startup(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
			services.AddDistributedRedisCache(options =>
			{
				options.Configuration = "localhost";
				options.InstanceName = "SampleInstance";
			});
			services.AddDistributedSqlServerCache(o =>
			{
				o.ConnectionString = "Data Source=(local);Initial Catalog=DistCache;Integrated Security=True;";
				o.TableName = "TestCache";
				o.SchemaName = "dbo";
			});
			//services.AddDistributedMemoryCache();
			services.AddResponseCaching();
			services.AddMvc().AddSessionStateTempDataProvider().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
			services.AddMemoryCache();
			services.AddSession(a => a.IdleTimeout = TimeSpan.FromMinutes(10));
		}

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IHostingEnvironment env)
		{
			app.UseResponseCaching();
			app.Use(async (context, next) =>
			{
				var sw = new Stopwatch();
				context.Items["sw"] = sw;
				sw.Start();
				await next.Invoke();
				sw.Stop();
				Debug.WriteLine(sw.ElapsedMilliseconds);
			});

			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
			}
			else
			{
				app.UseExceptionHandler("/Home/Error");
			}

			app.UseStaticFiles();
			app.UseSession();
			app.UseMvc(routes =>
			{
				routes.MapRoute(
									name: "default",
									template: "{controller=Home}/{action=Index}/{id?}");
			});
		}
	}
}
