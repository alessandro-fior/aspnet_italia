﻿using System.Diagnostics;
using Capitolo14.Middleware;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace Microsoft.AspNetCore.Builder
{
    public static class TimerExtensions
    {
        public static IApplicationBuilder UseTimer(this IApplicationBuilder applicationBuilder)
        {
            return applicationBuilder.UseMiddleware<TimerMiddleware>();
        }
    }
}

namespace Capitolo14.Middleware
{
    public static class TimerExtensions
    {
        public static Stopwatch GetTimer(this HttpContext httpContext)
        {
            return httpContext.Features.Get<ITimerFeature>()?.Stopwatch;
        }
    }
}
