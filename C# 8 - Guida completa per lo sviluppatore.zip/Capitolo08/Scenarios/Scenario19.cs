﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario19
    {
        /// <summary>
        /// Esempio 8.21, 8.22
        /// </summary>
        public static void Run()
        {
            var outerTask = Task.Factory.StartNew(() =>
            {
                var innerTask = Task.Factory.StartNew(() =>
                {
                    Thread.Sleep(2000);
                    Console.WriteLine("Nested task");
                });

                // fix per l'implementazione precedente
                //var innerTask = Task.Factory.StartNew(() =>
                //{
                //    Thread.Sleep(2000);
                //    Console.WriteLine("Nested task");
                //}, TaskCreationOptions.AttachedToParent);

                Console.WriteLine("Outer Task");
            });

            outerTask.Wait();            
            Console.WriteLine("outerTask terminato");
        }
    }
}