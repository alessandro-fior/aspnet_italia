using System;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using ConfigSample.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ConfigSample.Middlewares
{
    public class EmailErrorsMiddleware
    {
        private readonly IOptionsMonitor<SmtpOptions> smtpOptions;
        private readonly IOptionsMonitor<ConnectionStringOptions> connectionStringOptions;
        private readonly ILogger<EmailErrorsMiddleware> logger;
        private readonly RequestDelegate next;

        //Riceviamo i servizi come parametri del costruttore
        //Si dice che questo middleware DIPENDE da essi
        public EmailErrorsMiddleware(
            RequestDelegate next,
            IOptionsMonitor<SmtpOptions> smtpOptions,
            IOptionsMonitor<ConnectionStringOptions> connectionStringOptions,
            ILogger<EmailErrorsMiddleware> logger
        )
        {
            this.smtpOptions = smtpOptions;
            this.connectionStringOptions = connectionStringOptions;
            this.logger = logger;
            //L'oggetto next, di tipo RequestDelegate, rappresenta il prossimo middleware configurato nella pipeline (se presente)
            this.next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await next.Invoke(context);
            }
            catch (Exception exc)
            {
                SendErrorEmail(exc);
                //Rilanciamo l'eccezione, così che il middleware della pagina d'errore
                //possa visualizzare il suo contenuto
                throw;
            }
        }

        private void SendErrorEmail(Exception exc)
        {
            var smtp = smtpOptions.CurrentValue;
            try
            {
                using (var client = new SmtpClient())
                {
                    client.Host = smtp.Host;
                    client.Port = smtp.Port;
                    client.EnableSsl = smtp.EnableSsl;
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    if (!string.IsNullOrWhiteSpace(smtp.Username)) {
                        client.UseDefaultCredentials = false;
                        client.Credentials = new NetworkCredential(userName: smtp.Username, password: smtp.Password);
                    }
                    client.Timeout = 10000; //ms
                    logger.LogInformation($"Invio l'email per l'errore: '{exc.Message}'");

                    //Inviamo la mail di errore
                    client.Send(
                        from: smtp.Email,
                        recipients: smtp.Email,
                        subject: "Errore nell'applicazione",
                        body: $"Si è verificato il seguente errore:\r\n{exc.ToString()}");
                    //Scriviamo l'avvenuto invio nel log
                    logger.LogInformation($"Inviata e-mail a {smtp.Email} per l'errore '{exc.Message}'");
                }
            }
            catch (Exception mailExc)
            {
                logger.LogError($"Impossibile inviare l'e-mail di errore a {smtp.Email} a causa di '{mailExc.Message}', controlla le impostazioni SMTP");
            }
        }
    }
}