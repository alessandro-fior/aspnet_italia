﻿using System.Collections.Generic;

namespace DemoWebAPI.Models
{
    public class CustomerForReadV2 : CustomerForRead
    {
        public ICollection<Link> Links { get; set; } = new List<Link>();
    }
}