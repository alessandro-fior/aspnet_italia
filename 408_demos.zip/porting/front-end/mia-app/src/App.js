import React, {Component} from 'react';
import Forecasts from './components/forecasts';

class App extends Component {
  state = {
    forecasts: []
  }
  componentDidMount() {
    fetch('https://localhost:5001/WeatherForecast')
    .then(res => res.json())
    .then((data) => {
      this.setState({ forecasts: data })
    })
    .catch(console.log)
  }
  render () {
    return (
      <Forecasts forecasts={this.state.forecasts} />
    );
  }
}

export default App;