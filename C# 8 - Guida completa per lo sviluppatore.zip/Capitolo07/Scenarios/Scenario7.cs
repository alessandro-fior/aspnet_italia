﻿using System;
using System.Collections.Generic;

namespace Capitolo7.Scenarios
{
    public static class Scenario7
    {
        /// <summary>
        /// Esempio 7.12, 7.13
        /// </summary>
        public static void Run()
        {
            try
            {
                SomeMethod(null);
            }
            catch
            {
                Console.WriteLine("Si è verificato un errore");
            }
        }

        public static void SomeMethod(List<int> items)
        {
            if (items == null)
            {
                // Si solleva l'eccezione indicando il nome dell'argomento non
                // correttamente valorizzato
                throw new ArgumentNullException("items");

                // sintassi alternativa
                //throw new ArgumentNullException(nameof(items));
            }

            // Codice del metodo qui
        }
    }
}