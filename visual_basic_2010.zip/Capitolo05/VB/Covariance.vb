﻿Namespace ASPItalia.Books.Chapter05
    Module Covariance
        Public Sub SomeMethod(ByVal list As IEnumerable(Of Object))
            For Each item In list
                Console.WriteLine(item)
            Next
        End Sub

        Sub Main()

            Dim strings As New List(Of String)
            SomeMethod(strings)

        End Sub
    End Module
End Namespace