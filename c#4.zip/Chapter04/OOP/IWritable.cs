﻿namespace Aspitalia.Books.Chapter4
{
    // Interfaccia
    public interface IWritable
    {
        void Write();
    }
}
