namespace Capitolo19.Models
{
	public class VueViewModel
	{
		public string Name { get; set; }
	}
}