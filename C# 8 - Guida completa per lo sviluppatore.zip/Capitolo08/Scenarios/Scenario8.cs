﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Capitolo8.Scenarios
{
    public static class Scenario8
    {
        /// <summary>
        /// Esempio 8.8
        /// </summary>
        public static void Run()
        {
            var list = new List<ManualResetEvent>();

            try
            {
                for (int index = 0; index < 5; index++)
                {
                    // Creazione del waitHandle per il task corrente
                    var waitHandle = new ManualResetEvent(false);
                    list.Add(waitHandle);
                    
                    // Oggetto da passare al task accodato
                    var state = new Tuple<int, ManualResetEvent>(index, waitHandle);

                    ThreadPool.QueueUserWorkItem((untypedState) =>
                    {
                        // WaitCallback accetta un object, pertanto
                        // è necessario un cast
                        var taskState = (Tuple<int, ManualResetEvent>)untypedState;

                        // Visualizzazione dei messaggi su console
                        Console.WriteLine("Thread {0} è iniziato", taskState.Item1);
                        Thread.Sleep(500);
                        Console.WriteLine("Thread {0} è terminato", taskState.Item1);

                        // Segnalazione del termine dell'esecuzione del task
                        // utilizzando il Set del ManualResetEvent
                        taskState.Item2.Set();
                    }, state);
                }

                // Attesa che tutti i ManualResetEvent siano in stato Set
                foreach (ManualResetEvent handle in list)
                {
                    handle.WaitOne();
                }
            }
            finally
            {
                foreach (ManualResetEvent handle in list)
                {
                    handle.Dispose();
                }
            }

            Console.WriteLine("Esecuzione terminata");
        }
    }
}