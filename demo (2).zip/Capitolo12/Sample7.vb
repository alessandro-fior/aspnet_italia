﻿Imports System.Xml

Public Class Sample7

    Public Shared Sub Run()
        ' Impostazioni di caricamento del file
        Dim settings As New XmlReaderSettings()
        settings.IgnoreComments = True
        settings.IgnoreProcessingInstructions = True
        settings.IgnoreWhitespace = True

        ' Using per chiudere il file e liberarlo
        Using reader = XmlReader.Create("Test.xml", settings)

            ' Leggo il prossimo nodo dallo stream
            While reader.Read()

                ' Stampo nome del nodo (attributo o elemento) e tipo
                Console.WriteLine("LocalName: {0} - NodeType: {1}",
                  reader.LocalName, reader.NodeType)

                ' Intercetto l'inizio di un nuovo elemento
                If reader.NodeType = XmlNodeType.Element Then
                    ' Identifico in che elemento mi trovo
                    Select Case reader.LocalName

                        Case "description"
                            ' Controllo che l'elemento non sia vuoto
                            If Not reader.IsEmptyElement Then
                                Console.WriteLine("Description: {0}",
                                  reader.ReadElementContentAsString())
                            End If
                        Case "product"
                            ' Mi sposto sull'attributo idProduct
                            If reader.MoveToAttribute("idProduct") Then
                                ' Se è andato a buon fine, leggo il valore
                                Console.WriteLine("idProduct: {0}", reader.Value)
                            End If
                    End Select
                End If
            End While

        End Using

    End Sub

End Class
