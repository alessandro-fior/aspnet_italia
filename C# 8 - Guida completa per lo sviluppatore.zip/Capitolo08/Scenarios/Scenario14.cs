﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario14
    {
        /// <summary>
        /// Esempio 8.14, 8.15, 8.16
        /// </summary>
        public static void Run()
        {
            // Costruzione di un semplice task
            var simpleTask = Task.Factory.StartNew(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Ciao da simpleTask");
            });

            // Costruzione di un task con parametro in input
            var parameterTask = Task.Factory.StartNew((name) =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Ciao da parameterTask, {0}", name);
            }, "Matteo Tumiati");

            // Costruzione di un task che ritorna un risultato
            var resultTask = Task.Factory.StartNew((inputValue) => PerformSomeLongCalulation(inputValue), 5000D);

            // sintassi alternativa
            //var resultTask = new Task((inputValue) => PerformSomeLongCalulation(inputValue), 5000D);
            //resultTask.Start();

            // Determinazione del risultato
            Console.WriteLine("Il risultato è: {0}", resultTask.Result);
        }

        private static int PerformSomeLongCalulation(object inputValue)
        {
            return 0;
        }
    }
}