using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using CustomerAuthorization.Data;
using CustomerAuthorization.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace CustomerAuthorization.Authorization
{
    public class SelfOrRoleAuthorizationHandler : AuthorizationHandler<SelfOrRoleRequirement>
    {
        protected override Task HandleRequirementAsync(
            AuthorizationHandlerContext context,
            SelfOrRoleRequirement requirement)
        {
            var isSelf = context.User.Identity.Name == context.Resource as string;
            var hasRole = (context.User.Identity as ClaimsIdentity).HasClaim(claim => claim.Type == ClaimTypes.Role && claim.Value == requirement.Role);
            if (isSelf || hasRole) {
                context.Succeed(requirement);
            } else {
                context.Fail();
            }
            return Task.CompletedTask;
        }
    }

}