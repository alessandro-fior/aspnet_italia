﻿using System.Linq;
using System.Xml.XPath;
using System.Xml;
using System;

public class Sample15
{
    public static void Run()
    {
        XPathDocument doc = new XPathDocument("test.xml");
        XPathNavigator navigator = doc.CreateNavigator();

        // Creo il gestore dei namespace
        XmlNamespaceManager nsManager = new XmlNamespaceManager(navigator.NameTable);
        // Associo il prefisso al namespace
        nsManager.AddNamespace("p", "http://schemas.aspitalia.com/book40/products");

        // Navigo direttamente sull'attributo
        navigator = navigator.SelectSingleNode("/p:products/p:product[1]/@idCategory", nsManager);

        // Leggo il valore
        int idCategory = navigator.ValueAsInt;

        Console.WriteLine(idCategory);
    }
}