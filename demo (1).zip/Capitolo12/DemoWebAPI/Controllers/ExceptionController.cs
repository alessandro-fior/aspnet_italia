﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace DemoWebAPI.Controllers
{
    [Route("api/exception")]
    [ApiVersion("1.0")]
    public class ExceptionController : Controller
    {
        /// <summary>
        /// Genera una eccezione
        /// </summary>
        /// <returns>N/A</returns>
        /// <response code="500">Quando si verifica l'eccezione</response>  
        [HttpGet]
        [ProducesResponseType(500)]
        public IActionResult GenerateException()
        {
            throw new NotImplementedException("Questo metodo è finto.");
        }
    }
}