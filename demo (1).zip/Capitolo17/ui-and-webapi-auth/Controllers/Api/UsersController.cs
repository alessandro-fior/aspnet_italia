using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UiAndApiAuth.Models;
using UiAndApiAuth.Models.Dto;

namespace UiAndApiAuth.Controllers
{
    //Le action di questo controller possono essere consumate solo accedento con JWT Token
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[Controller]")]
    public class UsersController : Controller {
        
        [HttpGet]
        public async Task<UsersResponse> Get([FromServices] UserManager<ApplicationUser> userManager) {
            var response = new UsersResponse {
                Users = await userManager.Users.Select(user => user.UserName).ToArrayAsync()
            };
            return response;
        }
    }
}