﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Debug;
using Newtonsoft.Json;

namespace Capitolo13
{
    public static class EmailLoggerProviderExtensions
    {
        public static ILoggingBuilder AddEmail(this ILoggingBuilder builder)
        {
            builder.Services.AddSingleton<ILoggerProvider, EmailLoggerProvider>();

            return builder;
        }
    }

    [ProviderAlias("Email")]
    public class EmailLoggerProvider : ILoggerProvider
    {
        private readonly ConcurrentDictionary<string, EmailLogger> _loggers = new ConcurrentDictionary<string, EmailLogger>();

        public ILogger CreateLogger(string categoryName)
        {
            // Caching dei logger
            return _loggers.GetOrAdd(categoryName, c => new EmailLogger(c));
        }

        public void Dispose()
        {
            _loggers.Clear();
        }
    }

    public class EmailLogger : ILogger
    {
        private string _category;

        public EmailLogger(string category)
        {
            _category = category;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            // Accedo allo stato come coppia chiave/valore
            var values = state as IEnumerable<KeyValuePair<string, object>>;

            // Serializo lo stato
            string json = JsonConvert.SerializeObject(state);

            // Ottengo il messaggio
            string message = formatter(state, exception);
        }

        public bool IsEnabled(LogLevel logLevel) => true;

        public IDisposable BeginScope<TState>(TState state) => null;
    }
}