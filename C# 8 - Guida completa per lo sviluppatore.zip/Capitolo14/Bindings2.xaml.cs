﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Markup;

namespace Capitolo14
{
    /// <summary>
    /// Interaction logic for Bindings2.xaml
    /// </summary>
    public partial class Bindings2 : Window
    {
        public Bindings2()
        {
            InitializeComponent();
        }

        private void Window_Loaded(Object sender, System.Windows.RoutedEventArgs e)
        {
            this.Language = XmlLanguage.GetLanguage("it-IT");
        }
    }
}
