using System;
using System.IO;
using System.Reflection;
using System.Runtime.Loader;
using System.Threading.Tasks;
using Capitolo14.Data;
using Capitolo14.Filters;
using Capitolo14.Middleware;
using Capitolo14.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApplicationParts;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Capitolo14
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<CustomersContext>();
            services.AddHttpClient();
            
            services.AddTransient<IHostedService, PingCustomerHostedService>();
            
            services.AddMvc(o =>
                {
                    o.Filters.Add(new Time2Attribute());
                })
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1)
                .ConfigureApplicationPartManager(p =>
                {
                    // Ottengo la directory dove sono presenti i plugin
                    string dir = Path.GetDirectoryName(typeof(Startup).GetTypeInfo().Assembly.Location);
                    dir = Path.Combine(dir, "plugin");
                    if (!Directory.Exists(dir)) return;

                    // Ciclo tutte le dll
                    foreach (string file in Directory.GetFiles(dir, "*.dll"))
                    {
                        // Carico l'assembly
                        Assembly assembly = Assembly.LoadFile(file);

                        // Aggiungo l'application part per i componenti
                        p.ApplicationParts.Add(new AssemblyPart(assembly));
                        // Aggiungo l'application part per le view
                        p.ApplicationParts.Add(new CompiledRazorAssemblyPart(assembly));
                    }
                });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseTimer();

            app.MapWhen(c => 
                System.Net.IPAddress.IsLoopback(c.Connection.RemoteIpAddress)
                && c.Request.Path.StartsWithSegments("/health"), b => b.Run(context => context.Response.WriteAsync("Status: OK")));

            app.Map("/secret", b =>
            {
                b.Use((context, next) =>
                {
                    if (!context.Request.IsHttps)
                    {
                        context.Response.StatusCode = 403;
                        return Task.CompletedTask;
                    }

                    return next();
                });

                b.UseStaticFiles();
            });

            app.UseMvcWithDefaultRoute();
        }
    }
   
}
