﻿using System;
using System.Collections.Generic;

namespace Capitolo5.Scenarios
{
    public static class Scenario12
    {
        /// <summary>
        /// Esempio 5.17
        /// </summary>
        public static void Run()
        {
            var intList = new List<int> { 10, 4, 6, 24, 9, 0, 18 };
            Console.WriteLine($"Il valore massimo è: {Max(intList)}");
        }

        private static T Max<T>(IEnumerable<T> list) where T : IComparable
        {
            bool isFirst = true;
            T res = default(T);
            foreach (T item in list)
            {
                if (isFirst)
                {
                    res = item;
                    isFirst = false;
                }
                if (res.CompareTo(item) < 0)
                    res = item;
            }
            return res;
        }
    }
}