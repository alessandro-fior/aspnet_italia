using Microsoft.AspNetCore.Authorization;

namespace CustomerAuthorization.Authorization
{
    public class SelfOrRoleRequirement : IAuthorizationRequirement
    {
        public SelfOrRoleRequirement(string role)
        {
            Role = role;
        }
        public string Role { get; }
    }

}