﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;
using System.Dynamic;
using System.Data.SqlClient;

namespace ASPItalia.Books.Chapter07
{
    class Program
    {
        static void Main(string[] args)
        {
            // ************************************************************************************
            // Esempio 7.3
            // ************************************************************************************
            try
            {
                var result = Division(5, 0);

                // Questo codice non viene mai eseguito
                Console.WriteLine("Il risultato è {0}", result);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Si è verificato un errore");
            }

            // ************************************************************************************
            // Esempio 7.4
            // ************************************************************************************
            try
            {
                var result = Division(5, 0);

                // Questo codice non viene mai eseguito
                Console.WriteLine("Il risultato è {0}", result);
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Errore: non si può dividere per zero");
            }
            catch (OutOfMemoryException ex)
            {
                Console.WriteLine("Memoria terminata");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Si è verificato un errore generico");
            }

            // ************************************************************************************
            // Esempio 7.5
            // ************************************************************************************
            try
            {
                //throw new SqlException(); // SqlException ha costruttore privato
            }
            catch (SqlException e) when (e.Class > 19)
            {
                Console.WriteLine("Errore fatale");
            }
            catch (SqlException e)
            {
                Console.WriteLine("Errore durante la query");
            }


            // ************************************************************************************
            // Esempio 7.7
            // ************************************************************************************
            StreamReader sr = null;
            try
            {
                sr = new StreamReader(@"c:\test.txt");
                string content = sr.ReadToEnd();
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine("Errore di I/O:\r\n{0}", ex);
            }
            finally
            {
                if (sr != null)
                    sr.Close();
            }

            // ************************************************************************************
            // Esempio 7.9
            // ************************************************************************************
            var myObject = new DisposableObject();

            try
            {
                myObject.SomeMethod();
            }
            finally
            {
                myObject.Dispose();
            }

            // ************************************************************************************
            // Esempio 7.10
            // ************************************************************************************
            using (var myObject1 = new DisposableObject())
            {
                myObject1.SomeMethod();
            }

            // ************************************************************************************
            // Esempio 7.15
            // ************************************************************************************
            // Recupera una reference all'assembly corrente
            Assembly currentAssembly = Assembly.GetExecutingAssembly();

            // Ricerca dei tipi definiti nell'assembly in esecuzione
            foreach (Type type in currentAssembly.GetTypes())
            {
                // Stampa il nome del tipo su console
                Console.WriteLine(type.Name);
            }

            // ************************************************************************************
            // Esempio 7.16
            // ************************************************************************************
            Assembly MsCoreLib = Assembly.GetAssembly(typeof(int));

            Console.WriteLine(MsCoreLib.FullName);
            Console.WriteLine(MsCoreLib.Location);
            Console.WriteLine(MsCoreLib.GetName().Version);

            // ************************************************************************************
            // Esempio 7.17
            // ************************************************************************************
            Type integerType;

            // Utilizzo dell'istruzione typeof
            integerType = typeof(int);

            // Utilizzo del metodo object.GetType() a partire
            // da un'istanza dell'oggetto
            int value = 5;
            integerType = value.GetType();

            // Utilizzo del metodo Type.GetType() a partire
            // dal nome in formato stringa del tipo
            integerType = Type.GetType("System.Int32");

            // ************************************************************************************
            // Esempio 7.19
            // ************************************************************************************
            // Recuperiamo un riferimento al tipo
            Type personType = Type.GetType("ClassLibrary.Person, ClassLibrary");

            // Tramite il costruttore di default (senza parametri)
            // ne costruiamo un'istanza
            ConstructorInfo constructor =
              personType.GetConstructor(Type.EmptyTypes);
            object person = constructor.Invoke(null);

            // Tramite PropertyInfo valorizziamo Name e Age
            PropertyInfo nameProperty =
              personType.GetProperty("Name");
            nameProperty.SetValue(person, "Marco De Sanctis", null);

            PropertyInfo ageProperty =
              personType.GetProperty("Age");
            ageProperty.SetValue(person, 33, null);

            // Visualizziamo su Console il risultato di Person.ToString()
            Console.WriteLine(person.ToString());

            // ************************************************************************************
            // Esempio 7.20
            // ************************************************************************************
            // Creazione di un'istanza di Person
            Type personType1 =
              Type.GetType("ClassLibrary.Person, ClassLibrary");
            dynamic person1 = Activator.CreateInstance(personType1);

            person1.Name = "Marco De Sanctis";
            person1.Age = 33;

            // Visualizziamo su Console il risultato di Person.ToString()
            Console.WriteLine(person1.ToString());

            // ************************************************************************************
            // Esempio 7.21
            // ************************************************************************************
            dynamic myObject2 = new MyDynamicObject();
            Console.WriteLine(myObject2.Property1);
            Console.WriteLine(myObject2.SomeMethod("Test"));

            // ************************************************************************************
            // Esempio 7.22
            // ************************************************************************************
            dynamic myObject3 = new ExpandoObject();

            // Aggiunta di un metodo all'oggetto tramite lambda expression
            // ToText restituisce una string e pertanto è di tipo Func<string>
            myObject3.ToText =
              (Func<string>)(
                () => string.Format("{0} ha {1} anni",
                                    myObject3.Name, myObject3.Age)
              );

            // Aggiunta dinamica di due proprietà
            myObject3.Name = "Marco De Sanctis";
            myObject3.Age = 33;

            // Invocazione del metodo definito in precedenza
            Console.WriteLine(myObject3.ToText());

            // ************************************************************************************
            // Esempio 7.27
            // ************************************************************************************
            var headers = new Dictionary<PropertyInfo, string>();

            // Lettura dei metadati
            foreach (PropertyInfo prop in typeof(Person).GetProperties())
            {
                object[] attributes =
                  prop.GetCustomAttributes(typeof(ReportPropertyAttribute), true);

                if (attributes.Length > 0)
                {
                    ReportPropertyAttribute reportAttribute =
                      (ReportPropertyAttribute)attributes[0];

                    headers.Add(prop, reportAttribute.Header);
                }
            }

            foreach (var item in headers)
            {
                Console.WriteLine("Property: {0} - Header: {1}", item.Key.Name, item.Value);
            }
        }

        public static int Division(int a, int b)
        {
            int result = a / b;

            // in caso di errore questo codice non viene mai eseguito
            Console.WriteLine("Risultato calcolato con successo");

            return result;
        }

        public static void SomeMethod(List<int> items)
        {
            if (items == null)
            {
                // Si solleva l'eccezione indicando il nome dell'argomento non
                // correttamente valorizzato
                throw new ArgumentNullException("items");
            }

            // Codice del metodo qui
        }

    }
}
