﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPItalia.Books.Chapter05
{
    public interface ICovariant<out T>
    {
        T SomeCovariantMethod();
    }

    public interface IContravariant<in T>
    {
        void SomeContravariantMethod(T arg);
    }

}
