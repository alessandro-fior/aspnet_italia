﻿<ServiceContract()>
Public Interface IProducts

    <OperationContract()>
    <WebGet(responseformat:=WebMessageFormat.Json)>
    Function GetAllProducts() As Product()

End Interface
