﻿Imports System.Linq
Imports System.Xml.XPath
Imports System.Xml



Public Class Sample20

    Public Shared Sub Run()

        Dim doc As New XPathDocument("test.xml")
        Dim navigator = doc.CreateNavigator()

        ' Creo il gestore dei namespace
        Dim nsManager As New XmlNamespaceManager(navigator.NameTable)
        ' Associo il prefisso al namespace
        nsManager.AddNamespace("p", "http://schemas.aspitalia.com/book40/products")

        ' Navigo direttamente sull'attributo
        navigator = navigator.SelectSingleNode("/p:products/p:product[1]/@idCategory", nsManager)

        ' Leggo il valore
        Dim idCategory As Integer = navigator.ValueAsInt

        Console.WriteLine(idCategory)
    End Sub

End Class
