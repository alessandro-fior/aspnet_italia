﻿Imports System.Xml
Imports System.IO

Public Class Sample11

    Public Shared Sub Run()

        ' Caricamento del documento
        Dim doc As XDocument = XDocument.Load("test.xml")

        Dim productNs As XNamespace = "http://schemas.aspitalia.com/book40/products"
        Dim dns As XNamespace = "http://schemas.aspitalia.com/book40/details"

        ' Tutti gli attributi idProduct degli elementi product 
        For Each attribute As XAttribute In doc.Root.Elements().Attributes("idProduct")
            Console.WriteLine("idProduct {0}", CStr(attribute))
        Next

        ' Il primo nodo (commento)
        Console.WriteLine("Comment: {0}", doc.Root.Nodes().First())

        ' Il primo elemento product
        Dim product As XElement = doc.Root.Elements(productNs + "product").ElementAt(1)
        Console.WriteLine("Description: {0}", CStr(product.Element(productNs + "description")))

        ' Somma dell'attributo value per tutti
        ' i detail di tipo Weight
        Dim sum As Integer = (From d In doc.Root.Descendants(dns + "detail")
                              Where CStr(d.Attribute("name")) = "Weight"
                              Select CInt(d.Attribute("value"))).Sum()
        Console.WriteLine("Total weight: {0}", sum)


    End Sub

End Class
