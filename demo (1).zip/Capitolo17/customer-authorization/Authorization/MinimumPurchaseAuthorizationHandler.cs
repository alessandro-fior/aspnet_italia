using System;
using System.Linq;
using System.Threading.Tasks;
using CustomerAuthorization.Data;
using CustomerAuthorization.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace CustomerAuthorization.Authorization
{
    public class MinimumPurchaseAuthorizationHandler : AuthorizationHandler<MinimumPurchaseRequirement>
    {

        private readonly ApplicationDbContext context;
        public MinimumPurchaseAuthorizationHandler(ApplicationDbContext context)
        {
            this.context = context;
        }

        protected override async Task HandleRequirementAsync(
            AuthorizationHandlerContext context,
            MinimumPurchaseRequirement requirement)
        {
            //Recuperiamo dal database il valore speso fino a oggi dall'utente
            decimal purchased = await GetAmountForUser(context.User.Identity.Name);

            //Lo confrontiamo con quello minimo indicato nel requirement
            if (purchased < requirement.Minimum)
            {
                //Non ha raggiunto il minimo, l'autorizzazione fallisce
                context.Fail();
            }
            //Altrimenti, l'autorizzazione ha successo
            context.Succeed(requirement);
        }

        private async Task<decimal> GetAmountForUser(string name)
        {
            //TODO: implementa una cache qui
            var totalAmount = await context.Users
            .Where(user => user.UserName == name)
            .SelectMany(user => user.Orders)
            .SumAsync(order => order.Amount);

            return totalAmount;
        }
    }

}