﻿Imports System.Configuration
Imports System.Diagnostics
Imports System.IO
Imports System.Text

Public Class DirectoryWatcher

    Friend Property Path As String = "C:\Temp\"
    Friend Filter As String = "*.*"
    Friend Property IsRecursive As Boolean = False

    Protected Overrides Sub OnStart(ByVal args() As String)
        Me.GetConfiguration()

        FileWatcher.Path = Me.Path
        FileWatcher.Filter = Me.Filter
        FileWatcher.IncludeSubdirectories = Me.IsRecursive

        FileWatcher.NotifyFilter = NotifyFilters.LastAccess Or NotifyFilters.LastWrite Or NotifyFilters.FileName Or NotifyFilters.DirectoryName
        FileWatcher.EnableRaisingEvents = True
    End Sub

    Protected Overrides Sub OnStop()
        FileWatcher.EnableRaisingEvents = False
    End Sub

    Protected Overrides Sub OnPause()
        FileWatcher.EnableRaisingEvents = False
    End Sub

    Protected Overrides Sub OnContinue()
        FileWatcher.NotifyFilter = NotifyFilters.LastAccess Or NotifyFilters.LastWrite Or NotifyFilters.FileName Or NotifyFilters.DirectoryName
        FileWatcher.EnableRaisingEvents = True
    End Sub

    Protected Overrides Sub OnShutdown()
        FileWatcher.EnableRaisingEvents = False
    End Sub

    Private Sub OnFileChanged(ByVal sender As Object, ByVal e As FileSystemEventArgs) Handles FileWatcher.Changed
        Dim builder As New StringBuilder()
        builder.Append(String.Concat("Base directory: '", Me.Path, "'.", vbCrLf))
        builder.Append(String.Concat("Path: '", e.FullPath, "'.", vbCrLf))
        builder.Append(String.Concat("Activity: item '", e.Name, "' changed."))

        Dim message As String = builder.ToString()
        EventLog.WriteEntry(Me.ServiceName, message)
    End Sub

    Private Sub OnFileCreated(ByVal sender As Object, ByVal e As FileSystemEventArgs) Handles FileWatcher.Created
        Dim builder As New StringBuilder()
        builder.Append(String.Concat("Base directory: '", Me.Path, "'.", vbCrLf))
        builder.Append(String.Concat("Path: '", e.FullPath, "'.", vbCrLf))
        builder.Append(String.Concat("Activity: item '", e.Name, "' created."))

        Dim message As String = builder.ToString()
        EventLog.WriteEntry(Me.ServiceName, message)
    End Sub

    Private Sub OnFileDeleted(ByVal sender As Object, ByVal e As FileSystemEventArgs) Handles FileWatcher.Deleted
        Dim builder As New StringBuilder()
        builder.Append(String.Concat("Base directory: '", Me.Path, "'.", vbCrLf))
        builder.Append(String.Concat("Path: '", e.FullPath, "'.", vbCrLf))
        builder.Append(String.Concat("Activity: item '", e.Name, "' deleted."))

        Dim message As String = builder.ToString()
        EventLog.WriteEntry(Me.ServiceName, message)
    End Sub

    Private Sub OnFileRenamed(ByVal sender As Object, ByVal e As RenamedEventArgs) Handles FileWatcher.Renamed
        Dim builder As New StringBuilder()
        builder.Append(String.Concat("Base directory: '", Me.Path, "'.", vbCrLf))
        builder.Append(String.Concat("Path: '", e.OldFullPath, "'.", vbCrLf))
        builder.Append(String.Concat("Activity: item '", e.OldName, "' renamed.", vbCrLf))
        builder.Append(String.Concat("New name: '", e.Name, "'."))

        Dim message As String = builder.ToString()
        EventLog.WriteEntry(Me.ServiceName, message)
    End Sub

    Private Sub GetConfiguration()
        If Not ConfigurationManager.AppSettings.Get("path") Is Nothing Then
            Me.Path = ConfigurationManager.AppSettings.Get("path")
        End If

        If Not ConfigurationManager.AppSettings.Get("filter") Is Nothing Then
            Me.Filter = ConfigurationManager.AppSettings.Get("filter")
        End If

        If Not ConfigurationManager.AppSettings.Get("isRecursive") Is Nothing Then
            Dim recursive As Boolean = False
            If Boolean.TryParse(ConfigurationManager.AppSettings.Get("isRecursive"), recursive) Then
                Me.IsRecursive = recursive
            End If
        End If
    End Sub

End Class
