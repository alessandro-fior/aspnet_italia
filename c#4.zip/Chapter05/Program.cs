﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.IO;

namespace ASPItalia.Books.Chapter05
{
    class Program
    {
        static void Main(string[] args)
        {
            // ************************************************************************************
            // Esempio 5.1
            // ************************************************************************************
            int[] myIntArray = { 1, 5, 2, 3, 6 };

            int[] anotherArray = new int[5];
            anotherArray[3] = 2;

            var length = myIntArray.Length;  // Recupera il numero di elementi
            var index =
              Array.IndexOf(myIntArray, 2);  // Indice di un elemento

            var item = myIntArray[3];        // Ritorna il quarto elemento

            Array.Sort(myIntArray);          // Ordina gli elementi

            Array.Resize(ref myIntArray, 7); // Modifica il numero di elementi
            myIntArray[6] = 11;

            // ************************************************************************************
            // Esempio 5.2
            // ************************************************************************************
            var sampleList = new ArrayList(); // Creazione di un arraylist
            sampleList.Add(2);                // Aggiunta di elementi
            sampleList.Add(5);

            object value = sampleList[1];     // Ritorna il secondo elemento

            int count = sampleList.Count;     // Recupera il numero di elementi

            sampleList.Remove(2);             // Rimuove l'intero 2
            sampleList.Clear();               // Rimuove tutti gli elementi

            // ************************************************************************************
            // Esempio 5.3
            // ************************************************************************************
            for (int index1 = 0; index1 < sampleList.Count - 1; index1++)
            {
                Console.WriteLine(sampleList[index1]);
            }

            foreach (object element in sampleList)
            {
                Console.WriteLine(element);
            }

            // ************************************************************************************
            // Esempio 5.4
            // ************************************************************************************
            var myDictionary = new Hashtable();  // Creazione dell'HashTable

            myDictionary.Add("someIntValue", 5); // Aggiunta di elementi
            myDictionary.Add(
              "someClass", new StringWriter());
            myDictionary.Add(
              DateTime.Today, "Today's string");

            object value1 =
                myDictionary["someClass"];       // Recupera elemento dalla chiave

            myDictionary.Remove("someClass");    // Rimuove un elemento

            int count1 = myDictionary.Count;      // Recupera il numero di elementi
            myDictionary.Clear();                // Rimuove tutti gli elementi

            // ************************************************************************************
            // Esempio 5.5
            // ************************************************************************************
            // Enumerazione di tutte le coppie chiave-valore
            foreach (DictionaryEntry item1 in myDictionary)
            {
                Console.WriteLine(item1.Key + " " + item1.Value);
            }

            // Enumerazione di tutte le chiavi
            foreach (object key in myDictionary.Keys)
            {
                Console.WriteLine(key);
            }

            // Enumerazione di tutti i valori
            foreach (object value2 in myDictionary.Values)
            {
                Console.WriteLine(value2);
            }

            // ************************************************************************************
            // Esempio 5.6
            // ************************************************************************************
            Console.WriteLine("---Stack---");
            var myStack = new Stack();
            myStack.Push("Marco");
            myStack.Push(5);
            myStack.Push(new object());

            Console.WriteLine(myStack.Pop());
            Console.WriteLine(myStack.Pop());

            Console.WriteLine("---Queue---");
            var myQueue = new Queue();
            myQueue.Enqueue("Marco");
            myQueue.Enqueue(5);
            myQueue.Enqueue(new object());

            Console.WriteLine(myQueue.Dequeue());
            Console.WriteLine(myQueue.Dequeue());

            // ************************************************************************************
            // Esempio 5.7
            // ************************************************************************************
            var dateList = new ArrayList();
            dateList.Add(DateTime.Now);
            dateList.Add(new DateTime(2000, 1, 10));
            dateList.Add(DateTime.Today.AddYears(-1));

            DateTime firstItem = (DateTime)dateList[0];

            // ************************************************************************************
            // Esempio 5.8
            // ************************************************************************************
            var list = new ArrayList();

            list.Add(10);
            list.Add("Some string");
            list.Add(DateTime.Now);
            list.Add(new ArrayList());
            list.Add(new System.Globalization.CultureInfo("en-US"));

            try
            {
                DateTime secondItem = (DateTime)list[0];
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            // ************************************************************************************
            // Esempio 5.9
            // ************************************************************************************
            var strings = new List<string>();    // Inizializzazione di List<T>
            strings.Add("Marco De Sanctis");     // Possiamo aggiungere solo string
            strings.Add("C# 4.0");
            strings.Insert(0, "Primo elemento");

            var index2 = strings.IndexOf(
              "Marco De Sanctis");               // Ritorna 1

            var mySubstring =
              strings[0].Substring(5);           // Già string: cast non necessario

            // ************************************************************************************
            // Esempio 5.10
            // ************************************************************************************
            var holidays = new Dictionary<string, DateTime>();

            holidays.Add("Natale", new DateTime(2010, 12, 25));
            holidays.Add("Capodanno", new DateTime(2010, 1, 1));
            holidays.Add("Compleanno", new DateTime(2010, 7, 10));

            DateTime vigiliaCompleanno = holidays["Compleanno"].AddDays(-1);

            // ************************************************************************************
            // Esempio 5.14
            // ************************************************************************************
            int myInt = default(int);
            Nullable<int> nullableInt = default(Nullable<int>);

            Console.WriteLine(myInt);       // Stampa 0
            Console.WriteLine(nullableInt); // Stampa una riga vuota

            myInt = 5;
            nullableInt = 7;                // Assegnazione di un valore intero

            var res = myInt + nullableInt;  // res è di tipo Nullable<int>

            if (nullableInt.HasValue)       // Verifica presenza di un valore
            {
                var value2 = nullableInt.Value; // Contiene il valore int
            }
        }
    }

}
