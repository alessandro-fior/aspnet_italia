using System;

namespace UiAndApiAuth.Models.Configuration
{
    public class JwtToken {
        public string Issuer { get; set; }
        public string Audience { get; set; }
        public string SigningKey { get; set; } 
        public string Algorithm { get; set; }
        public TimeSpan Expiration { get; set; }
        public TimeSpan ClockSkew { get; set; }
    }
}