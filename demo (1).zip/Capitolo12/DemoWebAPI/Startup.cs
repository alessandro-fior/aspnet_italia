﻿using DemoWebAPI.Extensions;
using DemoWebAPI.Models;
using DemoWebAPI.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.IO;
using System.Linq;
using System.Reflection;

namespace DemoWebAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // aggiunge il supporto per MVC e agli input/output formatter
            services.AddMvc(options =>
            {
                options.ReturnHttpNotAcceptable = true;

                options.OutputFormatters.Add(new XmlDataContractSerializerOutputFormatter());
                options.InputFormatters.Add(new XmlDataContractSerializerInputFormatter(options));
            })
            // aggiunge il webhook per github
            .AddGitHubWebHooks()
            .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            // aggiunge i servizi per repository e url helper
            services.AddTransient<ICustomerRepository, CustomerRepository>();
            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            services.AddScoped<IUrlHelper>(factory =>
            {
                var actionContext = factory.GetService<IActionContextAccessor>()
                                           .ActionContext;
                return new UrlHelper(actionContext);
            });
            
            // aggiunge il versionamento
            services.AddApiVersioning(config =>
            {
                config.AssumeDefaultVersionWhenUnspecified = true;
                config.DefaultApiVersion = new ApiVersion(1, 0);
                config.ApiVersionReader = new Microsoft.AspNetCore.Mvc.Versioning.QueryStringApiVersionReader("api-version");
            });

            // aggiunge la documentazione con swagger
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "Documentazione WebAPI ASP.NET Core",
                    Description = "Esempio di come si fa la documentazione con ASP.NET Core",
                    TermsOfService = "None",
                    Contact = new Contact
                    {
                        Name = "ASPItalia.com",
                        Email = string.Empty,
                        Url = "https://aspitalia.com"
                    }
                });

                c.SwaggerDoc("v2", new Info
                {
                    Version = "v2",
                    Title = "Documentazione WebAPI ASP.NET Core",
                    Description = "Esempio di come si fa la documentazione con ASP.NET Core",
                    TermsOfService = "None",
                    Contact = new Contact
                    {
                        Name = "ASPItalia.com",
                        Email = string.Empty,
                        Url = "https://aspitalia.com"
                    }
                });

                // Questo è un hack, non documentato nel libro per motivi di brevità e poiché non è determinante al corretto funzionamento delle API stesse.
                // Questo filtro va implementato per la parte di Swagger UI poiché altrimenti non sarebbe possibile
                // effettuare le chiamate ad una API che è implementata in versioni differenti (ad esempio v1.0, v.2.0)
                // Il risultato, senza questo filtro, infatti, sarebbe che verrebbe sempre richiamata la versione di default
                // prevista da ASP.NET Core se la chiamata viene eseguita all'interno di Swagger UI, poiché Swagger non è in grado
                // di aggiungere in maniera autonoma il parametro di query string "api-version" che utilizziamo per determinare la versione. 
                // Questa chiamata permette, appunto, di aggiungere il parametro obbligatorio "api-version" nella generazione del file swagger.json.
                // Ovviamente questo non presenta un problema qualora la chiamata venga effettuata da un client, 
                // in quanto è il client a dover specificare il parametro
                c.OperationFilter<ApiVersionOperationFilter>();

                c.DocInclusionPredicate((docName, apiDesc) =>
                {
                    // filtro delle API per versione
                    var versions = apiDesc.ControllerAttributes()
                        .OfType<ApiVersionAttribute>()
                        .SelectMany(attr => attr.Versions);
                    
                    return versions.Any(version => $"v{version.MajorVersion}" == docName);
                });
                
                // aggiunta delle API dal file XML dei commenti
                var xmlFile = $"{Assembly.GetEntryAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);
            });            
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            // gestione degli errori e delle eccezioni con errore 500
            app.UseExceptionHandler(options =>
            {
                options.Run(async context =>
                {
                    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
                    await context.Response.WriteAsync("Qualcosa è andato storto.");
                });
            });

            // configurazione di automapper
            AutoMapper.Mapper.Initialize(config =>
            {
                config.CreateMap<Customer, CustomerForRead>()
                      .ForMember(o => o.Name, i => i.MapFrom(m => $"{m.FirstName} {m.LastName}"))
                      .ForMember(o => o.Age, i => i.MapFrom(m => m.DateOfBirth.GetAge()));

                config.CreateMap<Customer, CustomerForReadV2>()
                      .ForMember(o => o.Name, i => i.MapFrom(m => $"{m.FirstName} {m.LastName}"))
                      .ForMember(o => o.Age, i => i.MapFrom(m => m.DateOfBirth.GetAge()));

                config.CreateMap<CustomerForCreate, Customer>();
                config.CreateMap<CustomerForUpdate, Customer>();
                config.CreateMap<Customer, CustomerForUpdate>();
            });

            // aggiunta degli static file
            app.UseStaticFiles();

            // aggiunta di swagger
            app.UseSwagger();

            // aggiunta della UI di swagger
            // documentazione raggiungibile tramite url /swagger
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "V1 Docs");
                c.SwaggerEndpoint("/swagger/v2/swagger.json", "V2 Docs");
            });

            app.UseMvc();
        }
    }
}