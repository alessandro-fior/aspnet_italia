﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace DemoWebAPI.Controllers
{
    [Route("api/exception")]
    public class ExceptionController : Controller
    {
        /// <summary>
        /// Genera una eccezione
        /// </summary>
        /// <returns>N/A</returns>
        [HttpGet]
        public IActionResult GenerateException()
        {
            throw new NotImplementedException("Questo metodo è finto.");
        }
    }
}