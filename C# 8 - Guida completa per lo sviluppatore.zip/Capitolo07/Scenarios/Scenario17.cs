﻿using Microsoft.CodeAnalysis.CSharp;
using System;

namespace Capitolo7.Scenarios
{
    public static class Scenario17
    {
        /// <summary>
        /// Esempio 7.29
        /// </summary>
        public static void Run()
        {
            var syntaxTree = CSharpSyntaxTree.ParseText(@"
                public class Test
                {
                    public string MyProperty { get; set; }
                }"
            );

            var root = syntaxTree.GetRoot();
            var nodes = root.DescendantNodes();

            foreach (var node in nodes)
                Console.WriteLine($"{node.Kind()} - {node.GetText()}");
        }
    }
}