﻿namespace ViewsLocalization.Validation
{
    public class ErrorMessages
    {
    }
}
