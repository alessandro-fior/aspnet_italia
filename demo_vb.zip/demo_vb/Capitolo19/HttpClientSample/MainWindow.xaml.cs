﻿using DataModel;
using System;
using System.Net.Http;
using System.Text;
using System.Windows;
using Newtonsoft.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;

namespace HttpClientSample
{
  public partial class MainWindow : Window
  {
    private StringBuilder log = new StringBuilder();
    private Uri baseUri = new Uri("http://localhost:18974/");
    private CancellationTokenSource cts = new CancellationTokenSource();

    public MainWindow()
    {
      InitializeComponent();
      this.Loaded += MainWindow_Loaded;
    }

    private void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
      TextBox1.Text = "api/products/5";
    }

    private async void ButtonGet_Click(object sender, RoutedEventArgs e)
    {
      //using (var client = new HttpClient())
      //{
      //  try
      //  {
      //    client.BaseAddress = new Uri("http://localhost:18974/");
      //    client.MaxResponseContentBufferSize = 1024;

      //    using (HttpResponseMessage response = await client.GetAsync("api/products/1", cts.Token))
      //    {
      //      log.AppendLine(response.RequestMessage.ToString());
      //      log.AppendLine(response.Version.ToString());
      //      log.AppendLine(response.StatusCode.ToString());

      //      if (response.IsSuccessStatusCode)
      //      {
      //        var content = response.Content;
      //        foreach (var item in content.Headers)
      //          log.AppendLine(item.Key + " " + item.Value.FirstOrDefault());

      //        string data = await content.ReadAsStringAsync();
      //        log.AppendLine(data);
      //      }
      //      else
      //      {
      //        log.AppendLine(response.ReasonPhrase);
      //        response.EnsureSuccessStatusCode();
      //      }
      //    }
      //  }
      //  catch (TaskCanceledException)
      //  {
      //  }
      //  catch (Exception ex)
      //  {
      //  }
      //  finally
      //  {
      //    log.AppendLine("------------");
      //    TextBox2.Text = log.ToString();
      //  }
      //}




      using (var client = new HttpClient())
      {
        client.CancelPendingRequests();

        try
        {
          client.BaseAddress = baseUri;
          client.MaxResponseContentBufferSize = 1024;

          using (HttpResponseMessage response = await client.GetAsync(TextBox1.Text, cts.Token))
          {
            if (response.IsSuccessStatusCode)
            {
              Product product = await response.Content.ReadAsAsync<Product>();

              log.AppendLine(product.ToString());
            }
            else
            {
              log.AppendLine(response.ReasonPhrase);

              response.EnsureSuccessStatusCode();
            }
          }

          string data = await client.GetStringAsync(TextBox1.Text);
          log.AppendLine(data);
        }
        catch (TaskCanceledException)
        {
          log.AppendLine("--Cancelled-");
        }
        catch (Exception ex)
        {
          log.AppendLine(ex.ToString());
        }
        finally
        {
          log.AppendLine("------------");
          TextBox2.Text = log.ToString();
        }
      }
    }

    private async void ButtonPost_Click(object sender, RoutedEventArgs e)
    {
      //using (var client = new HttpClient())
      //{
      //  client.BaseAddress = new Uri("http://localhost:18974/");
      //  string newData = @"{'Id':22,
      //                'Name':'Product22',
      //                'Price':22.0,
      //                'Category':'Category22'}";
      //  HttpContent contentPost = new StringContent(newData,
      //                                              Encoding.UTF8,
      //                                              "application/json");
      //  using (HttpResponseMessage response =
      //         await client.PostAsync("api/products", contentPost))
      //  {
      //    if (response.IsSuccessStatusCode)
      //    {
      //      Product product = await response.Content.ReadAsAsync<Product>();
      //      log.AppendLine(product.ToString());
      //    }
      //  }
      //}

      using (var client = new HttpClient())
      {
        try
        {
          client.BaseAddress = baseUri;

          var product = JsonConvert.DeserializeObject<Product>(TextBox2.Text);

          using (var response = await client.PostAsJsonAsync<Product>("api/products", product, cts.Token))
          {
            if (response.IsSuccessStatusCode)
            {
              Uri productUrl = response.Headers.Location;

              log.AppendLine(product.ToString());

              log.AppendLine(productUrl.ToString());
            }
            else
            {
              log.AppendLine(response.ReasonPhrase);
              response.EnsureSuccessStatusCode();
            }
          }
        }
        catch (Exception ex)
        {
          log.AppendLine(ex.ToString());
        }
        finally
        {
          log.AppendLine("------------");
          TextBox2.Text = log.ToString();
        }
      }
    }

    private async void ButtonPut_Click(object sender, RoutedEventArgs e)
    {
      using (var client = new HttpClient())
      {
        try
        {
          client.BaseAddress = baseUri;

          using (HttpResponseMessage response = await client.GetAsync(TextBox1.Text, cts.Token))
          {
            if (response.IsSuccessStatusCode)
            {
              Product product = await response.Content.ReadAsAsync<Product>(cts.Token);

              product.Name = TextBox2.Text;
              using (var response2 = await client.PutAsJsonAsync(TextBox1.Text, product, cts.Token))
              {
                Product product2 = await response.Content.ReadAsAsync<Product>();
                log.AppendLine(product2.ToString());
              }
            }
            else
            {
              log.AppendLine(response.ReasonPhrase);
              response.EnsureSuccessStatusCode();
            }
          }
        }
        catch (Exception ex)
        {
          log.AppendLine(ex.ToString());
        }
        finally
        {
          log.AppendLine("------------");
          TextBox2.Text = log.ToString();
        }
      }
    }

    private async void ButtonDelete_Click(object sender, RoutedEventArgs e)
    {
      using (var client = new HttpClient())
      {
        try
        {
          client.BaseAddress = baseUri;

          using (var response = await client.DeleteAsync(TextBox1.Text, cts.Token))
          {
            if (response.IsSuccessStatusCode)
            {
              Product product = await response.Content.ReadAsAsync<Product>(cts.Token);

              log.AppendLine(product.ToString());
            }
            else
            {
              log.AppendLine(response.ReasonPhrase);
              response.EnsureSuccessStatusCode();
            }
          }
        }
        catch (Exception ex)
        {
          log.AppendLine(ex.ToString());
        }
        finally
        {
          log.AppendLine("------------");
          TextBox2.Text = log.ToString();
        }
      }
    }

    private void ButtonStop_Click(object sender, RoutedEventArgs e)
    {
      cts.Cancel();
      cts.Dispose();

      cts = new CancellationTokenSource();
    }
  }
}
