﻿
Partial Class _04_ContentPage
    Inherits System.Web.UI.Page

End Class
