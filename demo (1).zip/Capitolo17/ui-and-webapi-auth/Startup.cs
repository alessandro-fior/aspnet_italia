﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using UiAndApiAuth.Data;
using UiAndApiAuth.Models;
using UiAndApiAuth.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using UiAndApiAuth.Models.Configuration;
using UiAndApiAuth.Middlewares;
using Swashbuckle.AspNetCore.Swagger;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace UiAndApiAuth
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<JwtToken>(Configuration.GetSection("JwtToken"));
            services.AddSingleton<IJwtTokenProvider, JwtTokenProvider>();

            services.AddAuthentication()
             .AddJwtBearer(options => {
                var tokenProvider = services.BuildServiceProvider().GetService<IJwtTokenProvider>();
                options.TokenValidationParameters = tokenProvider.GetTokenValidationParameters();
            });

            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlite(Configuration.GetConnectionString("DefaultConnection")));

            services.AddDefaultIdentity<ApplicationUser>()
                .AddEntityFrameworkStores<ApplicationDbContext>();

            // Add application services.
            services.AddTransient<IEmailSender, EmailSender>();

            services.AddSwaggerGen(config =>
            {
                config.DocumentFilter<DocumentApiFilter>();
                config.SwaggerDoc("v1", new Info { Title = "My API", Version = "v1" });
                config.AddSecurityDefinition("JWT Bearer Token", new ApiKeyScheme()
                {
                    Description = "Nella casella sottostante digita <code>Bearer</code> seguito da uno spazio e dal token ottenuto da /api/Token. Esempio: <strong><code>Bearer eyJhbGci...</code></strong><br><br><br><br>",
                    Name = "Authorization",
                    In = "header",
                    Type = "apiKey"
                });
            });
            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();
            app.UseMiddleware<JwtTokenMiddleware>();
            app.UseAuthentication();

            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.RoutePrefix = "apidocs";
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
            });

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
