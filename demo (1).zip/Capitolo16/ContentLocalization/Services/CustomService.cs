﻿using Microsoft.Extensions.Localization;

namespace ContentLocalization.Services
{
    public class CustomService : ICustomService
    {
        private readonly IStringLocalizer localizer;

        public CustomService(IStringLocalizer<CustomService> localizer)
        {
            this.localizer = localizer;
        }

        public string SendReply(string key)
        {
            // recupera il valore corrispondente alla chiave nel file di risorse
            var localizedValue = localizer.GetString(key);

            // se la risorsa non è stata trovata, prova a ricercare il valore
            // associato alla chiave NotFound
            if (localizedValue.ResourceNotFound)
                return localizer.GetString("NotFound");

            // ritorna il valore localizzato
            // c'è un operatore implicito che ne fa il ToString, pertanto è sicuro
            return localizedValue;
        }
    }
}