﻿using System.Xml;
using System;
using System.IO;

public class Sample7
{
    public static void Run()
    {
        // Impostazioni di caricamento del file
        var settings = new XmlReaderSettings
        {
            IgnoreComments = true,
            IgnoreProcessingInstructions = true,
            IgnoreWhitespace = true
        };

        // Using per chiudere il file e liberarlo
        using XmlReader reader = XmlReader.Create(Path.Combine(Environment.CurrentDirectory, "test.xml"), settings);

        // Leggo il prossimo nodo dallo stream
        while (reader.Read())
        {
            // Stampo nome del nodo (attributo o elemento) e tipo
            Console.WriteLine($"LocalName: {reader.LocalName} - NodeType: {reader.NodeType}");

            // Intercetto l'inizio di un nuovo elemento
            if (reader.NodeType == XmlNodeType.Element)
            {
                // Identifico in che elemento mi trovo
                switch (reader.LocalName)
                {
                    case "description":
                        // Controllo che l'elemento non sia vuoto
                        if (!reader.IsEmptyElement)
                            Console.WriteLine($"Description: {reader.ReadElementContentAsString()}");
                        break;
                    case "product":
                        // Mi sposto sull'attributo idProduct
                        if (reader.MoveToAttribute("idProduct"))
                            // Se è andato a buon fine, leggo il valore
                            Console.WriteLine($"idProduct: {reader.Value}");
                        break;
                }
            }
        }
    }

}