﻿Imports NorthwindModel

Partial Class _05_ListControl
    Inherits System.Web.UI.Page


	Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
		Using entities = New NorthwindEntities()
			Dim customers = entities.Customers.OrderBy(Function(c As Customer) c.CompanyName)
			DropDownList1.DataSource = customers
			DropDownList1.DataBind()
		End Using
	End Sub
End Class
