﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Collections.Concurrent;

namespace ASPItalia.Books.Chapter09
{
    class Program
    {
        static void Main(string[] args)
        {
            // ************************************************************************************
            // Esempio 9.1
            // ************************************************************************************
            Thread myThread = new Thread(() =>
            {
                Console.WriteLine("MyThread è iniziato");
                Thread.Sleep(1000);
                Console.WriteLine("MyThread è terminato");
            });

            // Esecuzione di myThread
            myThread.Start();

            Thread.Sleep(500);
            Console.WriteLine("Main Thread");

            // ************************************************************************************
            // Esempio 9.2
            // ************************************************************************************
            string someVariable = "Marco De Sanctis";

            var workerThread = new Thread((o) =>
            {
                Console.WriteLine("Saluti da: {0}", o);
            });

            workerThread.Start(someVariable);

            // ************************************************************************************
            // Esempio 9.3
            // ************************************************************************************
            string someVariable1 = "Marco De Sanctis";

            var workerThread1 = new Thread(() =>
            {
                Thread.Sleep(500);
                Console.WriteLine("Saluti da: {0}", someVariable1);
            });

            workerThread1.Start();
            someVariable1 = "Daniele Bochicchio";

            // ************************************************************************************
            // Esempio 9.4
            // ************************************************************************************
            var list = new List<Thread>();

            // Qui creiamo ed eseguiamo cinque worker thread
            for (int index = 0; index < 5; index++)
            {
                var myThread1 = new Thread((currentIndex) =>
                {
                    Console.WriteLine("Thread {0} è iniziato", currentIndex);
                    Thread.Sleep(500);
                    Console.WriteLine("Thread {0} è terminato", currentIndex);
                });

                myThread1.Start(index);
                list.Add(myThread1);
            }

            // Attesa del completamento di ognuno dei worker thread
            foreach (Thread thread in list)
            {
                thread.Join();
            }

            Console.WriteLine("Esecuzione di tutti i thread terminata");

            // ************************************************************************************
            // Esempio 9.5
            // ************************************************************************************
            var workerThread2 = new Thread(() =>
            {
                Console.WriteLine("Inizio di un thread molto lungo");
                Thread.Sleep(5000);
                Console.WriteLine("Termine worker thread");
            });

            workerThread2.Start();
            workerThread2.Join(500);

            // Se il worker thread è ancora in esecuzione lo si cancella
            if (workerThread2.ThreadState != System.Threading.ThreadState.Stopped)
            {
                workerThread2.Abort();
            }

            Console.WriteLine("Termine applicazione");

            // ************************************************************************************
            // Esempio 9.6
            // ************************************************************************************
            ThreadPool.QueueUserWorkItem((o) =>
            {
                Console.WriteLine("Inizio worker thread");
                Thread.Sleep(1000);
                Console.WriteLine("Termine worker thread");
            });

            Thread.Sleep(500);
            Console.WriteLine("Metodo main");
            Thread.Sleep(2000);

            // ************************************************************************************
            // Esempio 9.7
            // ************************************************************************************
            string someVariable2 = "Marco De Sanctis";

            ThreadPool.QueueUserWorkItem((argument) =>
            {
                Thread.Sleep(500);
                Console.WriteLine("Saluti da: {0}", argument);
            }, someVariable2);

            someVariable2 = "Daniele Bochicchio";
            Thread.Sleep(2000);

            // ************************************************************************************
            // Esempio 9.8
            // ************************************************************************************
            var list1 = new List<ManualResetEvent>();
            try
            {
                for (int index = 0; index < 5; index++)
                {
                    // Creazione del waitHandle per il task corrente
                    var waitHandle = new ManualResetEvent(false);
                    list1.Add(waitHandle);

                    // Oggetto da passare al task accodato
                    var state = new Tuple<int, ManualResetEvent>(
                      index, waitHandle);

                    ThreadPool.QueueUserWorkItem((untypedState) =>
                    {
                        // WaitCallback accetta un object, pertanto 
                        // è necessario un cast
                        var taskState = (Tuple<int, ManualResetEvent>)untypedState;

                        // Visualizzazione dei messaggi su console
                        Console.WriteLine("Thread {0} è iniziato", taskState.Item1);
                        Thread.Sleep(500);
                        Console.WriteLine("Thread {0} è terminato", taskState.Item1);

                        // Segnalazione del termine dell'esecuzione del task
                        // utilizzando il Set del ManualResetEvent
                        taskState.Item2.Set();
                    }, state);
                }

                // Attesa che tutti i ManualResetEvent siano in stato Set
                foreach (ManualResetEvent handle in list1)
                {
                    handle.WaitOne();
                }
            }
            finally
            {
                foreach (ManualResetEvent handle in list1)
                {
                    handle.Dispose();
                }
            }

            Console.WriteLine("Esecuzione terminata");

            // ************************************************************************************
            // Esempio 9.9
            // ************************************************************************************
            var method = new SomeDelegate((parameter) =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Ciao da {0}", parameter);
                return parameter.Length;
            });

            method.BeginInvoke("Marco De Sanctis", null, null);
            Console.WriteLine("Esecuzione avviata");
            Thread.Sleep(2000);

            // ************************************************************************************
            // Esempio 9.10
            // ************************************************************************************
            var method1 = new SomeDelegate((parameter) =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Ciao da {0}", parameter);
                return parameter.Length;
            });

            IAsyncResult asyncResult =
              method1.BeginInvoke("Marco De Sanctis", null, null);

            Console.WriteLine("Esecuzione avviata");

            // Attesa del termine dell'operazione e recupero risultato
            int result = method1.EndInvoke(asyncResult);

            Console.WriteLine("Il risultato è {0}", result);

            // ************************************************************************************
            // Esempio 9.11
            // ************************************************************************************
            var method2 = new SomeDelegate((parameter) =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Ciao da {0}", parameter);
                return parameter.Length;
            });

            IAsyncResult asyncResult1 =
              method2.BeginInvoke("Marco De Sanctis", null, null);

            Console.WriteLine("Esecuzione avviata");

            // Polling sul WaitHandle
            while (!asyncResult1.IsCompleted)
            {
                Console.WriteLine("Esecuzione in corso...");
                asyncResult1.AsyncWaitHandle.WaitOne(200);
            }

            // Attesa del termine dell'operazione e recupero risultato
            int result1 = method2.EndInvoke(asyncResult1);

            Console.WriteLine("Il risultato è {0}", result1);

            // ************************************************************************************
            // Esempio 9.13
            // ************************************************************************************
            var method3 = new SomeDelegate((parameter) =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Ciao da {0}", parameter);
                return parameter.Length;
            });

            method3.BeginInvoke("Marco De Sanctis", MyCallback, method3);

            Console.WriteLine("Esecuzione avviata");

            // ************************************************************************************
            // Esempio 9.14
            // ************************************************************************************
            // Costruzione di un semplice task
            var simpleTask = Task.Factory.StartNew(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Ciao da simpleTask");
            });

            // Costruzione di un task con parametro in input
            var parameterTask = Task.Factory.StartNew((name) =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Ciao da parameterTask, {0}", name);
            }, "Marco De Sanctis");

            // Costruzione di un task che ritorna un risultato
            var resultTask = Task.Factory.StartNew((inputValue) =>
              PerformSomeLongCalulation(inputValue), 5000D);
            
            // ************************************************************************************
            // Esempio 9.15
            // ************************************************************************************
            // Creazione esplicita di un Task
            var resultTask1 = new Task((inputValue) =>
              PerformSomeLongCalulation(inputValue), 5000D);

            // Esecuzione
            resultTask1.Start();

            // ************************************************************************************
            // Esempio 9.16
            // ************************************************************************************
            resultTask1 = Task.Factory.StartNew((inputValue) => 
                PerformSomeLongCalulation(inputValue), 5000D);

            // .. altro codice qui ..

            // Determinazione del risultato
            Console.WriteLine("Il risultato è: {0}", resultTask.Result);

            // ************************************************************************************
            // Esempio 9.17
            // ************************************************************************************
            // Attesa senza timeout
            var myTask = Task.Factory.StartNew(SomeMethod);
            myTask.Wait();

            // Attesa con timeout di un secondo
            myTask = Task.Factory.StartNew(SomeMethod);
            myTask.Wait(1000);

            // Attesa conclusione di uno tra myTask e anotherTask
            myTask = Task.Factory.StartNew(SomeMethod);
            var anotherTask = Task.Factory.StartNew(SomeMethod);
            Task.WaitAny(myTask, anotherTask);

            // Attesa conclusione di una lista di Task, con timeout di 2 secondi
            List<Task> taskList = GetTaskList();
            Task.WaitAll(taskList.ToArray(), 2000);

            // ************************************************************************************
            // Esempio 9.18
            // ************************************************************************************
            var problematicTask = Task.Factory.StartNew(() =>
            {
                throw new ApplicationException("Errore!");
            });

            try
            {
                problematicTask.Wait();
            }
            catch (AggregateException ex)
            {
                Console.WriteLine("Il task ha sollevato la seguente eccezione:");
                Console.WriteLine(ex.InnerException);
            }
            Console.ReadLine();
            // ************************************************************************************
            // Esempio 9.19
            // ************************************************************************************
            var compositeTask = Task.Factory.StartNew(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Primo task");
            }).ContinueWith((task) =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Secondo task");
            });

            // Accodamento di una funzione
            var resultTask2 = compositeTask.ContinueWith((task) =>
            {
                string result2 = "Funzione del terzo task";
                Console.WriteLine(result2);
                return result2;
            });

            Console.WriteLine("Il risultato è: {0}", resultTask2.Result);

            // ************************************************************************************
            // Esempio 9.20
            // ************************************************************************************
            taskList = GetTaskList();

            // Task da eseguire al termine di tutti quelli contenuti in tasklist
            var finalTask = Task.Factory.ContinueWhenAll(
              taskList.ToArray(),
              (tl) => Console.WriteLine("Tutti i task completati con successo"));

            // ************************************************************************************
            // Esempio 9.21
            // ************************************************************************************
            var outerTask = Task.Factory.StartNew(() =>
            {
                var innerTask = Task.Factory.StartNew(() =>
                {
                    Thread.Sleep(2000);
                    Console.WriteLine("Nested task");
                });
                Console.WriteLine("Outer Task");
            });

            outerTask.Wait();
            Console.WriteLine("outerTask terminato");
            
            // ************************************************************************************
            // Esempio 9.22
            // ************************************************************************************
            var outerTask1 = Task.Factory.StartNew(() =>
            {
                var innerTask1 = Task.Factory.StartNew(() =>
                {
                    Thread.Sleep(2000);
                    Console.WriteLine("Nested task");
                }, TaskCreationOptions.AttachedToParent);

                Console.WriteLine("Outer Task");
            });

            outerTask1.Wait();
            Console.WriteLine("outerTask terminato");

            // ************************************************************************************
            // Esempio 9.23
            // ************************************************************************************
            var myList = new List<int>();
            var rnd = new Random();

            for (int index = 1; index <= 10000000; index++)
            {
                myList.Add(rnd.Next(0, 100000));
            }

            // Query per recuperare i numeri primi
            var primes = from n in myList.AsParallel()
                         where IsPrime(n)
                         select n;

            var sw = Stopwatch.StartNew();
            primes.Count();
            sw.Stop();

            // ************************************************************************************
            // Esempio 9.24
            // ************************************************************************************
            var primes1 = from n in myList.AsParallel()
                         where IsPrime(n)
                         select n;

            primes1.ForAll((n) => DoSomething(n));

            // ************************************************************************************
            // Esempio 9.31
            // ************************************************************************************
            var syncObject = new object();

            var myList1 = new List<string>();
            myList1.Add("Elemento di test");

            var firstTask = Task.Factory.StartNew(() =>
            {
                bool lockTaken = false;
                Monitor.Enter(syncObject, ref lockTaken);
                try
                {
                    if (myList1.Count > 0)
                    {
                        Console.WriteLine(myList1[0]);
                    }
                }
                finally
                {
                    if (lockTaken)
                        Monitor.Exit(syncObject);
                }
            });

            var secondTask = Task.Factory.StartNew(() =>
            {
                bool lockTaken = false;
                Monitor.Enter(syncObject, ref lockTaken);
                try
                {
                    if (myList1.Count > 0)
                        myList1.RemoveAt(0);
                }
                finally
                {
                    if (lockTaken)
                        Monitor.Exit(syncObject);
                }
            });

            Task.WaitAll(firstTask, secondTask);

            // ************************************************************************************
            // Esempio 9.33
            // ************************************************************************************
            var myBag = new ConcurrentBag<string>(GetList());

            // Creazione del task che scorre la collection
            var firstTask1 = Task.Factory.StartNew(() =>
            {
                foreach (string item in myBag)
                {
                    DoSomething(item);
                }
            });

            // Creazione del task che modifica la collection
            var secondTask1 = Task.Factory.StartNew(() =>
            {
                myBag.Add("Task element");
            });

            Task.WaitAll(firstTask1, secondTask1);
        }

        public static void MyCallback(IAsyncResult ar)
        {
            Console.WriteLine("Esecuzione terminata");

            var method = (SomeDelegate)ar.AsyncState;
            int result = method.EndInvoke(ar);

            Console.WriteLine("Il risultato è {0}", result);
        }

        private static double PerformSomeLongCalulation(object inputValue)
        {
            return (double)inputValue;
        }

        public static void SomeMethod()
        { }

        private static List<Task> GetTaskList()
        {
            return new List<Task>() { Task.Factory.StartNew(() => Console.WriteLine("Some task")) };
        }

        public static bool IsPrime(int n)
        {
            var upperDivisor = Math.Floor(Math.Sqrt(n));

            for (int divisor = 2; divisor <= upperDivisor; divisor++)
            {
                if (n % divisor == 0)
                    return false;
            }

            return true;
        }

        public static void DoSomething(int value)
        {
        }

        public static void DoSomething(string value)
        {
        }


        private static List<string> GetList()
        {
            return new List<string>() { "A", "B", "C", "D" };
        }
    }
    
    public delegate int SomeDelegate(string parameter);
}
