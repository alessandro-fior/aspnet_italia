﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ASPItalia.Books.Chapter06
{
    class Program
    {
        static void Main(string[] args)
        {
            // ************************************************************************************
            // Esempio 6.1
            // ************************************************************************************
            var strings = new List<string>();

            strings.Add("This is a test");
            strings.Add("abcdefgh");
            strings.Add("a1234567");

            // Utilizzo del predicate come argomento di Find
            var foundString = strings.Find(FindStringsWithA);

            // Stampa abcdefgh sulla console
            Console.WriteLine(foundString);

            // ************************************************************************************
            // Esempio 6.3
            // ************************************************************************************
            var myLogger = new Logger(ConsoleWriter);

            // Stampa sulla console il messaggio in basso
            myLogger.Log("Messaggio di esempio");

            // ************************************************************************************
            // Esempio 6.4
            // ************************************************************************************
            var writer = new FileLogWriter(@"c:\somefile.txt");
            var writerDelegate = new StringLogWriter(writer.Write);

            Console.WriteLine(writerDelegate.Method);

            Console.WriteLine(
              ((FileLogWriter)writerDelegate.Target).FileName);

            // ************************************************************************************
            // Esempio 6.5
            // ************************************************************************************
            var sample = new MyDelegate<DateTime>(DateTimeWriter);

            // ************************************************************************************
            // Esempio 6.6
            // ************************************************************************************
            var sample1 = new Func<DateTime, string>(DateTimeWriter);

            // ************************************************************************************
            // Esempio 6.7
            // ************************************************************************************
            var foundString1 = strings.Find(
                delegate(string item)
                {
                    return item.StartsWith("a");
                });

            // ************************************************************************************
            // Esempio 6.8
            // ************************************************************************************
            var foundString2 = strings.Find(i => i.StartsWith("a"));

            // ************************************************************************************
            // Esempio 6.9
            // ************************************************************************************
            var searchString = "B";
            var foundString3 = strings.Find(i => i.StartsWith(searchString));

        }

        private static bool FindStringsWithA(string item)
        {
            return item.StartsWith("a");
        }

        private static void ConsoleWriter(DateTime timestamp, string message)
        {
            Console.WriteLine("{0} - {1}", timestamp, message);
        }

        delegate string SampleDelegate(string input);
        public static string VeryLongEchoFunction(string input)
        {
            Thread.Sleep(3000);
            return "Hello " + input;
        }

        public delegate string MyDelegate<T>(T input) where T : struct;

        private static string DateTimeWriter(DateTime input)
        {
            return input.ToShortDateString();
        }

    }
}
