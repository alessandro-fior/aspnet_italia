﻿using Capitolo8.Scenarios;

namespace Capitolo8
{
    class Program
    {
        static void Main(string[] args)
        {
            Scenario1.Run();
        }
    }
}