﻿using Capitolo7.Scenarios;

namespace Capitolo7
{
    class Program
    {
        static void Main(string[] args)
        {
            Scenario1.Run();
        }
    }
}