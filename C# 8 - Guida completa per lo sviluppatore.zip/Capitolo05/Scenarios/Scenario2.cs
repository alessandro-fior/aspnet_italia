﻿using System;
using System.Collections;

namespace Capitolo5.Scenarios
{
    public static class Scenario2
    {
        /// <summary>
        /// Esempio 5.2, 5.3
        /// </summary>
        public static void Run()
        {
            // Creazione di un arraylist
            var sample = new ArrayList();

            // Aggiunta di elementi
            sample.Add(2);
            sample.Add(5);
            sample.Add(3);

            // Ritorna il secondo elemento
            object value = sample[1];
            Console.WriteLine($"L'elemento in posizione 1 è: {value}");

            // Recupera il numero di elementi
            int count = sample.Count;
            Console.WriteLine($"L'ArrayList contiene {count} elementi");

            // Rimuove l'intero 2
            sample.Remove(2);

            // ciclo tutti gli elementi usando un ciclo for
            Console.WriteLine();
            for (int index = 0; index < sample.Count; index++)
            {
                Console.WriteLine(sample[index]);
            }

            // ciclo tutti gli elementi usando un ciclo foreach
            Console.WriteLine();
            foreach (object element in sample)
            {
                Console.WriteLine(element);
            }

            // Rimuove tutti gli elementi
            sample.Clear();
            Console.WriteLine();
            Console.WriteLine($"L'ArrayList contiene {sample.Count} elementi");
        }
    }
}