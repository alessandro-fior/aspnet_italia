﻿using System;

namespace Capitolo6.Scenarios
{
    public static class Scenario2
    {
        /// <summary>
        /// Esempio 6.2, 6.3
        /// </summary>
        public static void Run()
        {
            var myLogger = new Logger(ConsoleWriter);

            // Stampa sulla console il messaggio in basso
            myLogger.Log("Messaggio di esempio");
        }

        public static void ConsoleWriter(DateTime timestamp, string message)
        {
            Console.WriteLine("{0} - {1}", timestamp, message);
        }

        public delegate void StringLogWriter(DateTime timestamp, string message);

        public class Logger
        {
            private StringLogWriter writer;
        
            public Logger(StringLogWriter writer)
            {
                this.writer = writer;
            }
            
            public void Log(string message)
            {
                if (this.writer != null)
                    this.writer(DateTime.Now, message);
            }
        }
    }
}