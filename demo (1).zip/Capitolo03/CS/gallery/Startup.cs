﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Gallery
{
    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            //Quando arriva una richiesta alla root del sito (cioè a http://localhost:5000/)
            //allora la richiesta verrà riscritta internamente per puntare a uno dei file di default.
            //Tra i file di default figura index.html, che si trova in wwwroot.
            //UseDefaultFiles è utile nel caso di siti statici come questo o di Single Page Application
            //https://docs.microsoft.com/en-us/aspnet/core/fundamentals/static-files?tabs=aspnetcore2x
            app.UseDefaultFiles();
            //Questo middleware si occupa di servire i file statici al client
            app.UseStaticFiles();

            //Non sono necessari altri middleware.
            //Questa applicazione è un sito formato unicamente
            //da contenuti statici (pagine html, stile css e immagini jpg)
        }
    }
}
