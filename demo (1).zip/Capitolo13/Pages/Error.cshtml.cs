using System.Diagnostics;
using System.Net;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Capitolo13.Pages
{
    public class ErrorModel : PageModel
    {
        public string RequestId => Activity.Current?.Id ?? HttpContext.TraceIdentifier;

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

        public string ErrorMessage
        {
            get
            {
                var exceptionHandlerFeature = HttpContext.Features.Get<IExceptionHandlerFeature>();
                // Personalizzo il messaggio da mostrare
                switch (exceptionHandlerFeature?.Error)
                {
                    case WebException we:
                        return "Errore nella chiamata ai servizi. Riprovare";
                    default:
                        return "Si � verificato un errore non previsto. Riprovare";
                }
            }
        }

    }
}
