﻿Imports System.Security.Cryptography
Imports System.IO
Imports System.Text

Class MainWindow
  Dim cryptoProvider As TripleDESCryptoServiceProvider
  Dim key As Byte()
  Dim vector As Byte()
  Dim data As String = "testo da cifrare"

  Public Sub New()
    InitializeComponent()

    cryptoProvider = New TripleDESCryptoServiceProvider()

    'Dim cryptoProvider As New TripleDESCryptoServiceProvider()
    key = cryptoProvider.Key
    vector = cryptoProvider.IV

    key = {234, 12, 67, 245, 66, 99, _
            22, 214, 6, 88, 124, 44, _
            221, 34, 9, 22}

    Dim password As String = _
      "password per generare chiave"
    Dim salt As String = _
      "salt per generare chiave"

    Dim passwordByte As Byte() = _
      System.Text.Encoding.UTF8.GetBytes(password)
    Dim saltByte As Byte() = _
      System.Text.Encoding.UTF8.GetBytes(salt)

    Dim keyGenerator As New PasswordDeriveBytes(passwordByte, saltByte)
    key = keyGenerator.CryptDeriveKey("TripleDES", "SHA1", 192, vector)
  End Sub

  Private Sub Button_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    Dim dataByte As Byte() = _
      System.Text.Encoding.UTF8.GetBytes(data)
    Dim entropy As Byte() = _
      System.Text.Encoding.UTF8.GetBytes("chiave ulteriore sicurezza")
    Dim dataCripted As Byte() = _
      ProtectedData.Protect(dataByte, entropy, DataProtectionScope.CurrentUser)
    tb1.Text = System.Text.Encoding.UTF8.GetString(dataCripted)
  End Sub

  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)

    Dim dataByte As Byte() = _
      System.Text.Encoding.UTF8.GetBytes(data)

    Using encryptor As ICryptoTransform = _
      cryptoProvider.CreateEncryptor(key, vector)
      Using stream As Stream = File.Create("d:\encrypted.txt")
        Using cryptoStream As CryptoStream = _
          New CryptoStream(stream, encryptor, CryptoStreamMode.Write)
          cryptoStream.Write(dataByte, 0, dataByte.Length)
          cryptoStream.FlushFinalBlock()
        End Using
      End Using
    End Using

  End Sub

  Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)

    Using encryptor As ICryptoTransform = _
      cryptoProvider.CreateDecryptor(key, vector)
      Using stream As Stream = File.OpenRead("d:\encrypted.txt")
        Using cryptoStream As Stream = _
          New CryptoStream(stream, encryptor, CryptoStreamMode.Read)
          Using reader As New StreamReader(cryptoStream)
            tb2.Text = reader.ReadToEnd()
          End Using
        End Using
      End Using
    End Using

  End Sub

  Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    Using asCryptoProvider = New RSACryptoServiceProvider()
      File.WriteAllText("d:\PublicKey.xml", _
                        asCryptoProvider.ToXmlString(False))
      File.WriteAllText("d:\PublicAndPrivate.xml", _
                        asCryptoProvider.ToXmlString(True))
    End Using
  End Sub

  'chiavi di cifratura simmetrica criptate con RSA, da passare al destinatario
  Dim keyCrypted As Byte()
  Dim vectorCrypted As Byte()

  Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    'creazione chiave simmetrica per cifratura
    Dim cryptoProvider As TripleDESCryptoServiceProvider = New TripleDESCryptoServiceProvider()
    Dim key As Byte() = cryptoProvider.Key
    Dim vector As Byte() = cryptoProvider.IV

    'lettura chiave pubblica per cifratura asimmetrica
    Dim publicKeyOnly As String = File.ReadAllText("d:\PublicKey.xml")

    'cifratura asimmetrica della chiave simmetrica
    Using asCryptoProvider As RSACryptoServiceProvider = New RSACryptoServiceProvider()
      asCryptoProvider.FromXmlString(publicKeyOnly)

      keyCrypted = asCryptoProvider.Encrypt(key, True)
      vectorCrypted = asCryptoProvider.Encrypt(vector, True)
    End Using

    'dati riservati
    Dim dataByte As Byte() = _
      System.Text.Encoding.UTF8.GetBytes(data)

    'cifratura simmetrica con chiave e vettore autogenerati
    Using encryptor As ICryptoTransform = _
      cryptoProvider.CreateEncryptor(key, vector)
      Using stream As Stream = File.Create("d:\encrypted.txt")
        Using cryptoStream As CryptoStream = _
          New CryptoStream(stream, encryptor, CryptoStreamMode.Write)
          cryptoStream.Write(dataByte, 0, dataByte.Length)
          cryptoStream.FlushFinalBlock()
        End Using
      End Using
    End Using

  End Sub

  Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    Dim keyDecrypted As Byte()
    Dim vectorDecrypted As Byte()

    'lettura chiave pubblica e privata
    Dim publicPrivate As String = File.ReadAllText("d:\PublicAndPrivate.xml")

    'decifratura chiave simmetrica e vettore, con algoritmo asimmetrico
    Using asCryptoProvider As RSACryptoServiceProvider = New RSACryptoServiceProvider()
      asCryptoProvider.FromXmlString(publicPrivate)

      keyDecrypted = asCryptoProvider.Decrypt(keyCrypted, True)
      vectorDecrypted = asCryptoProvider.Decrypt(vectorCrypted, True)
    End Using

    'decifratura dati riservati con chiave simmetrica decifrata
    Using encryptor As ICryptoTransform = _
      cryptoProvider.CreateDecryptor(keyDecrypted, vectorDecrypted)
      Using stream As Stream = File.OpenRead("d:\encrypted.txt")
        Using cryptoStream As Stream = _
          New CryptoStream(stream, encryptor, CryptoStreamMode.Read)
          Using reader As New StreamReader(cryptoStream)
            tb3.Text = reader.ReadToEnd()
          End Using
        End Using
      End Using
    End Using

  End Sub

  Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    main.Visibility = Visibility.Collapsed

    Dim data As Byte() = _
      System.Text.Encoding.UTF8.GetBytes(tb4.Text)

    Dim hash1 As Byte() = MD5.Create().ComputeHash(data)
    Dim hash2 As Byte() = SHA1.Create().ComputeHash(data)
    Dim hash3 As Byte() = SHA512.Create().ComputeHash(data)

    tb5.Text = GetHexadecimal(hash1)
    tb6.Text = GetHexadecimal(hash2)
    tb7.Text = GetHexadecimal(hash3)
  End Sub

  Function GetHexadecimal(ByVal hash As Byte()) As String
    Dim sBuilder As New StringBuilder()

    Dim i As Integer
    For i = 0 To hash.Length - 1
      sBuilder.Append(hash(i).ToString("x2"))
    Next i
    Return sBuilder.ToString()
  End Function

  Public Sub Test()
    'Dim query As String = _
    '  String.Format("SELECT * FROM Users WHERE Username='{0}' AND Password='{1}'", _
    '                tbxUsername.Text, tbxPassword.Text)

    'Dim connection As New SqlConnection("stringa di connessione")
    'Dim query As String = "SELECT * FROM Users WHERE Username = @Username"
    'Dim command As New SqlCommand(query, connection)
    'Dim param As New SqlParameter("@Username", SqlDbType.NVarChar, 100)
    'param.Value = tbxUsername.Text
    'command.Parameters.Add(param)
    'Dim reader As SqlDataReader = command.ExecuteReader()
  End Sub
End Class

