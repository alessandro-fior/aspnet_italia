﻿using System;
using System.Xml.Xsl;

public class Sample20
{
    public static void Run()
    {
        var xslt = new XslCompiledTransform();
        // Carico la trasformazione XSLT
        xslt.Load("test.xslt");

        // Trasformo l'XML e lo mostro nella finestra di Output
        xslt.Transform("test.xml", null, Console.Out);
    }
}