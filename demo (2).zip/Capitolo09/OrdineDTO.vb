﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web

Public Class OrdineDTO
	Public Property Id As Int32
	Public Property Data As DateTime
End Class