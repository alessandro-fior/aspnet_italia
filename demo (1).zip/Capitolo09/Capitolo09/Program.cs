﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Transactions;

namespace Capitolo09
{
	class Program
	{
		static async Task Main(string[] args)
		{
			//await UseConnection();
			//ExecuteQuery();
			//await ExecuteQueryAsync();
			//QueryWithParameters();
			//UseTransaction();
			//CreateOrder();
			//await IterateDataReader();
			await IterateMultipleResultset();
			Console.ReadLine();
		}

		private static async Task IterateMultipleResultset()
		{
			using (var connection = GetConnection())
			{
				var cmd = new SqlCommand("SELECT * FROM Products; SELECT * FROM Customers",
				connection);
				using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
				{
					while (reader.Read())
					{
						Console.WriteLine((int)reader["ProductID"] + reader.GetString(1));
					}
					await reader.NextResultAsync();
					while (reader.Read())
					{
						Console.WriteLine((string)reader["CustomerID"] + reader.GetString(1));
					}
				}
			}
		}

		private static async Task IterateDataReader()
		{
			using (var connection = GetConnection())
			{
				using (var cmd = new SqlCommand("SELECT * FROM Products", connection))
				{
					using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
					{
						while (reader.Read())
						{
							Console.WriteLine((int)reader["ProductID"] + reader.GetString(1));
						}
					}
				}
			}
		}

		private static void UseTransaction()
		{
			using (var connection = GetConnection())
			{
				using (SqlTransaction transaction = connection.BeginTransaction())
				{
					try
					{
						// inserisce un ordine
						// inserisce i dettagli
						// aggiorna il magazzino
						transaction.Commit();
					}
					catch (SqlException)
					{
						transaction.Rollback();
						// Gestione dell'eccezione
					}
				}
			}
		}

		private static void QueryWithParameters()
		{
			using (var connection = GetConnection())
			{
				var query = new SqlCommand(
					"SELECT * FROM Orders " +
					"WHERE EmployeeID = @EmployeeID " +
					"AND OrderDate = @OrderDate " +
					"AND ShipCountry = @ShipCountry " +
					"ORDER BY OrderDate DESC", connection);
				var p1 = new SqlParameter
				{
					ParameterName = "@EmployeeID",
					DbType = DbType.Int32,
					Direction = ParameterDirection.Input,
					Value = 1
				};
				var p2 = new SqlParameter
				{
					ParameterName = "@OrderDate",
					DbType = DbType.DateTime,
					Direction = ParameterDirection.Input,
					Value = new DateTime(1996, 8, 7)
				};
				var p3 = new SqlParameter
				{
					ParameterName = "@ShipCountry",
					DbType = DbType.String,
					Direction = ParameterDirection.Input,
					Value = "Italy"
				};
				query.Parameters.Add(p1);
				query.Parameters.Add(p2);
				query.Parameters.Add(p3);
				using (var reader = query.ExecuteReader())
				{

				}
			}
		}

		private static async Task UseConnection()
		{
			// Stringa di connessione
			var connectionString = "Server=(local);Database=Northwind;integrated security=true";

			// Creazione dell'istanza di SqlConnection
			var conn = new SqlConnection(connectionString);
			try
			{
				// Apertura della connessione
				await conn.OpenAsync();

			}
			catch (SqlException)
			{
				// Gestione dell'eccezione
			}
			finally
			{
				// Chiusura della connessione
				if (conn.State == ConnectionState.Open)
					conn.Close();
			}

			var builder = new SqlConnectionStringBuilder();
			builder.DataSource = "(local)";
			builder.InitialCatalog = "Northwind";
			builder.IntegratedSecurity = true;

			using (var connection = new SqlConnection(builder.ConnectionString))
			{
				try
				{
					await connection.OpenAsync();
					// ...
				}
				catch (SqlException)
				{
					// Gestione dell'eccezione
				}
			}
		}

		private static SqlConnection GetConnection()
		{
			// Stringa di connessione
			var connectionString = "Server=(local);Database=Northwind;integrated security=true;MultipleActiveResultSets=true;";

			// Creazione dell'istanza di SqlConnection
			var conn = new SqlConnection(connectionString);
			conn.Open();
			return conn;
		}

		private static void ExecuteQuery()
		{
			using (var connection = GetConnection())
			{
				// Aggiornamento
				var cmdUpdate = new SqlCommand("UPDATE Products SET discontinued = 0 where productid = 1", connection);
				Console.WriteLine(cmdUpdate.ExecuteNonQuery());

				// Query
				var cmdQuery = new SqlCommand("SELECT * FROM Products", connection);
				SqlDataReader reader = cmdQuery.ExecuteReader();
				Console.WriteLine(reader.RecordsAffected);

				// Conteggio
				var cmdCount = new SqlCommand("SELECT COUNT(*) FROM Products", connection);
				Console.WriteLine((int)cmdCount.ExecuteScalar());
			}
		}

		private static async Task ExecuteQueryAsync()
		{
			using (var connection = GetConnection())
			{
				// Aggiornamento
				var cmdUpdate = new SqlCommand("UPDATE Products SET discontinued = 0 where productid = 1", connection);
				Console.WriteLine(await cmdUpdate.ExecuteNonQueryAsync());

				// Query
				var cmdQuery = new SqlCommand("SELECT * FROM Products", connection);
				SqlDataReader reader = await cmdQuery.ExecuteReaderAsync();
				Console.WriteLine(reader.RecordsAffected);

				// Conteggio
				var cmdCount = new SqlCommand("SELECT COUNT(*) FROM Products", connection);
				Console.WriteLine((int)await cmdCount.ExecuteScalarAsync());
			}
		}


		public static void CreateOrder()
		{
			using (var scope = new TransactionScope())
			{
				SaveOrder();
				UpdateStock();
				scope.Complete();
			}
		}
		private static void SaveOrder()
		{
			using (var connection = GetConnection())
			{
				var command = new SqlCommand("INSERT INTO[dbo].[Orders] ([CustomerID],[OrderDate],[ShipName],[ShipAddress],[ShipCity],[ShipPostalCode]) VALUES ('ALFKI', '2018-06-06', 'testname', 'testaddress', 'testcity', '00100')", connection);
				command.ExecuteNonQuery();

			}
		}

		private static void UpdateStock()
		{
			using (var connection = GetConnection())
			{
				var command = new SqlCommand("update products set unitsinstock = unitsinstock-1 where productid = 1", connection);
				command.ExecuteNonQuery();
			}
		}
	}
}
