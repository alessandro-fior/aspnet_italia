using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using UserAdministration.Models;
using UserAdministration.Models.UserAdministrationViewModels;

namespace UserAdministration.Controllers
{
    [Authorize(Roles = "Administrator")]
    public class UserAdministrationController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        public UserAdministrationController(UserManager<ApplicationUser> userManager) {
            this.userManager = userManager;
        }
        public async Task<IActionResult> Index() {
            var users = await GetAllUsers();
            return View(users);
        }

        private async Task<List<UserAdministrationListViewModel>> GetAllUsers()
        {
            return await userManager.Users
            .OrderBy(user => user.Email)
            .Select(user => new UserAdministrationListViewModel {
                Id = user.Id,
                Email = user.Email,
                LockedOut = user.LockoutEnd.HasValue
            }).ToListAsync();
        }

        [HttpPost]
        public async Task<IActionResult> Create(UserAdministrationCreateViewModel userModel) {
            if (!ModelState.IsValid) {
                var users = await GetAllUsers();
                return View(nameof(Index), users);
            }
            var user = new ApplicationUser {
                UserName = userModel.Email,
                Email = userModel.Email,
                LockoutEnabled = true,
                EmailConfirmed = true
            };
            var result = await userManager.CreateAsync(user, userModel.Password);
            if (result.Errors?.Any() == true) {
                ModelState.AddModelError("", result.Errors.FirstOrDefault().Description);
                var users = await GetAllUsers();
                return View(nameof(Index), users);
            }
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(string id) {

            var user = await userManager.FindByIdAsync(id);
            if (user == null) {
                return RedirectToAction(nameof(Index));
            }

            var userViewModel = await GetUserViewModel(user);
            ViewBag.ClaimTypes = GetClaimTypes();

            return View(userViewModel);
        }

        private async Task<UserAdministrationEditViewModel> GetUserViewModel(ApplicationUser user)
        {
            return new UserAdministrationEditViewModel {
                Id = user.Id,
                Email = user.UserName,
                LockedOut = user.LockoutEnd.HasValue && user.LockoutEnd.Value >= DateTimeOffset.UtcNow,
                Claims = await GetClaimsForUser(user)
            };
        }

        private async Task<List<UserAdministrationClaimViewModel>> GetClaimsForUser(ApplicationUser user)
        {
             return (await userManager.GetClaimsAsync(user))
                            .Select(claim => new UserAdministrationClaimViewModel {
                                ClaimType = claim.Type,
                                Value = claim.Value
                            }).ToList();
        }

        private List<SelectListItem> GetClaimTypes()
        {
            var claimTypes = new List<SelectListItem>();
            var constants = typeof(ClaimTypes).GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy);
            foreach (var c in constants) {
                if (c.IsLiteral && !c.IsInitOnly) {
                    
                    claimTypes.Add(new SelectListItem { Value = c.GetRawConstantValue() as string, Text = c.Name });
                }
            }
            return claimTypes.OrderBy(c => c.Text).ToList();
        }

        [HttpPost]
        public async Task<IActionResult> Edit(string id, UserAdministrationEditViewModel userModel) {
            var user = await userManager.FindByIdAsync(id);
            if (!ModelState.IsValid) {
                userModel = await GetUserViewModel(user);
                ViewBag.ClaimTypes = GetClaimTypes();
                return View(userModel);
            }

            if (user == null) {
                return RedirectToAction(nameof(Index));
            }

            //Password changed?


            if (!string.IsNullOrWhiteSpace(userModel.Password)) {
                //Metodo 1: usare GeneratePasswordResetTokenAsync e ResetPasswordAsync
                //var resetPasswordToken = await userManager.GeneratePasswordResetTokenAsync(user);
                //var passwordChangeResult = await userManager.ResetPasswordAsync(user, resetPasswordToken, userModel.Password);

                //Metodo 2: usare il password hasher per creare una versione hashata della password
                user.PasswordHash = userManager.PasswordHasher.HashPassword(user, userModel.Password);
            }

            //Aggiorniamo la data di Lockout
            user.LockoutEnd = userModel.LockedOut ? DateTimeOffset.UtcNow.AddYears(40) : default(DateTimeOffset?);
            
            var result = await userManager.UpdateAsync(user);
            if (result.Errors?.Any() == true) {
                userModel = await GetUserViewModel(user);
                ViewBag.ClaimTypes = GetClaimTypes();
                ModelState.AddModelError("", result.Errors.FirstOrDefault().Description);
                return View(userModel);
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(string id) {
            var user = await userManager.FindByIdAsync(id);
            if (user != null) {
                await userManager.DeleteAsync(user);
            }
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> AddClaim(string id, UserAdministrationClaimViewModel claimModel) {
            if (ModelState.IsValid) {
                var user = await userManager.FindByIdAsync(id);
                if (user != null) {
                    var claim = new Claim(claimModel.ClaimType, claimModel.Value);
                    await userManager.AddClaimAsync(user, claim);
                }
            }
            return RedirectToAction(nameof(Edit), new { id = id });
        }

        public async Task<IActionResult> RemoveClaim(string id, UserAdministrationClaimViewModel claimModel) {
            if (ModelState.IsValid) {
                var user = await userManager.FindByIdAsync(id);
                if (user != null) {
                    var allClaims = await userManager.GetClaimsAsync(user);
                    var removeClaims = allClaims.Where(c => c.Type == claimModel.ClaimType && c.Value == claimModel.Value).ToList();
                    if (removeClaims.Any()) {
                        await userManager.RemoveClaimsAsync(user, removeClaims);
                    }
                }
            }
            return RedirectToAction(nameof(Edit), new { id = id });
        }
    }
}