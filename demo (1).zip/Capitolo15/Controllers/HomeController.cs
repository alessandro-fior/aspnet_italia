﻿using Microsoft.AspNetCore.Mvc;
using Capitolo15.Models;
using Capitolo15.Binders;

namespace Capitolo15.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(string id)
        {
            return View(new IndexViewModel { ReservedSection = "Reserved section" });
        }

        public ActionResult Multisource([FromHeader(Name = "Content-Type")] string header, [FromRoute(Name = "id")] int parameter)
        {
            return Ok();
        }
        
        public ActionResult SelectedBind()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SelectedBind([Bind("FirstName,LastName")] Person p)
        {
            // si può verificare, se il PersonBinderProvider è disabilitato nello startup
            // che l'età ha il valore di default previsto dagli interi, ovvero 0, 
            // mentre tutti gli altri campi saranno valorizzati correttamente

            return Ok();
        }

        /// <summary>
        /// Send request with this data:
        /// 
        /// Valido
        /// eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmaXJzdE5hbWUiOiJNYXJpbyIsImxhc3ROYW1lIjoiUm9zc2kiLCJhZ2UiOjI1fQ.FQWf49HefTcPjkdEcs9Xbt5klzc1pBWGyGOHpJ575uY
        /// 
        /// Non valido
        /// eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJub21lIjoiTWFyaW8iLCJjb2dub21lIjoiUm9zc2kiLCJldGEiOjI1fQ.OtK420A2CApeTFHqS5xYqxRAdGrPXYLKbYcHKPxezwE
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Decode([ModelBinder(typeof(PersonBinder))] Person p)
        {
            if (p == null)
                return BadRequest();

            return Ok();
        }

        public IActionResult InterfaceBinding()
        {
            return View();
        }

        [HttpPost]
        public IActionResult InterfaceBinding(IPerson person)
        {
            return View(person);
        }
    }
}