﻿using System;

namespace Aspitalia.Books.Chapter4
{
    // Classe derivata
    public class Employee : Person
    {
        // Campo privato
        private string _firstName;

        // Viene richiamato implicitamente il costruttore
        // di default della classe base
        public Employee(string name, int age) : base(name, age)
        {
            // Viene chiamato il metodo della classe base
            _firstName = base.GetFirstName();
        }

        // Override di un metodo virtuale
        public override string GetFirstName()
        {
            return _firstName;
        }

        // Override di un metodo astratto
        public override void Write()
        {
            Console.Write(FullName);
        }
    }
}
