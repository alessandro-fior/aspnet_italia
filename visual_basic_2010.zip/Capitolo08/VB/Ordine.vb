﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web

Public Class Ordine
	Public Property Id As Int32
	Public Property Data As DateTime
	Public Property Dettagli As DettaglioOrdine()

	Public Overrides Function Equals(ByVal obj As Object) As Boolean
		Return CType(obj, Ordine).Id = Id
	End Function

	Public Overrides Function GetHashCode() As Integer
		Return Id
	End Function
End Class