﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using BasicAuth.Middlewares;
using BasicAuth.Services;

namespace BasicAuth
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<IUserRepository, UserRepository>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            //Questa applicazione è composta di soli 3 middleware

            //Il middleware di autenticazione ispeziona la richiesta ed eventualmente crea una ClaimsPrincipal
            app.UseMiddleware<BasicAuthenticationMiddleware>();

            //Il middleware di autorizzazione blocca la richiesta se non era stata crare una ClaimsPrincipal
            app.UseMiddleware<AuthorizationMiddleware>();

            //Il middleware che mostra il contenuto potrà dunque produrre una risposta solo per glis utenti autorizzati
            app.UseMiddleware<ContentMiddleware>();
        }
    }
}
