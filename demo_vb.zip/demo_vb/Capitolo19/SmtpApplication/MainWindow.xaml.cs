﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Net.Mail;
using System.Net;

namespace SmtpApplication
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Button1_Click(object sender, RoutedEventArgs e)
    {
      SmtpClient client = new SmtpClient("xxx.xxx.xxx.xxx");
      client.Credentials = new NetworkCredential("username", "password");

      MailMessage message = new MailMessage(new MailAddress("indirizzo_mittente"), new MailAddress("indirizzo_destinatario"));
      message.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure | DeliveryNotificationOptions.OnSuccess | DeliveryNotificationOptions.Delay;
      message.Body = this.TextBox2.Text;
      message.Subject = "messaggio di prova";
      client.SendCompleted += new SendCompletedEventHandler(ClientSendCompleted);
      client.SendAsync(message, null);
    }

    private void ClientSendCompleted(object sender, AsyncCompletedEventArgs e)
    {
      if (e.Error != null)
      {
        this.TextBox2.Text = e.Error.ToString();
      }
      else
      {
        this.TextBox2.Text = "inviato";
      }
    }








  }
}
