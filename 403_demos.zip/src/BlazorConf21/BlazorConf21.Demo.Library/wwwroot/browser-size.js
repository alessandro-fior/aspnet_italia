﻿export function registerResizeCallback() {
  window.addEventListener('resize', onResize);
}

function onResize() {
  console.log("resize");
  DotNet.invokeMethodAsync('BlazorConf21.Demo.Library', 'OnBrowserResize').then(data => data);
}
