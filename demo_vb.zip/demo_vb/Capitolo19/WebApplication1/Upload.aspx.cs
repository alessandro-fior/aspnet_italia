﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace WebApplication1
{
  public partial class Upload : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.Request.QueryString["path"] != null)
      {
        string _physicalApplicationPath = HttpContext.Current.Request.PhysicalApplicationPath;
        string _path = string.Format(@"{0}\{1}", _physicalApplicationPath, Convert.ToString(this.Request.QueryString["path"]));
        using (FileStream stream = File.OpenWrite(_path))
        {
          byte[] dataByte = new byte[1024];
          int i = 0;
          do
          {
            i = this.Context.Request.InputStream.Read(dataByte, 0, 1024);
            if (i > 0)
            {
              stream.Write(dataByte, 0, i);
            }
          }
          while (i > 0);
        }
        this.Response.Clear();
        this.Response.Write("ok");
        this.Response.End();
      }
      else
      {
        this.Response.Clear();
        this.Response.Write("errore");
        this.Response.End();
      }
    }
  }
}