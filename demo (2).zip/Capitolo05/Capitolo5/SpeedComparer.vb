﻿Namespace ASPItalia.Books.Chapter05
    Public Class Vehicle
        Public Property Speed As Integer
    End Class

    Public Class Car
        Inherits Vehicle
    End Class

    Public Class SpeedComparer
        Implements IComparer(Of Vehicle)

        Public Function Compare(ByVal x As Vehicle, ByVal y As Vehicle) _
          As Integer Implements IComparer(Of Vehicle).Compare

            Return x.Speed - y.Speed
        End Function
    End Class

    Module ContravarianceModule
        'Public Sub Main()
        '    Dim cars As New List(Of Car)
        '    ' ... si popola la lista

        '    cars.Sort(New SpeedComparer())
        'End Sub
    End Module

End Namespace