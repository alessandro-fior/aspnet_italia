﻿Imports System.IO
Imports System.Security.Cryptography
Imports System.Text

Class MainWindow
    Private key As Byte()
    Private vector As Byte()
    Private keyCrypted As Byte()
    Private vectorCrypted As Byte()
    Private cryptoProvider As TripleDESCryptoServiceProvider
    Private keyDecrypted As Byte()
    Private vectorDecrypted As Byte()
    Public Sub DemoCript()
        cryptoProvider = New TripleDESCryptoServiceProvider()
        key = cryptoProvider.Key
        vector = cryptoProvider.IV
        key = New Byte() {&HEA, 12, &H43, &HF5, &H42, &H63, &H16, &HD6, 6, &H58, &H7C, &H2C, &HDD, &H22, 9, &H16}
        Dim password As String = "password per generare chiave"
        Dim salt As String = "salt per generare chiave"
        Dim passwordByte As Byte() = Encoding.UTF8.GetBytes(password)
        Dim saltByte As Byte() = Encoding.UTF8.GetBytes(salt)
        key = New PasswordDeriveBytes(passwordByte, saltByte).CryptDeriveKey("TripleDES", "SHA1", 192, Me.vector)
        Dim dataByte As Byte() = Encoding.UTF8.GetBytes(textToCript.Text)

        Using encryptor As ICryptoTransform = cryptoProvider.CreateEncryptor(Me.key, Me.vector)

            Using stream As Stream = File.Create("c:\temp\encrypted.txt")

                Using cryptoStream As CryptoStream = New CryptoStream(stream, encryptor, CryptoStreamMode.Write)
                    cryptoStream.Write(dataByte, 0, dataByte.Length)
                    cryptoStream.FlushFinalBlock()
                End Using
            End Using
        End Using
    End Sub

    Public Sub DemoDeCript()
        Using encryptor As ICryptoTransform = Me.cryptoProvider.CreateDecryptor(Me.key, Me.vector)

            Using stream As Stream = File.OpenRead("c:\temp\encrypted.txt")

                Using cryptoStream As Stream = New CryptoStream(stream, encryptor, CryptoStreamMode.Read)

                    Using reader As StreamReader = New StreamReader(cryptoStream)
                        textToDECript.Text = reader.ReadToEnd()
                    End Using
                End Using
            End Using
        End Using
    End Sub

    Public Sub DemoCriptAsim()
        Using asCryptoProvider As RSACryptoServiceProvider = New RSACryptoServiceProvider()
            File.WriteAllText("c:\temp\PublicKey.xml", asCryptoProvider.ToXmlString(False))
            File.WriteAllText("c:\temp\PublicAndPrivate.xml", asCryptoProvider.ToXmlString(True))
        End Using

        Dim cryptoProvider As TripleDESCryptoServiceProvider = New TripleDESCryptoServiceProvider()
        key = cryptoProvider.Key
        vector = cryptoProvider.IV
        Dim publicKeyOnly As String = File.ReadAllText("c:\temp\PublicKey.xml")

        Using asCryptoProvider As RSACryptoServiceProvider = New RSACryptoServiceProvider()
            asCryptoProvider.FromXmlString(publicKeyOnly)
            keyCrypted = asCryptoProvider.Encrypt(key, True)
            vectorCrypted = asCryptoProvider.Encrypt(vector, True)
        End Using

        Dim dataByte As Byte() = Encoding.UTF8.GetBytes(textToCript.Text)

        Using encryptor As ICryptoTransform = cryptoProvider.CreateEncryptor(key, vector)

            Using stream As Stream = File.Create("c:\temp\encrypted.txt")

                Using cryptoStream As CryptoStream = New CryptoStream(stream, encryptor, CryptoStreamMode.Write)
                    cryptoStream.Write(dataByte, 0, dataByte.Length)
                    cryptoStream.FlushFinalBlock()
                End Using
            End Using
        End Using
    End Sub

    Public Sub DemoDeCriptAsim()
        Dim publicPrivate As String = File.ReadAllText("c:\temp\PublicAndPrivate.xml")

        Using asCryptoProvider As RSACryptoServiceProvider = New RSACryptoServiceProvider()
            asCryptoProvider.FromXmlString(publicPrivate)
            keyDecrypted = asCryptoProvider.Decrypt(keyCrypted, True)
            vectorDecrypted = asCryptoProvider.Decrypt(vectorCrypted, True)
        End Using

        Using encryptor As ICryptoTransform = Me.cryptoProvider.CreateDecryptor(keyDecrypted, vectorDecrypted)

            Using stream As Stream = File.OpenRead("c:\temp\encrypted.txt")

                Using cryptoStream As Stream = New CryptoStream(stream, encryptor, CryptoStreamMode.Read)

                    Using reader As StreamReader = New StreamReader(cryptoStream)
                        textToDECript.Text = reader.ReadToEnd()
                    End Using
                End Using
            End Using
        End Using
    End Sub

    Private Sub Button_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        DemoCript()
    End Sub

    Private Sub Button_Click_1(ByVal sender As Object, ByVal e As RoutedEventArgs)
        DemoDeCript()
    End Sub

    Private Sub Button_Click_2(ByVal sender As Object, ByVal e As RoutedEventArgs)
        DemoCriptAsim()
    End Sub

    Private Sub Button_Click_3(ByVal sender As Object, ByVal e As RoutedEventArgs)
        DemoDeCriptAsim()
    End Sub
End Class
