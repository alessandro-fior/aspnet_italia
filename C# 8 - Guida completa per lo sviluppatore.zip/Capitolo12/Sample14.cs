﻿using System.Linq;
using System.Xml.XPath;
using System;
using System.IO;


public class Sample14
{
    public static void Run()
    {
        var doc = new XPathDocument(Path.Combine(Environment.CurrentDirectory, "test.xml"));
        XPathNavigator navigator = doc.CreateNavigator();
        // Navigo sulla root <products>
        navigator.MoveToFirstChild();
        // Navigo sul primo <product>
        navigator.MoveToChild("product", "http://schemas.aspitalia.com/book40/products");
        // Mi sposto sull'attributo della categoria
        navigator.MoveToAttribute("idCategory", "");
        // Leggo il valore
        int idCategory = navigator.ValueAsInt;

        Console.WriteLine(idCategory);
    }

}
