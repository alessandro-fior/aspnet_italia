﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Ordine
/// </summary>
namespace CS {
	public class Ordine {
		public int Id { get; set; }
		public DateTime Data { get; set; }
		public DettaglioOrdine[] Dettagli { get; set; }

		public override int GetHashCode() {
			return Id;
		}

		public override bool Equals(object obj) {
			return ((Ordine)obj).Id == Id;
		}
	}
}