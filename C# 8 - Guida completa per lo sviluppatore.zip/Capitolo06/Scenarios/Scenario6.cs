﻿using System;
using System.Threading;

namespace Capitolo6.Scenarios
{
    public static class Scenario6
    {
        /// <summary>
        /// Esempio 6.7
        /// </summary>
        public static void Run()
        {
            var myEcho = new SampleDelegate(VeryLongEchoFunction);
            Console.WriteLine(myEcho("Marco"));
            Console.WriteLine(myEcho("Daniele"));
            Console.WriteLine(myEcho("Matteo"));
        }

        delegate string SampleDelegate(string input);
        
        public static string VeryLongEchoFunction(string input)
        {
            Thread.Sleep(3000);
            return "Hello " + input;
        }
    }
}