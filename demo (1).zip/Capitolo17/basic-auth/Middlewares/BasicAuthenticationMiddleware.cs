using System;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using BasicAuth.Models;
using BasicAuth.Services;

namespace BasicAuth.Middlewares
{
    public class BasicAuthenticationMiddleware
    {
        private readonly RequestDelegate next;
        private readonly IUserRepository userRepository;
        public BasicAuthenticationMiddleware(RequestDelegate next, IUserRepository userRepository)
        {
            this.next = next;
            this.userRepository = userRepository;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            //Esaminiamo la richiesta per capire se sono state fornite delle credenziali
            var headerValue = context.Request.Headers["Authorization"];
            var credentials = ParseBasicAuthenticationCredentials(headerValue);
            var user = userRepository.FindByCredentials(credentials.Username, credentials.Password);
            if (user != null)
            {
                //Se è stato trovato un utente con le credenziali fornite,
                //allora creiamo una ClaimsPrincipal
                var identity = new ClaimsIdentity(authenticationType: "Basic");

                //Aggiungiamo dei Claim
                //I più comuni li troviamo elencati come costanti nella classe ClaimTypes
                identity.AddClaim(new Claim(ClaimTypes.Name, user.Username));
                identity.AddClaim(new Claim(ClaimTypes.Role, user.Role));
                identity.AddClaim(new Claim(ClaimTypes.DateOfBirth, user.DateOfBirth.ToString()));
                //Possiamo anche aggiungere Claim dal nome totalmente arbitrario
                identity.AddClaim(new Claim("FavoriteColor", user.FavoriteColor));

                //Impostiamo la ClaimsPrincipal sulla proprietà User
                context.User = new ClaimsPrincipal(identity);
            }
            else
            {
                //Non era stata fornita alcuna credenziale, quindi non imposteremo alcuna ClaimsPrincipal
                //Secondo la basic authentication, dobbiamo aggiungere un'intestazione WWW-Authenticate
                //alla risposta per notificare l'utente che può autenticarsi con questo meccanismo
                //https://it.wikipedia.org/wiki/Basic_access_authentication
                context.Response.Headers.Add("WWW-Authenticate", "Basic realm=\"BasicAuthSample\"");
            }
            //Possiamo passare il controllo al middleware successivo
            await next.Invoke(context);
        }

        private (string Username, string Password) ParseBasicAuthenticationCredentials(string value)
        {
            //Le credenziali per la basic authentication sono formattate in questo modo
            //Basic <stringa codificata in base64>
            //Decodificando la stringa si ottiene username:password
            if (!string.IsNullOrWhiteSpace(value) && value.StartsWith("Basic "))
            {
                value = value.Substring(6); //Rimuoviamo il prefisso "Basic "
                try
                {
                    var decodedCredentials = Encoding.UTF8.GetString(Convert.FromBase64String(value));
                    var colonPosition = decodedCredentials.IndexOf(":");
                    if (colonPosition >= 0)
                    {
                        return (Username: decodedCredentials.Substring(0, colonPosition),
                                Password: decodedCredentials.Substring(colonPosition + 1));

                    }
                }
                catch
                {

                }
            }
            return default((string, string));
        }
    }
}