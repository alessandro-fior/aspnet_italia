﻿Partial Public Class Order
	Public Sub New()
		Order_Details = New HashSet(Of OrderDetail)
	End Sub

	Public Property OrderID As Integer
	Public Property CustomerID As String
	Public Property EmployeeID As Integer?
	Public Property OrderDate As Date?
	Public Property RequiredDate As Date?
	Public Property ShippedDate As Date?
	Public Property ShipVia As Integer?
	Public Property Freight As Decimal?
	Public Property ShipName As String
	Public Property ShipAddress As String
	Public Property ShipCity As String
	Public Property ShipRegion As String
	Public Property ShipPostalCode As String
	Public Property ShipCountry As String
	Public Overridable Property Customer As Customer
	Public Overridable Property Order_Details As ICollection(Of OrderDetail)
End Class
