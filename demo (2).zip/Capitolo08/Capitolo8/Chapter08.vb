﻿Imports System.Threading
Imports System.Threading.Tasks
Imports System.Collections.Concurrent

Module Chapter08

    Sub Main()

        ' ***************************************************************************************************
        ' Esempio 09.1
        ' ***************************************************************************************************
        Dim myThread As New Thread(
          Sub()
              Console.WriteLine("MyThread è iniziato")
              Thread.Sleep(1000)
              Console.WriteLine("MyThread è terminato")
          End Sub)

        ' Esecuzione di myThread
        myThread.Start()

        Thread.Sleep(500)
        Console.WriteLine("Main Thread")

        ' ***************************************************************************************************
        ' Esempio 09.2
        ' ***************************************************************************************************
        Dim someVariable As String = "Matteo Tumiati"

        Dim workerThread As New Thread(
          Sub(argument)
              Console.WriteLine("Saluti da: {0}", argument)
          End Sub)

        workerThread.Start(someVariable)

        ' ***************************************************************************************************
        ' Esempio 09.3
        ' ***************************************************************************************************
        Dim someVariable1 As String = "Matteo Tumiati"

        Dim workerThread1 As New Thread(
          Sub()
              Thread.Sleep(500)
              Console.WriteLine("Saluti da: {0}", someVariable1)
          End Sub)

        workerThread1.Start()
        someVariable1 = "Daniele Bochicchio"

        ' ***************************************************************************************************
        ' Esempio 09.4
        ' ***************************************************************************************************
        Dim list As New List(Of Thread)

        ' Qui creiamo ed eseguiamo cinque worker thread
        For index = 1 To 5
            Dim myThread1 As New Thread(
              Sub(currentIndex)
                  Console.WriteLine("Thread {0} è iniziato", currentIndex)
                  Thread.Sleep(500)
                  Console.WriteLine("Thread {0} è terminato", currentIndex)
              End Sub)

            myThread1.Start(index)
            list.Add(myThread1)
        Next

        ' Attesa del completamento di ognuno dei worker thread
        For Each thread As Thread In list
            thread.Join()
        Next

        Console.WriteLine("Esecuzione di tutti i thread terminata")

        ' ***************************************************************************************************
        ' Esempio 09.5
        ' ***************************************************************************************************
        Dim workerThread2 As New Thread(
            Sub()
                Console.WriteLine("Inizio di un thread molto lungo")
                Thread.Sleep(5000)
                Console.WriteLine("Termine worker thread")
            End Sub)

        workerThread2.Start()
        workerThread2.Join(500)
        ' Se il worker thread è ancora in esecuzione, lo si cancella
        If (workerThread2.ThreadState <> ThreadState.Stopped) Then
            workerThread2.Abort()
        End If

        Console.WriteLine("Termine applicazione")

        ' ***************************************************************************************************
        ' Esempio 09.6
        ' ***************************************************************************************************
        ThreadPool.QueueUserWorkItem(
            Sub()
                Console.WriteLine("Inizio worker thread")
                Thread.Sleep(1000)
                Console.WriteLine("Termine worker thread")
            End Sub)

        Thread.Sleep(500)
        Console.WriteLine("Metodo main")
        Thread.Sleep(2000)

        ' ***************************************************************************************************
        ' Esempio 09.7
        ' ***************************************************************************************************
        Dim someVariable2 As String = "Matteo Tumiati"

        ThreadPool.QueueUserWorkItem(
            Sub(argument)
                Thread.Sleep(500)
                Console.WriteLine("Saluti da: {0}", argument)
            End Sub, someVariable2)

        someVariable2 = "Daniele Bochicchio"
        Thread.Sleep(2000)

        ' ***************************************************************************************************
        ' Esempio 09.8
        ' ***************************************************************************************************
        Dim list1 As New List(Of ManualResetEvent)

        Try
            For index = 1 To 5
                ' Creazione del waitHandle per il task corrente
                Dim waitHandle As New ManualResetEvent(False)
                list1.Add(waitHandle)

                ' Oggetto da passare al task accodato
                Dim state As New Tuple(Of Integer, ManualResetEvent)(
                  index, waitHandle)

                ThreadPool.QueueUserWorkItem(
                  Sub(untypedState)
                      ' WaitCallback accetta un Object, pertanto è necessario un cast
                      Dim taskState = DirectCast(untypedState,
                        Tuple(Of Integer, ManualResetEvent))

                      ' Visualizzazione dei messaggi su consol
                      Console.WriteLine("Thread {0} è iniziato", taskState.Item1)
                      Thread.Sleep(500)
                      Console.WriteLine("Thread {0} è terminato", taskState.Item1)

                      ' Segnalazione del termine dell'esecuzione del task
                      ' utilizzando il Set del ManualResetEvent
                      taskState.Item2.Set()
                  End Sub, state)
            Next

            ' Attesa che tutti i ManualResetEvent siano in stato Set
            For Each handle As ManualResetEvent In list1
                handle.WaitOne()
            Next
        Finally
            For Each handle As ManualResetEvent In list1
                handle.Dispose()
            Next
        End Try

        Console.WriteLine("Esecuzione terminata")

        ' ***************************************************************************************************
        ' Esempio 09.9
        ' ***************************************************************************************************
        Dim method As New SomeDelegate(
            Function(parameter)
                Thread.Sleep(1000)
                Console.WriteLine("Ciao da {0}", parameter)
                Return parameter.Length
            End Function)

        method.BeginInvoke("Matteo Tumiati", Nothing, Nothing)
        Console.WriteLine("Esecuzione avviata")
        Thread.Sleep(2000)

        ' ***************************************************************************************************
        ' Esempio 09.10
        ' ***************************************************************************************************
        ' Esecuzione asincrona del delegate
        Dim asyncResult As IAsyncResult =
          method.BeginInvoke("Matteo Tumiati", Nothing, Nothing)

        Console.WriteLine("Esecuzione avviata")

        ' Attesa del termine dell'operazione e recupero risultato
        Dim result As Integer = method.EndInvoke(asyncResult)

        Console.WriteLine("Il risultato è {0}", result)

        ' ***************************************************************************************************
        ' Esempio 09.11
        ' ***************************************************************************************************
        ' Esecuzione asincrona del delegate
        Dim asyncResult1 As IAsyncResult =
          method.BeginInvoke("Matteo Tumiati", Nothing, Nothing)

        Console.WriteLine("Esecuzione avviata")

        ' Polling sul WaitHandle
        While Not asyncResult1.IsCompleted
            Console.WriteLine("Esecuzione in corso...")
            asyncResult1.AsyncWaitHandle.WaitOne(200)
        End While

        Dim result1 As Integer = method.EndInvoke(asyncResult1)

        Console.WriteLine("Il risultato è {0}", result1)

        ' ***************************************************************************************************
        ' Esempio 09.12
        ' ***************************************************************************************************
        ' Esecuzione asincrona del delegate
        method.BeginInvoke("Matteo Tumiati", AddressOf MyCallback, Nothing)

        Console.WriteLine("Esecuzione avviata")

        Console.ReadLine()

        ' ***************************************************************************************************
        ' Esempio 09.13
        ' ***************************************************************************************************
        ' Esecuzione asincrona del delegate
        method.BeginInvoke("Matteo Tumiati", AddressOf MyCallback1, method)

        Console.WriteLine("Esecuzione avviata")

        Console.ReadLine()

        ' ***************************************************************************************************
        ' Esempio 09.14
        ' ***************************************************************************************************
        ' Costruzione di un semplice task
        Dim simpleTask = Task.Factory.StartNew(
            Sub()
                Thread.Sleep(1000)
                Console.WriteLine("Ciao da simpleTask")
            End Sub)

        ' Costruzione di un task con parametro in input
        Dim parameterTask = Task.Factory.StartNew(
            Sub(name)
                Thread.Sleep(1000)
                Console.WriteLine("Ciao da parameterTask, {0}", name)
            End Sub, "Matteo Tumiati")

        ' Costruzione di un task che ritorna un risultato
        Dim resultTask = Task.Factory.StartNew(
            Function(inputValue) As Decimal
                Return PerformSomeLongCalculation(inputValue)
            End Function, 5000D)

        ' ***************************************************************************************************
        ' Esempio 09.15
        ' ***************************************************************************************************
        ' Creazione esplicita di un task
        Dim resultTask1 = New Task(
          Function(inputValue) As Decimal
              Return PerformSomeLongCalculation(inputValue)
          End Function, 5000D)

        ' Esecuzione
        resultTask1.Start()

        ' ***************************************************************************************************
        ' Esempio 09.16
        ' ***************************************************************************************************
        Dim resultTask2 = Task.Factory.StartNew(
            Function(inputValue) As Decimal
                Return PerformSomeLongCalculation(inputValue)
            End Function, 5000D)

        ' .. altro codice qui ..

        ' Determinazione del risultato
        Console.WriteLine("Il risultato è: {0}", resultTask2.Result)

        ' ***************************************************************************************************
        ' Esempio 09.17
        ' ***************************************************************************************************
        ' Attesa senza timeout
        Dim myTask = Task.Factory.StartNew(AddressOf SomeMethod)
        myTask.Wait()

        ' Attesa con timeout di 1 secondo
        myTask = Task.Factory.StartNew(AddressOf SomeMethod)
        myTask.Wait(1000)

        ' Attesa conclusione di uno tra myTask e anotherTask
        myTask = Task.Factory.StartNew(AddressOf SomeMethod)
        Dim anotherTask = Task.Factory.StartNew(AddressOf SomeMethod)
        Task.WaitAny(myTask, anotherTask)

        ' Attesa conclusione di una lista di Task, con timeout di 2 secondi
        Dim taskList As List(Of Task) = GetTaskList()
        Task.WaitAll(taskList.ToArray(), 2000)

        ' ***************************************************************************************************
        ' Esempio 09.18
        ' ***************************************************************************************************
        Dim problematicTask = Task.Factory.StartNew(
            Sub()
                Throw New ApplicationException("Errore!")
            End Sub)

        Try
            problematicTask.Wait()
        Catch ex As AggregateException
            Console.WriteLine("Il task ha sollevato la seguente eccezione:")
            Console.WriteLine(ex.InnerException)
        End Try

        ' ***************************************************************************************************
        ' Esempio 09.19
        ' ***************************************************************************************************
        Dim compositeTask = Task.Factory.StartNew(
            Sub()
                Thread.Sleep(1000)
                Console.WriteLine("Primo task")
            End Sub).ContinueWith(
            Sub()
                Thread.Sleep(1000)
                Console.WriteLine("Secondo task")
            End Sub)

        ' Accodamento di una funzione
        Dim resultTask3 = compositeTask.ContinueWith(
          Function(task As Task) As String
              Dim result2 = "Funzione del terzo task"
              Console.WriteLine(result2)
              Return result2
          End Function)

        Console.WriteLine("Il risultato è: {0}", resultTask3.Result)

        ' ***************************************************************************************************
        ' Esempio 09.20
        ' ***************************************************************************************************
        Dim taskList1 As List(Of Task) = GetTaskList()

        ' Task da eseguire al termine di tutti quelli contenuti in taskList
        Dim finalTask = Task.Factory.ContinueWhenAll(
          taskList.ToArray(),
          Sub() Console.WriteLine("Tutti i task completati con successo"))

        ' ***************************************************************************************************
        ' Esempio 09.21
        ' ***************************************************************************************************
        Dim outerTask = Task.Factory.StartNew(
            Sub()
                Dim innerTask = Task.Factory.StartNew(
                  Sub()
                      Thread.Sleep(2000)
                      Console.WriteLine("Nested Task")
                  End Sub)
                Console.WriteLine("First task")
            End Sub)

        outerTask.Wait()
        Console.WriteLine("outerTask Terminato")

        ' ***************************************************************************************************
        ' Esempio 09.22
        ' ***************************************************************************************************
        Dim outerTask1 = Task.Factory.StartNew(
            Sub()
                Dim innerTask = Task.Factory.StartNew(
                  Sub()
                      Thread.Sleep(2000)
                      Console.WriteLine("Child Task")
                  End Sub, TaskCreationOptions.AttachedToParent)
                Console.WriteLine("First task")
            End Sub)

        outerTask1.Wait()
        Console.WriteLine("outerTask Terminato")

        ' ***************************************************************************************************
        ' Esempio 09.23
        ' ***************************************************************************************************
        ' Creazione di una lista di numeri casuali
        Dim myList As New List(Of Integer)
        Dim rnd As New Random
        For index = 1 To 10000000
            myList.Add(rnd.Next(0, 100000))
        Next

        ' Query per recuperare i numeri primi
        Dim primes = From n In myList.AsParallel()
                     Where IsPrime(n)
                     Select n

        Dim sw = Stopwatch.StartNew()
        primes.Count()
        sw.Stop()

        Console.WriteLine("Esecuzione parallela: {0}", sw.Elapsed)

        ' ***************************************************************************************************
        ' Esempio 09.24
        ' ***************************************************************************************************
        Dim primes1 = From n In myList.AsParallel()
                      Where IsPrime(n)
                      Select n

        primes1.ForAll(Sub(item) DoSomething(item))

        ' ***************************************************************************************************
        ' Escuzione esempi 09.25 - 09.26 - 09.27 - 09.28 - 09.29
        ' ***************************************************************************************************

        Execute()

        Console.ReadLine()

        ' ***************************************************************************************************
        ' Esempio 09.30
        ' ***************************************************************************************************
        Dim myList1 As New List(Of String)
        myList1.Add("Elemento di test")

        Dim firstTask = Task.Factory.StartNew(
          Sub()
              If myList1.Count > 0 Then
                  ' race condition!
                  Console.WriteLine(myList1(0))
              End If
          End Sub)

        Dim secondTask = Task.Factory.StartNew(
          Sub()
              If myList1.Count > 0 Then
                  myList1.RemoveAt(0)
              End If
          End Sub)

        Task.WaitAll(firstTask, secondTask)

        ' ***************************************************************************************************
        ' Esempio 09.31
        ' ***************************************************************************************************
        Dim syncObject As New Object

        Dim myList2 As New List(Of String)
        myList2.Add("Elemento di test")

        Dim firstTask1 = Task.Factory.StartNew(
          Sub()
              Dim lockTaken As Boolean = False
              Monitor.Enter(syncObject, lockTaken)
              Try
                  If myList2.Count > 0 Then
                      Console.WriteLine(myList2(0))
                  End If
              Finally
                  If lockTaken Then
                      Monitor.Exit(syncObject)
                  End If
              End Try
          End Sub)

        Dim secondTask1 = Task.Factory.StartNew(
          Sub()
              Dim lockTaken As Boolean = False
              Monitor.Enter(syncObject, lockTaken)
              Try
                  If myList2.Count > 0 Then
                      myList2.RemoveAt(0)
                  End If
              Finally
                  If lockTaken Then
                      Monitor.Exit(syncObject)
                  End If
              End Try
          End Sub)

        Task.WaitAll(firstTask1, secondTask1)

        ' ***************************************************************************************************
        ' Esempio 09.32
        ' ***************************************************************************************************
        Dim myList3 As List(Of String) = GetList()

        ' Creazione del task che scorre la collection
        Dim firstTask2 = Task.Factory.StartNew(
          Sub()
              For Each item As String In myList3
                  DoSomething(item)
              Next
          End Sub)

        ' Creazione del task che modifica la collection
        Dim secondTask2 = Task.Factory.StartNew(
          Sub()
              myList3.Add("Task element")
          End Sub)

        Task.WaitAll(firstTask2, secondTask2)

        ' ***************************************************************************************************
        ' Esempio 09.33
        ' ***************************************************************************************************
        Dim myBag As New ConcurrentBag(Of String)(GetList())

        Dim firstTask3 = Task.Factory.StartNew(
          Sub()
              For Each item As String In myBag
                  DoSomething(item)
              Next
          End Sub)

        Dim secondTask3 = Task.Factory.StartNew(
          Sub()
              myBag.Add("Task element")
          End Sub)

        Task.WaitAll(firstTask3, secondTask3)

    End Sub

    Delegate Function SomeDelegate(ByVal parameter As String) As Integer

    Private Sub MyCallback(ByVal ar As IAsyncResult)
        Console.WriteLine("Esecuzione terminata")
    End Sub

    Private Sub MyCallback1(ByVal ar As IAsyncResult)
        Console.WriteLine("Esecuzione terminata")

        Dim method = DirectCast(ar.AsyncState, SomeDelegate)

        Dim result As Integer = method.EndInvoke(ar)
        Console.WriteLine("Il risultato è {0}", result)
    End Sub

    Public Function PerformSomeLongCalculation(ByVal inputValue As Object) As Decimal
        Return Convert.ToDecimal(inputValue)
    End Function

    Private Sub SomeMethod()

    End Sub

    Private Function GetTaskList() As List(Of Task)
        Dim result = New List(Of Task)

        result.Add(Task.FromResult(0))
        result.Add(Task.FromResult(0))

        Return result

    End Function

    Public Function IsPrime(ByVal n As Integer) As Boolean
        Dim upperDivisor = Math.Floor(Math.Sqrt(n))

        For divisor = 2 To upperDivisor
            If n Mod divisor = 0 Then
                Return False
            End If
        Next

        Return True
    End Function

    Private Sub DoSomething(ByVal i As Integer)

    End Sub

    Private Sub DoSomething(ByVal item As String)
        Thread.Sleep(10)
    End Sub

    Private Function GetList() As List(Of String)
        Dim result As New List(Of String)
        For index = 1 To 10
            result.Add("Test item " + index.ToString())
        Next

        Return result
    End Function
End Module
