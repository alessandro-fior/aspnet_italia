﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TCPL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += async (o, e) => await ReiceveDataAsync();
        }

        private async Task ReiceveDataAsync()
        {
            var server = new TcpListener(new IPEndPoint(IPAddress.Any, 1234));
            server.Start();
            while (true)
            {
                var localClient = await server.AcceptTcpClientAsync();
                var netStream = localClient.GetStream();
                if (netStream.CanRead)
                {
                    var dataStream = new MemoryStream();
                    var dataByte = new byte[1024];
                    int i = 0;
                    do
                    {
                        i = await netStream.ReadAsync(dataByte, 0, 1024);
                        if (i > 0)
                        {
                            await dataStream.WriteAsync(dataByte, 0, i);
                        }
                    }
                    while (i > 0);
                    dataStream.Seek(0, SeekOrigin.Begin);
                    var bmpImage = new BitmapImage();
                    bmpImage.BeginInit();
                    bmpImage.StreamSource = dataStream;
                    bmpImage.EndInit();
                    var img = new Image
                    {
                        Stretch = Stretch.Uniform,
                        Source = bmpImage
                    };
                    stackpanel1.Children.Add(img);
                }
                localClient.Close();
                netStream.Close();
            }
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            using (Stream fileStream = File.OpenRead(this.txb1.Text))
            {
                var client = new TcpClient();
                await client.ConnectAsync("localhost", 1234);
                var netStream = client.GetStream();
                var sendBuffer = new byte[1024];
                int bytesRead = 0;
                do
                {
                    bytesRead = await fileStream.ReadAsync(sendBuffer, 0, 1024);
                    if (bytesRead > 0)
                    {
                        netStream.Write(sendBuffer, 0, bytesRead);
                    }
                }
                while (bytesRead > 0);
                netStream.Close();
            }
        }
    }
}

