﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Net;

namespace HttpWebRequestApplication
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    Uri uploadUri;
    Stream fileStream;
    public delegate void ManageDataDelegate(string result);

    public MainWindow()
    {
      InitializeComponent();
    }

    private void Button2_Click(object sender, RoutedEventArgs e)
    {
      OpenFileDialog fileDialog = new OpenFileDialog
      {
        Filter = "immagini (*.jpg)|*.jpg"
      };

      bool? show = fileDialog.ShowDialog();
      if (show.HasValue & show.Value)
      {
        using (Stream fileStream = fileDialog.OpenFile())
        {
          this.TextBlock1.Text = fileDialog.SafeFileName;
          this.TextBlock1.Tag = fileDialog.FileName;
          MemoryStream dataStream = new MemoryStream();
          byte[] dataByte = new byte[1024];
          int i = 0;
          do
          {
            i = fileStream.Read(dataByte, 0, 1024);
            if (i > 0)
            {
              dataStream.Write(dataByte, 0, i);
            }
          }
          while (i > 0);
          dataStream.Seek(0, SeekOrigin.Begin);
          BitmapImage bmpImage = new BitmapImage();
          bmpImage.BeginInit();
          bmpImage.StreamSource = dataStream;
          bmpImage.EndInit();
          this.Image1.Source = bmpImage;
          this.uploadUri = new Uri(string.Format("http://localhost:1503/Upload.aspx?path={0}", fileDialog.SafeFileName));
        }
      }
    }

    private void Button1_Click(object sender, RoutedEventArgs e)
    {
      this.fileStream = File.OpenRead(this.TextBlock1.Tag.ToString());
      HttpWebRequest request = (HttpWebRequest)WebRequest.Create(this.uploadUri);
      request.Method = "POST";
      IAsyncResult result = request.BeginGetRequestStream(new AsyncCallback(this.GetRequestStreamCallback), request);
    }

    private void GetRequestStreamCallback(IAsyncResult asynchronousResult)
    {
      HttpWebRequest request = (HttpWebRequest)asynchronousResult.AsyncState;
      Stream postStream = request.EndGetRequestStream(asynchronousResult);
      byte[] sendBuffer = new byte[1024];
      int bytesRead = 0;
      do
      {
        bytesRead = this.fileStream.Read(sendBuffer, 0, 1024);
        if (bytesRead > 0)
        {
          postStream.Write(sendBuffer, 0, bytesRead);
        }
      }
      while (bytesRead > 0);
      request.BeginGetResponse(new AsyncCallback(this.GetResponseCallback), request);
    }

    private void GetResponseCallback(IAsyncResult asynchronousResult)
    {
      HttpWebResponse response = (HttpWebResponse)((HttpWebRequest)asynchronousResult.AsyncState).EndGetResponse(asynchronousResult);
      Stream streamResponse = response.GetResponseStream();
      StreamReader streamRead = new StreamReader(streamResponse);
      string responseString = streamRead.ReadToEnd();
      this.Dispatcher.BeginInvoke(new ManageDataDelegate(this.ViewData), new object[] { responseString });
      streamResponse.Close();
      streamRead.Close();
      response.Close();
      this.fileStream.Close();
    }

    private void ViewData(string datas)
    {
      this.TextBlock1.Text = datas;
    }
  }
}
