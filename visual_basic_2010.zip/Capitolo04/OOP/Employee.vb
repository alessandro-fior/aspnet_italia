﻿Namespace Aspitalia.Books.Chapter4

    ' Classe derivata
    Public Class Employee
        Inherits Person

        ' Campo privato
        Private _firstName As String

        ' Costruttore con parametri 
        Public Sub New(ByVal name As String, ByVal age As Integer)
            MyBase.FullName = name
            MyBase.Age = age

            ' Viene chiamato il metodo della classe base
            _firstName = MyBase.GetFirstName()
        End Sub

        ' Override di un metodo virtuale
        Public Overrides Function GetFirstName() As String
            Return _firstName
        End Function

        ' Override di un metodo astratto
        Public Overrides Sub Print()
            Console.Write(MyBase.FullName)
        End Sub

    End Class

End Namespace

