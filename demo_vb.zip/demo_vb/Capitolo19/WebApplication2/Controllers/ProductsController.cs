﻿using DataModel;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Web.Http;
using System.Linq;
using System.Web.Http.Controllers;
using System.Net.Http;
using System.Net;
using System.Threading;

namespace WebApplication1.Controllers
{
	public class ProductsController : ApiController
	{
		private static readonly Lazy<ConcurrentDictionary<int, Product>> _storage = new Lazy<ConcurrentDictionary<int, Product>>(() => new ConcurrentDictionary<int, Product>());
		private static ConcurrentDictionary<int, Product> Storage { get { return _storage.Value; } }

		protected override void Initialize(HttpControllerContext controllerContext)
		{
			BuildStorage();

			base.Initialize(controllerContext);
		}
		private void BuildStorage()
		{
			if (Storage.IsEmpty)
			{
				var p1 = new Product
				{
					Id = 1,
					Name = "Product1",
					Category = "Category1",
					Price = 10
				};
				Storage.TryAdd(1, p1);

				var p2 = new Product
				{
					Id = 2,
					Name = "Product2",
					Category = "Category2",
					Price = 20
				};
				Storage.TryAdd(2, p2);
			}
		}

		// GET api/products
		public IEnumerable<Product> Get()
		{
			return Storage.Values.AsEnumerable();
		}

		// GET api/products/5
		public Product Get(int id)
		{
			Thread.Sleep(1000);

			Product product;
			Storage.TryGetValue(id, out product);

			return product;
		}

		// POST api/products
		public HttpResponseMessage Post(Product value)
		{
			Storage.TryAdd(value.Id, value);

			HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, value);

			string itemUri = Url.Route(null, new { id = value.Id });
			response.Headers.Location = new Uri(Request.RequestUri, itemUri);

			return response;
		}

		// PUT api/products/5
		public Product Put(int id, Product value)
		{
			Product product;
			Storage.TryGetValue(id, out product);

			Storage.TryUpdate(value.Id, value, product);

			Storage.TryGetValue(id, out product);
			return product;
		}

		// DELETE api/products/5
		public Product Delete(int id)
		{
			Product product;
			Storage.TryRemove(id, out product);
			return product;
		}
	}
}
