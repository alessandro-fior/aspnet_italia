﻿Imports System.Data.Entity
Imports System.Data.SqlClient
Imports System.Text
Imports System.Transactions

Module Program

	Sub Main(args As String())
		QuerySingolo()
		Console.ReadLine()
	End Sub

	Private Sub DeleteCustomerDisconnected()
		Dim custToDelete As Customers

		Using ctx = New NorthwindModel
			custToDelete = ctx.Customers.Find("STEMO")
		End Using

		Using ctx = New NorthwindModel
			ctx.Customers.Attach(custToDelete)
			ctx.Customers.Remove(custToDelete)
		End Using
	End Sub

	Private Sub DeleteCustomerConnected()
		Using ctx = New NorthwindModel
			Dim cust = ctx.Customers.Find("STEMO")
			ctx.Customers.Remove(cust)
		End Using
	End Sub

	Private Sub UpdateCustomerDisconnected()
		Dim cust As Customers

		Using ctx = New NorthwindModel
			cust = ctx.Customers.Find("STEMO")
		End Using

		cust.Address = "Piazza Venezia 10"

		Using ctx = New NorthwindModel
			ctx.Customers.Attach(cust)
			ctx.Entry(cust).State = EntityState.Modified
			ctx.SaveChanges()
		End Using
	End Sub

	Private Sub UpdateCustomerConnected()
		Using ctx As NorthwindModel = New NorthwindModel
			Dim cust = ctx.Customers.Find("STEMO")
			cust.Address = "Piazza del popolo 1"
			ctx.SaveChanges()
		End Using
	End Sub

	Private Sub InsertCustomer()
		Using ctx As NorthwindModel = New NorthwindModel
			Dim c = New Customers With {
																																.CustomerID = "STEMO",
																																.CompanyName = "Stefano Mostarda",
																																.ContactName = "Stefano Mostarda",
																																.Address = "Via Del Corso 14",
																																.City = "Roma",
																																.Country = "Italy",
																																.PostalCode = "00100",
																																.Region = "Lazio",
																																.ContactTitle = "Sig",
																																.Phone = "00000",
																																.Fax = "00000"
																								}
			ctx.Customers.Add(c)
			ctx.SaveChanges()
		End Using
	End Sub

	Private Sub QueryInclude()
		Using ctx = New NorthwindModel
			Dim orders = ctx.Orders.Include(Function(o) o.Order_Details)

			For Each o In orders
				Console.WriteLine($"{o.OrderID}-{o.Order_Details.Count}")
			Next
		End Using
	End Sub

	Private Sub QueryProjection()
		Using ctx = New NorthwindModel
			Dim customers = ctx.Customers.[Select](Function(c) New With {c.CustomerID, c.CompanyName
																								})

			For Each cust In customers
				Console.WriteLine($"{cust.CustomerID}-{cust.CompanyName}")
			Next
		End Using
	End Sub

	Private Sub QuerySingolo()
		Using ctx = New NorthwindModel
			Dim item1 = ctx.Customers.First(Function(c) c.CustomerID = "ALFKI")
			Dim item2 = ctx.Customers.Find("ALFKI")
			Console.WriteLine(item1.CustomerID)
		End Using
	End Sub

	Private Sub QueryLista()
		Dim it = "Italy"
		Using ctx = New NorthwindModel
			Dim customers1 = From c In ctx.Customers Where c.Country.Equals(it) Select c
			Dim customers2 = ctx.Customers.Where(Function(c) c.Country.Equals(it))
			Console.WriteLine(customers1.Count())
			Console.WriteLine(customers2.Count())
		End Using
	End Sub

End Module
