﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LINQ {
	public class DettaglioOrdine {
		public int Id { get; set; }
		public int Quantita { get; set; }
		public double Prezzo { get; set; }
		public Prodotto Prodotto { get; set; }
	}
}