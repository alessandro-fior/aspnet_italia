﻿Public Module Calculator
	Public Function Sum(
	  ByVal x As Integer,
	  ByVal y As Integer) As Integer
		' Ritorna la somma dei due numeri
		Return x + y
	End Function

	Public Function Divide(
	  ByVal x As Integer,
	  ByVal y As Integer) As Integer
		' Ritorna la divisione intera dei due numeri
		Return x \ y
	End Function

End Module
