﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chapter11
{
    class Program
    {
        static void Main(string[] args)
        {   
            //Sample3.Run()
            //Sample4.Run()
            //Sample7.Run()
            //Sample8.Run()
            //Sample11.Run()
            //Sample12.Run()
            //Sample15.Run()
            //Sample16.Run()
            //Sample17.Run()
            //Sample18.Run()
            Sample20.Run();
       }
    }
}
