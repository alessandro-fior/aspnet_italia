﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASPItalia.Books.Chapter4
{
    // Interfaccia che definisce un metodo per la scrittura
    public interface ILogger
    {
        void Log(string what, string category);
        void Log(string what) => Log(what, "Default");
    }

}
