﻿using System.Collections.Generic;
using System.Globalization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Localization.Routing;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Middleware.Providers;

namespace Middleware
{
    public class Startup
    {
        // 1. Verificare la lingua italiana e verificare di ottenere come provider l'AcceptLanguageHeaderRequestCultureProvider
        // http://localhost:5000/

        // 2. Impostare una nuova lingua (inglese) tramite cookie
        // http://localhost:5000/Home/SetCulture?value=en-US

        // 3. Verificare che nella index il valore mostrato sia l'inglese appena impostato e il provider sia il CookieRequestCultureProvider
        // Verificare anche che, nonostante ci sia la UI-Culture con "en-US" come recuperato dal cookie, la cultura impostata corrisponde ad "es" perché il fallback è disabilitato e pertanto viene recuperato il file di risorse generico, in inglese.
        // http://localhost:5000/

        // 4. Impostare la nuova lingua tramite route e verificare che venga fornita la cultura italiana
        // Verificare anche che il provider in questo caso sia il RouteDataRequestCultureProvider
        // http://localhost:5000/it-IT/Home/Index

        // 5. Navigare alla route senza la cultura e verificare che ci sia ancora la lingua inglese
        // http://localhost:5000/

        // 6. Togliere il RouteDataRequestCultureProvider dalla lista dei provider ed il middleware CustomRouteLocalizationMiddleware dal controller Home
        // Riavviare l'applicazione e notare che i contenuti vengono ancora forniti in inglese
        // http://localhost:5000/

        // 7. Navigare sulla route italiana e notare che vengono forniti tramite il CustomRouteDataCultureProvider 
        // http://localhost:5000/it-IT/Home/Index

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddLocalization(options =>
            {
                options.ResourcesPath = "Resources";
            });

            services.Configure<RequestLocalizationOptions>(options =>
            {
                options.SupportedUICultures = new List<CultureInfo> {
                    new CultureInfo("it-IT"),
                    new CultureInfo("en-US")
                };

                options.SupportedCultures = new List<CultureInfo> {
                    new CultureInfo("it-IT"),
                    new CultureInfo("en-US")
                };

                options.FallBackToParentUICultures = false;
                options.FallBackToParentCultures = false;
                options.DefaultRequestCulture = new RequestCulture("es");

                //options.RequestCultureProviders.Insert(0, new RouteDataRequestCultureProvider());
                options.RequestCultureProviders.Insert(0, new CustomRouteDataCultureProvider());
            });

            services.AddMvc()
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseRequestLocalization();

            app.UseMvc(routes =>
            {
                routes.MapRoute(name: "defaultWithCulture",
                    template: "{culture}/{controller=Home}/{action=Index}/{value?}"
                    );
            });

            app.UseMvcWithDefaultRoute();
        }
    }
}