﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Chapter16.Core.Models;
using Microsoft.AspNetCore.Mvc;

namespace Chapter16.Core.Controllers
{
    public class AdminController : Controller
    {
        readonly StoreContext db;
        public AdminController(StoreContext db)
        {
            this.db = db;
        }


        public IActionResult Index()
        {
            return View(db.Customers.ToList());
        }

        public IActionResult Details(int id = 0)
        {
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }

        //
        // GET: /Admin/Create

        public IActionResult Create()
        {
            return View();
        }

        //
        // POST: /Admin/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Customer customer)
        {
            if (ModelState.IsValid)
            {
                db.Customers.Add(customer);
                db.SaveChanges();

                return RedirectToAction(nameof(Details), new { id = customer.Id });
            }

            return View(customer);
        }

        //
        // GET: /Admin/Edit/5

        public IActionResult Edit(int id = 0)
        {
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }

        //
        // POST: /Admin/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Customer customer)
        {
            if (ModelState.IsValid)
            {
                // opzione 1: prendiamo il dato dal db e applichiamo le differenze
                var dbItem = db.Customers.First(x => x.Id == customer.Id);
                if (await TryUpdateModelAsync<Customer>(dbItem))
                {
                    // opzione 2: segniamo tutto come modificato
                    //db.Entry(customer).State = EntityState.Modified;
                    db.SaveChanges();

                    return RedirectToAction(nameof(Details), new { id = dbItem.Id });
                }
            }

            return View(customer);
        }

        //
        // GET: /Admin/Delete/5

        public IActionResult Delete(int id = 0)
        {
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }

        //
        // POST: /Admin/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            Customer customer = db.Customers.Find(id);
            db.Customers.Remove(customer);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}