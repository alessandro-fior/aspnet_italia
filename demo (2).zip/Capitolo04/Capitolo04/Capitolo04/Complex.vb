﻿' Definizione di una struttura per i numeri complessi
Public Structure Complex

	Public Property Real As Single      ' Parte reale
	Public Property Imaginary As Single ' Parte immaginaria

	' Costruttore con parametri
	Public Sub New(ByVal r As Single, ByVal i As Single)
		Me.Real = r
		Me.Imaginary = i
	End Sub

	' Metodo statico per la somma di due numeri complessi
	Public Shared Function Sum(ByVal x As Complex,
							   ByVal y As Complex) As Complex
		Return New Complex(x.Real + y.Real, x.Imaginary + y.Imaginary)
	End Function

	Public Shared Function Sum(ByVal x As Complex,
				   ByVal y As Complex) As Complex
		Return New Complex(x.Real + y.Real, x.Imaginary + y.Imaginary)
	End Function

	Public Shared Operator +(ByVal x As Complex,
						   ByVal y As Complex) As Complex
		Return New Complex(x.Real + y.Real, x.Imaginary + y.Imaginary)
	End Operator
	Public Shared Operator -(ByVal x As Complex,
						   ByVal y As Complex) As Complex
		Return New Complex(x.Real - y.Real, x.Imaginary - y.Imaginary)
	End Operator

End Structure

