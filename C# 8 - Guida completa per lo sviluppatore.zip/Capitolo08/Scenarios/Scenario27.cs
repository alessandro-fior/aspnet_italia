﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario27
    {
        /// <summary>
        /// Esempio 8.36, 8.37, 8.38
        /// </summary>
        public static void Run()
        {
            Task.Factory.StartNew(async () =>
            {
                await foreach (var number in AddNumbersAsyncWithYield())
                {
                    Console.WriteLine(number);
                }
            })
            .Wait();            
        }

        public static async Task<IEnumerable<int>> AddNumbersAsync()
        {
            var collection = new List<int>();

            for (int i = 0; i < 20; i++)
            {
                collection.Add(await GetDataAsync(i));
            }

            return collection;
        }

        public static async IAsyncEnumerable<int> AddNumbersAsyncWithYield()
        {
            for (int i = 0; i < 20; i++)
            {
                yield return await GetDataAsync(i);
            }
        }

        private static async Task<int> GetDataAsync(int i)
        {
            await Task.Delay(1000);
            return i;
        }
    }
}