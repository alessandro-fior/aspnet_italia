﻿namespace DemoWebAPI.Models
{
    public class CustomerForUpdate
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}