﻿
Partial Class _03_Form
	Inherits System.Web.UI.Page

	Sub ShowFirstName(ByVal sender As Object, ByVal e As EventArgs)
		EntryForm.Visible = False
		Results.Visible = True
		SelectedFirstName.Text = FirstName.Text
	End Sub


End Class
