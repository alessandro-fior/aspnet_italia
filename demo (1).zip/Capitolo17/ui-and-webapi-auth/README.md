# Usare sia Cookie che JWT Token come meccanismi di autenticazione
In questa applicazione ASP.NET Core è presente sia una parte di UI che una Web API che possiedono meccanismi di autenticazione differenti.
 * La parte **UI** è composta da pagine che permettono all'utente di registrarsi ed effettuare il login. Dopo il login, l'utente verrà riconosciuto grazie al cookie di autenticazione e potrà così accedere alle pagine di gestione del profilo;
 * La parte **Web API** è accessibile cliccando la voce di menu `Web Api Demo`. Inserendo le credenziali di un utente registrato, partirà una richiesta ajax per ottenere un Token JWT. Il token deve essere incluso in tutte le successive richieste per consumare le operazioni protette della Web API.

 ##  Configurazione
 Nella classe [Startup](Startup.cs) è stato aggiunto il supporto all'autenticazione con Token JWT, mentre l'autenticazione basata sui cookie è abilitata per default.

 ## Peculiarità dei token JWT
 Nell'autenticazione basata su Token JWT, il client invia una prima richiesta fornendo le proprie credenziali per ottenere un token. Il token viene creato dal server e consegnato al client per mezzo di un'intestazione o nel corpo della risposta. Il client quindi lo memorizza in una variabile o nello storage del dispositivo e lo restituisce al server come intestazione `Authorization` in tutte le successive richieste, specificando `Bearer` come _scheme_ di autenticazione. 

 ![jwt-token.png](jwt-token.png)

 Il token JWT viene creato con una data di scadenza che può essere più o meno lunga, a seconda degli scenari di utilizzo. Se vogliamo garantire un buon livello di sicurezza possiamo creare token short-lived, ovvero con una scadenza molto breve (in quest'applicazione, 1 minuto, come configurato nell'[appsettings.json](appsettings.son)). Fintanto che il client invia richieste ad una qualsiasi action della Web API, il server potrà restituirgli nuovi token con scadenza rinnovata, permettendogli di continuare indefinitamente senza dover reinserire le credenziali. Per contro, username e password dovranno essere reinserite se l'utente resta inattivo e lascia scadere il token.