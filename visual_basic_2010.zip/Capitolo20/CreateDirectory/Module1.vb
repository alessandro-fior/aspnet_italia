﻿Imports System
Imports System.IO

Module Module1
    Sub Main()
        Try
            Directory.CreateDirectory(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments), "Capitolo20"))
            Console.WriteLine("Cartella creata correttamente")
        Catch ex As Exception
            Console.WriteLine("Impossibile creare la cartella: {0}", ex.ToString())
        End Try
        Console.ReadLine()
    End Sub
End Module
