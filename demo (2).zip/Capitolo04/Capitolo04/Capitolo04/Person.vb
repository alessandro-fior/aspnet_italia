﻿Public Class Person

	' Campo privato che contiene il nome completo (nome e cognome)
	' Il campo è inizializzato con il valore "Sconosciuto"
	Private _fullName As String = "Sconosciuto"

	' Campo privato che contiene l'età
	' Il campo è implicitamente inizializzato con il valore 0
	Private _age As Integer

	' Costruttore senza parametri
	Public Sub New()

	End Sub

	' Costruttore con parametri
	Public Sub New(ByVal name As String, ByVal age As Integer)
		_fullName = name
		_age = age
	End Sub

	' Proprietà pubblica che espone il campo contenente il nome
	Public Property FullName() As String
		Get
			Return _fullName
		End Get
		Set(ByVal value As String) ' Va specificato il parametro
			_fullName = value
		End Set
	End Property

	' Proprietà pubblica che espone il campo contenente l'età
	Public Property Age() As Integer
		Get
			Return _age
		End Get
		Set(ByVal value As Integer)
			_age = value
		End Set
	End Property

	Public Function GetFirstName() As String
		Return Me.FullName.Split(" ")(0)
	End Function

	' Metodo statico
	Public Shared Function GetFirstName(ByVal name As String) As String
		Return name.Split(" "c)(0)
	End Function

End Class

