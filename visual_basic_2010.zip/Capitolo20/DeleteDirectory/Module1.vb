﻿Imports System
Imports System.IO

Module Module1
    Sub Main()
        Dim myPath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments), "Capitolo20")
        Try
            Directory.CreateDirectory(myPath)
            Console.WriteLine("Cartella creata correttamente, premi un tasto per eliminarla")
            Console.ReadLine()
            Directory.Delete(myPath)
            Console.WriteLine("Cartella Eliminata correttamente")
        Catch ex As Exception
            Console.WriteLine("Impossibile creare la cartella: {0}", ex.ToString())
        End Try
        Console.ReadLine()
    End Sub
End Module
