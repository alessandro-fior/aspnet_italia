﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario18
    {
        /// <summary>
        /// Esempio 8.20
        /// </summary>
        public static void Run()
        {
            List<Task> taskList = GetTaskList();

            // Task da eseguire al termine di tutti quelli contenuti in tasklist
            var finalTask = Task.Factory.ContinueWhenAll(
                taskList.ToArray(),
                (tl) => Console.WriteLine("Tutti i task completati con successo"));
        }

        private static List<Task> GetTaskList()
        {
            return new List<Task>();
        }
    }
}