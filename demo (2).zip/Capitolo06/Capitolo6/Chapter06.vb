﻿Imports System.Threading

Namespace ASPItalia.Books.Chapter06
    Module Chapter06

        Function FindStringsWithA(ByVal item As String) As Boolean
            Return item.StartsWith("a")
        End Function

        Private Sub consoleWriter(ByVal timestamp As DateTime, ByVal message As String)
            Console.WriteLine(
              String.Format("{0} - {1}", timestamp, message))
        End Sub

        Delegate Function SampleDelegate(ByVal input As String) As String

        Public Function VeryLongEchoFunction(ByVal input As String) As String
            Thread.Sleep(3000)
            Return "Hello " + input
        End Function

        Public Delegate Function MyDelegate(Of T As Structure)(ByVal input As T) As String

        Private Function DateTimeWriter(ByVal input As DateTime) As String
            Return input.ToShortDateString()
        End Function

        Sub Main()

            ' ****************************************************************************************************
            ' Esempio 6.1
            ' ****************************************************************************************************

            Dim strings As New List(Of String)

            strings.Add("This is a test")
            strings.Add("abcdefgh")
            strings.Add("a1234567")

            'Utilizzo del predicate come argomento di Find
            Dim foundString = strings.Find(AddressOf FindStringsWithA)

            'Stampa abcdefgh sulla console
            Console.WriteLine(foundString)

            ' ****************************************************************************************************
            ' Esempio 6.3
            ' ****************************************************************************************************
            Dim myLogger As New Logger(AddressOf consoleWriter)

            'Stampa sulla console il messaggio in basso
            myLogger.Log("Messaggio di esempio")

            ' ****************************************************************************************************
            ' Esempio 6.4
            ' ****************************************************************************************************
            Dim writer As New FileLogWriter("c:\somefile.txt")
            Dim writerDelegate As StringLogWriter = AddressOf writer.Write

            Console.WriteLine(writerDelegate.Method)

            Console.WriteLine(
              DirectCast(writerDelegate.Target, FileLogWriter).FileName)

            ' ****************************************************************************************************
            ' Esempio 6.5
            ' ****************************************************************************************************
            ' Definizione del primo delegate
            Dim writer1 As New FileLogWriter("c:\somefile.txt")
            Dim fileDelegate As New StringLogWriter(AddressOf writer1.Write)

            ' Definizione del secondo delegate
            Dim consoleDelegate As New StringLogWriter(AddressOf consoleWriter)

            'combinazione dei delegate
            Dim combinedDelegate As StringLogWriter = DirectCast(
              [Delegate].Combine(consoleDelegate, fileDelegate), StringLogWriter)

            Dim myLogger1 As New Logger(combinedDelegate)

            'Scrive sulla console e su file il messaggio in basso
            myLogger1.Log("Messaggio di esempio")

            ' ****************************************************************************************************
            ' Esempio 6.6
            ' ****************************************************************************************************
            For Each item As [Delegate] In combinedDelegate.GetInvocationList()
                Console.WriteLine(item.Method)
            Next

            combinedDelegate = DirectCast(
              [Delegate].Remove(combinedDelegate, fileDelegate), StringLogWriter)

            Console.WriteLine(vbCrLf + "Dopo la rimozione:")
            For Each item As [Delegate] In combinedDelegate.GetInvocationList()
                Console.WriteLine(item.Method)
            Next

            ' ****************************************************************************************************
            ' Esempio 6.7
            ' ****************************************************************************************************
            Dim myEcho As New SampleDelegate(AddressOf VeryLongEchoFunction)

            Console.WriteLine(myEcho("Cristian"))
            Console.WriteLine(myEcho("Daniele"))
            Console.WriteLine(myEcho("Matteo"))

            ' ****************************************************************************************************
            ' Esempio 6.8
            ' ****************************************************************************************************
            'esecuzione parallela delle tre VeryLongEchoFunction
            Dim results As New List(Of IAsyncResult)
            results.Add(myEcho.BeginInvoke("Cristian", Nothing, Nothing))
            results.Add(myEcho.BeginInvoke("Daniele", Nothing, Nothing))
            results.Add(myEcho.BeginInvoke("Matteo", Nothing, Nothing))

            'Recupero dei risultati e stampa sulla console
            For Each result As IAsyncResult In results
                Console.WriteLine(myEcho.EndInvoke(result))
            Next

            ' ****************************************************************************************************
            ' Esempio 6.9
            ' ****************************************************************************************************
            Dim sample As New MyDelegate(Of DateTime)(AddressOf DateTimeWriter)

            ' ****************************************************************************************************
            ' Esempio 6.10
            ' ****************************************************************************************************
            Dim funcSample As New Func(Of DateTime, String)(AddressOf DateTimeWriter)

            ' ****************************************************************************************************
            ' Esempio 6.11
            ' ****************************************************************************************************
            foundString = strings.Find(Function(s) s.StartsWith("a"))

            ' ****************************************************************************************************
            ' Esempio 6.12
            ' ****************************************************************************************************
            Dim searchString = "B"
            foundString = strings.Find(Function(s) s.StartsWith(searchString))
        End Sub

    End Module
End Namespace
