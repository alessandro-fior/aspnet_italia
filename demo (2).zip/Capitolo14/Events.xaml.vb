﻿Public Class Events

    Private Sub Window_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Input.MouseButtonEventArgs)
        MessageBox.Show("Pulsante premuto su " &
                        e.OriginalSource.GetType().Name)
    End Sub

    Private Sub Rectangle_MouseUp(sender As Object, e As MouseButtonEventArgs)
        e.Handled = True
    End Sub
End Class
