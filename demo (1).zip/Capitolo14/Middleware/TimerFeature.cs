﻿using System.Diagnostics;

namespace Capitolo14.Middleware
{
    public class TimerFeature : ITimerFeature
    {
        public Stopwatch Stopwatch { get; }

        public TimerFeature(Stopwatch stopwatch)
        {
            Stopwatch = stopwatch;
        }
    }
}
