﻿using Microsoft.EntityFrameworkCore;

namespace Chapter16.Core.Models
{
    public class StoreContext : DbContext
    {
        public StoreContext(DbContextOptions<StoreContext> o) : base(o)
        {

        }
        public DbSet<Customer> Customers { get; set; }
    }
}