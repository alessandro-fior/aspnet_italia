﻿Imports Chapter16.MVC.Models
Imports System.Linq
Imports System.Data.Entity

Public Class HomeController
    Inherits System.Web.Mvc.Controller

    Function Index() As ActionResult
        Using db = New StoreContext()
            Dim customers = db.Customers.OrderBy(Function(f) f.Id).Take(5)
            Return View(customers.ToList())
        End Using
    End Function

    Function About() As ActionResult
        ViewData("Message") = "Your application description page."

        Return View()
    End Function

    Function Contact() As ActionResult
        ViewData("Message") = "Your contact page."

        Return View()
    End Function
End Class
