using System.Collections.Generic;
using System.Linq;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace UiAndApiAuth.Services
{
    public class DocumentApiFilter : IDocumentFilter
    {
        public void Apply(SwaggerDocument swaggerDoc, DocumentFilterContext context)
        {
            swaggerDoc.Security = new List<IDictionary<string, IEnumerable<string>>>()
            {
                new Dictionary<string, IEnumerable<string>>()
                {
                    { "JWT Bearer Token", new string[]{ } }
                }
            };

            var hiddenPaths = swaggerDoc.Paths.Keys
            .Where(key => !key.StartsWith("/api/")).ToList();
            foreach (var hiddenPath in hiddenPaths) {
                swaggerDoc.Paths.Remove(hiddenPath);    
            }
        }
    }
}