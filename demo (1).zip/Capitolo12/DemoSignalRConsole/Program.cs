﻿using Microsoft.AspNetCore.SignalR.Client;
using System;
using System.Threading.Tasks;

namespace DemoSignalRConsole
{
    class Program
    {
        private static HubConnection _connection;
        private static HubConnection _streamingConnection;

        static async Task Main(string[] args)
        {
            // avvia la connession
            await StartConnectionAsync();

            // ad ogni messaggio ricevuto su 'broadcastMessage', stampa sender e messaggio inviato
            _connection.On<string, string>("broadcastMessage", (name, message) => Console.WriteLine($"{name}: {message}"));

            // registrazione allo stream e stampa dei messaggi ricevuti
            var channel = await _streamingConnection.StreamAsChannelAsync<string>("StartStreaming");

            // lettura dei messaggi in arrivo
            while (await channel.WaitToReadAsync())
            {
                while (channel.TryRead(out string message))
                {
                    Console.WriteLine($"Message received: {message}");
                }
            }

            Console.ReadLine();
            await DisposeAsync();
        }

        /// <summary>
        /// Stabilisce la connessione con il server per chat e streaming
        /// </summary>
        /// <returns></returns>
        public static async Task StartConnectionAsync()
        {
            _connection = new HubConnectionBuilder()
                 .WithUrl("http://localhost:5000/chat")
                 .Build();

            _streamingConnection = new HubConnectionBuilder()
                .WithUrl("http://localhost:5000/streaming")
                // .WithMessagePackProtocol()
                .Build();
            
            await _connection.StartAsync();
            await _streamingConnection.StartAsync();
        }

        /// <summary>
        /// Rilascia tutte le connessioni
        /// </summary>
        /// <returns></returns>
        public static async Task DisposeAsync()
        {
            await _connection.DisposeAsync();
            await _streamingConnection.DisposeAsync();
        }
    }
}