using System.ComponentModel.DataAnnotations;

namespace UiAndApiAuth.Models.Dto
{
    public class TokenRequest {
        [Required]
        public string Username  { get; set; }
        [Required]
        public string Password { get; set; }
    }
}