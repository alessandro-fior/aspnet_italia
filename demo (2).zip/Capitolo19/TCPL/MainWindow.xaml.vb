﻿Imports System.IO
Imports System.Net
Imports System.Net.Sockets

Class MainWindow
    Private Sub Window_Loaded(sender As Object, e As RoutedEventArgs)
        ReiceveDataAsync()

    End Sub
    Private Async Function ReiceveDataAsync() As Task
        Dim server = New TcpListener(New IPEndPoint(IPAddress.Any, 1234))
        server.Start()

        While True
            Dim localClient = Await server.AcceptTcpClientAsync()
            Dim netStream = localClient.GetStream()

            If netStream.CanRead Then
                Dim dataStream = New MemoryStream()
                Dim dataByte = New Byte(1023) {}
                Dim i As Integer = 0

                Do
                    i = Await netStream.ReadAsync(dataByte, 0, 1024)

                    If i > 0 Then
                        Await dataStream.WriteAsync(dataByte, 0, i)
                    End If
                Loop While i > 0

                dataStream.Seek(0, SeekOrigin.Begin)
                Dim bmpImage = New BitmapImage()
                bmpImage.BeginInit()
                bmpImage.StreamSource = dataStream
                bmpImage.EndInit()
                Dim img = New Image With {
                    .Stretch = Stretch.Uniform,
                    .Source = bmpImage
                }
                stackpanel1.Children.Add(img)
            End If

            localClient.Close()
            netStream.Close()
        End While
    End Function

    Private Async Sub Button_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Using fileStream As Stream = File.OpenRead(Me.txb1.Text)
            Dim client = New TcpClient()
            Await client.ConnectAsync("localhost", 1234)
            Dim netStream = client.GetStream()
            Dim sendBuffer = New Byte(1023) {}
            Dim bytesRead As Integer = 0

            Do
                bytesRead = Await fileStream.ReadAsync(sendBuffer, 0, 1024)

                If bytesRead > 0 Then
                    netStream.Write(sendBuffer, 0, bytesRead)
                End If
            Loop While bytesRead > 0

            netStream.Close()
        End Using
    End Sub
End Class
