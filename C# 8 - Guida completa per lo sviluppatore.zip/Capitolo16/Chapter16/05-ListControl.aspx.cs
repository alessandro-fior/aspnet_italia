﻿using Chapter16.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Chapter16
{
    public partial class _05_ListControl : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (var entities = new NorthwindContext())
            {
                var customers = entities.Customers.OrderBy(c => c.CompanyName);
                DropDownList1.DataSource = customers.ToList();
                DropDownList1.DataBind();
            }
        }
    }
}