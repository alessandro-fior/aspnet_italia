﻿using System;
using System.Collections.Generic;

namespace Capitolo5.Scenarios
{
    public static class Scenario14
    {
        /// <summary>
        /// Esempio 5.19
        /// </summary>
        public static void Run()
        {
            var strings = new List<string>();
            PrintItems(strings);
        }

        // verificare che decommentando questo metodo viene generato un errore
        //private static void PrintItems(List<object> list)
        //{
        //    foreach (var item in list)
        //    {
        //        Console.WriteLine(item);
        //    }
        //}

        private static void PrintItems(IEnumerable<object> list)
        {
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
        }
    }
}