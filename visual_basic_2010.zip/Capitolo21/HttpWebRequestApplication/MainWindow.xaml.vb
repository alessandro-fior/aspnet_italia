﻿Imports Microsoft.Win32
Imports System.IO
Imports System.Net.Sockets
Imports System.Threading
Imports System.Net

Class MainWindow

  Dim uploadUri As Uri
  Dim fileStream As Stream
  Public Delegate Sub ManageDataDelegate(ByVal result As String)

  Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button2.Click
    Dim fileDialog As New OpenFileDialog()
    fileDialog.Filter = "immagini (*.jpg)|*.jpg"
    Dim show As Boolean? = fileDialog.ShowDialog()
    If show IsNot Nothing And show.Value = True Then
      Using fileStream As Stream = fileDialog.OpenFile()
        TextBlock1.Text = fileDialog.SafeFileName
        TextBlock1.Tag = fileDialog.FileName

        Dim dataStream As MemoryStream = New MemoryStream()
        Dim dataByte As Byte() = New Byte(1023) {}
        Dim i As Integer = 0

        Do
          i = fileStream.Read(dataByte, 0, 1024)
          If i > 0 Then
            dataStream.Write(dataByte, 0, i)
          End If
        Loop While i > 0

        dataStream.Seek(0, SeekOrigin.Begin)

        Dim bmpImage As BitmapImage = New BitmapImage()
        bmpImage.BeginInit()
        bmpImage.StreamSource = dataStream
        bmpImage.EndInit()
        Image1.Source = bmpImage

        uploadUri = New Uri(String.Format( _
                            "http://localhost:1503/Upload.aspx?path={0}", _
                            fileDialog.SafeFileName))
      End Using
    End If
  End Sub

  Private Sub Button1_Click(ByVal sender As System.Object, _
                            ByVal e As System.Windows.RoutedEventArgs) _
                          Handles Button1.Click
    fileStream = File.OpenRead(TextBlock1.Tag.ToString())

    Dim request As HttpWebRequest = _
      CType(WebRequest.Create(uploadUri), HttpWebRequest)
    request.Method = "POST"

    Dim result As IAsyncResult = _
        CType(request.BeginGetRequestStream( _
            AddressOf GetRequestStreamCallback, request), IAsyncResult)
  End Sub

  Private Sub GetRequestStreamCallback( _
      ByVal asynchronousResult As IAsyncResult)
    Dim request As HttpWebRequest = _
      CType(asynchronousResult.AsyncState, HttpWebRequest)
    Dim postStream As Stream = _
      request.EndGetRequestStream(asynchronousResult)

    Dim sendBuffer(1023) As Byte
    Dim bytesRead As Integer = 0
    Do
      bytesRead = fileStream.Read(sendBuffer, 0, 1024)
      If bytesRead > 0 Then
        postStream.Write(sendBuffer, 0, bytesRead)
      End If
    Loop While bytesRead > 0

    request.BeginGetResponse(AddressOf GetResponseCallback, request)
  End Sub

  Private Sub GetResponseCallback(ByVal asynchronousResult As IAsyncResult)
    Dim request As HttpWebRequest = _
      CType(asynchronousResult.AsyncState, HttpWebRequest)
    Dim response As HttpWebResponse = _
      CType(request.EndGetResponse(asynchronousResult), HttpWebResponse)

    Dim streamResponse As Stream = response.GetResponseStream()
    Dim streamRead As New StreamReader(streamResponse)
    Dim responseString As String = streamRead.ReadToEnd()

    Dispatcher.BeginInvoke(New ManageDataDelegate( _
                                 AddressOf ViewData), responseString)

    streamResponse.Close()
    streamRead.Close()
    response.Close()
    fileStream.Close()
  End Sub

  Private Sub ViewData(ByVal datas As String)
    TextBlock1.Text = datas
  End Sub

End Class


