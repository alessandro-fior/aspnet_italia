﻿
Partial Class _01_Form
	Inherits System.Web.UI.Page

	Sub ShowFirstName(ByVal sender As Object, ByVal e As EventArgs)
		'… codice
	End Sub

End Class
