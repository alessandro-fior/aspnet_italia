using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CustomerAuthorization.Models.ViewModels
{
    public class OrderViewModel
    {
        public int Id { get; set; }
        public DateTime CreatedAt { get; set; }
        [Required]
        public decimal Amount { get; set; }
    }
}