﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario15
    {
        /// <summary>
        /// Esempio 8.17
        /// </summary>
        public static void Run()
        {
            // Attesa senza timeout
            var myTask = Task.Factory.StartNew(SomeMethod);
            myTask.Wait();

            // Attesa con timeout di un secondo
            myTask = Task.Factory.StartNew(SomeMethod);
            myTask.Wait(1000);
            
            // Attesa conclusione di uno tra myTask e anotherTask
            myTask = Task.Factory.StartNew(SomeMethod);
            var anotherTask = Task.Factory.StartNew(SomeMethod);
            Task.WaitAny(myTask, anotherTask);
            
            // Attesa conclusione di una lista di Task, con timeout di 2 secondi
            List<Task> taskList = GetTaskList();
            Task.WaitAll(taskList.ToArray(), 2000);
        }

        private static List<Task> GetTaskList()
        {
            return new List<Task>();
        }

        private static void SomeMethod()
        {
        }
    }
}