﻿Imports Microsoft.Win32

Module Module1
    Sub Main()
        Dim chapter20 As RegistryKey = Registry.CurrentUser.CreateSubKey("Capitolo20")
        Dim autor As RegistryKey = chapter20.CreateSubKey("Autore")
        autor.SetValue("Name", "Marco")
        Console.WriteLine("Chiave creata con successo")
        Console.ReadLine()
    End Sub
End Module
