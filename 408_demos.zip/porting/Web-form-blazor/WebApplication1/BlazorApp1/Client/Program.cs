using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using BlazorApp1.Client.Client;

namespace BlazorApp1.Client
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = WebAssemblyHostBuilder.CreateDefault(args);
            builder.RootComponents.Add<App>("#app");

            builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });

            builder.Services.AddHttpClient("sample-client", client =>
            {
                client.BaseAddress = new Uri("https://mio-sito-A.com/");
            });

            builder.Services.AddHttpClient<SampleClient>(client =>
            {
                client.BaseAddress = new Uri("https://mio-sito-B.com/");
            });
            await builder.Build().RunAsync();
        }
    }
}
