﻿using Microsoft.AspNetCore.Mvc;

namespace DemoWebAPI.Controllers
{
    [ApiVersion("1.0", Deprecated = true)]
    [Route("api/versioning")]
    public class VersioningController : Controller
    {
        /// <summary>
        /// Mostra il numero di versione dell'API, /api/versioning
        /// </summary>
        /// <returns>Il valore dell'API</returns>
        /// <response code="200">Quando la chiamata va a buon fine</response>
        [HttpGet]
        [ProducesResponseType(typeof(string), 200)]
        public IActionResult Get()
        {
            return Ok("v1");
        }
    }
}

namespace DemoWebAPI.Controllers.V2
{
    [ApiVersion("2.0")]
    [Route("api/versioning")]
    public class VersioningController : Controller
    {
        /// <summary>
        /// Mostra il numero di versione dell'API, raggiungibile tramite /api/versioning?api-version=2.0
        /// </summary>
        /// <returns>Il valore dell'API</returns>
        /// <response code="200">Quando la chiamata va a buon fine</response>
        [HttpGet]
        [ProducesResponseType(typeof(string), 200)]  
        public IActionResult Get()
        {
            return Ok("v2");
        }
    }
}