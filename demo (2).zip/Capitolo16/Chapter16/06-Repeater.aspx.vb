﻿Imports Chapter16.Models

Public Class _06_Repeater
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Using entities = New NorthwindContext()
            Dim customers = entities.Customers.OrderBy(Function(c) c.CompanyName)
            CustomerView.DataSource = customers.ToList()
            CustomerView.DataBind()
        End Using

    End Sub

End Class