﻿using Capitolo15.Binders;
using Capitolo15.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Binders;
using System;

namespace Capitolo15.Providers
{
    public class PersonBinderProvider : IModelBinderProvider
    {
        public IModelBinder GetBinder(ModelBinderProviderContext context)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            if (context.Metadata.ModelType == typeof(Person))
                return new BinderTypeModelBinder(typeof(PersonBinder));

            return null;
        }
    }
}