﻿using System;
using System.Threading;

namespace Capitolo8.Scenarios
{
    public static class Scenario11
    {
        /// <summary>
        /// Esempio 8.11
        /// </summary>
        public static void Run()
        {
            var method = new SomeDelegate((parameter) =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Ciao da {0}", parameter);
                return parameter.Length;
            });

            IAsyncResult asyncResult = method.BeginInvoke("Matteo Tumiati", null, null);
            Console.WriteLine("Esecuzione avviata");

            // Polling sul WaitHandle
            while (!asyncResult.IsCompleted)
            {
                Console.WriteLine("Esecuzione in corso...");
                asyncResult.AsyncWaitHandle.WaitOne(200);
            }

            // Attesa del termine dell'operazione e recupero risultato
            int result = method.EndInvoke(asyncResult);
            Console.WriteLine("Il risultato è {0}", result);
        }

        public delegate int SomeDelegate(string parameter);
    }
}