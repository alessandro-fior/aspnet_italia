﻿using System;
using System.Collections;
using System.IO;

namespace Capitolo5.Scenarios
{
    public static class Scenario3
    {
        /// <summary>
        /// Esempio 5.4, 5.5
        /// </summary>
        public static void Run()
        {
            // Creazione dell'HashTable
            var myDictionary = new Hashtable();

            // Aggiunta di elementi
            myDictionary.Add("someIntValue", 5);
            myDictionary.Add("someClass", new StringWriter());
            myDictionary.Add(DateTime.Today, "Today's string");

            // Recupera elemento dalla chiave
            object value = myDictionary["someIntValue"];
            Console.WriteLine($"L'elemento con chiave \"someIntValue\" è: {value}");

            // Enumerazione di tutte le coppie chiave-valore
            foreach (DictionaryEntry item in myDictionary)
            {
                Console.WriteLine(item.Key + ": " + item.Value);
            }

            // Rimuove un elemento
            myDictionary.Remove("someClass");

            // Recupera il numero di elementi
            int count = myDictionary.Count;
            Console.WriteLine($"L'Hashtable contiene {count} elementi");

            // Rimuove tutti gli elementi
            myDictionary.Clear();
            Console.WriteLine($"L'Hashtable contiene {myDictionary.Count} elementi");
        }
    }
}