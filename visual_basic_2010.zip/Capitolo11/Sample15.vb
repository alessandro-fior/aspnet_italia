﻿Imports System.Linq
Imports System.Xml.Linq
Imports <xmlns:p="http://schemas.aspitalia.com/book40/products">
Imports <xmlns:d="http://schemas.aspitalia.com/book40/details">


Public Class Sample15

    Public Shared Sub Run()

        ' Caricamento del documento
        Dim doc As XDocument = XDocument.Load("test.xml")

        Dim idProduct = doc.<p:products>.<p:product>(1).@idProduct
        Dim weight = doc...<d:detail>.@value

        Console.WriteLine(idProduct)
        Console.WriteLine(weight)

    End Sub

End Class
