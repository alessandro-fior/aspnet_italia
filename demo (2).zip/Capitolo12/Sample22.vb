﻿Imports System.Linq
Imports System.Xml.XPath
Imports System.Xml



Public Class Sample22

    Public Shared Sub Run()

        ' Carico il documento
        Dim doc As New XmlDocument()
        doc.Load("test.xml")

        ' Creo il gestore dei namespace
        Dim nsManager As New XmlNamespaceManager(doc.NameTable)
        ' Associo il prefisso al namespace
        nsManager.AddNamespace("p", "http://schemas.aspitalia.com/book40/products")

        ' Creo il navigatore sui XmlNode
        Dim navigator = doc.CreateNavigator()

        ' Ricerco l'attributo
        navigator = navigator.SelectSingleNode("/p:products/p:product[1]/@idCategory", nsManager)
        navigator.SetValue("5")

        Console.WriteLine(navigator.ValueAsInt)
    End Sub

End Class
