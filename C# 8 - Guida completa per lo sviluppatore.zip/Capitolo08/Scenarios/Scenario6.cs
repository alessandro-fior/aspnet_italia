﻿using System;
using System.Threading;

namespace Capitolo8.Scenarios
{
    public static class Scenario6
    {
        /// <summary>
        /// Esempio 8.6
        /// </summary>
        public static void Run()
        {
            ThreadPool.QueueUserWorkItem((o) =>
            {
                Console.WriteLine("Inizio worker thread");
                Thread.Sleep(1000);
                Console.WriteLine("Termine worker thread");
            });

            Thread.Sleep(500);
            Console.WriteLine("Metodo main");
            Thread.Sleep(2000);
        }
    }
}