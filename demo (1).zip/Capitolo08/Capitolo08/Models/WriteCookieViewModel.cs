using System;
using System.ComponentModel.DataAnnotations;

namespace Capitolo08.Models
{
	public class WriteCookieViewModel
	{
		[Required]
		public string Key { get; set; }

		public string Value { get; set; }
	}
}