namespace CustomerAuthorization.Models.ViewModels
{
    public class DemoUsersViewModel
    {
        public bool DemoUsersCreated { get; set; }
    }
}