﻿Imports System.Linq
Imports System.Xml.XPath
Imports System.Xml



Public Class Sample23

    Public Shared Sub Run()

        Dim doc As New XmlDocument()
        Dim navigator = doc.CreateNavigator()

        ' Creo il tag <products>
        navigator.AppendChildElement("p", "products", "http://schemas.aspitalia.com/book40/products", "")
        navigator.MoveToFirstChild()

        ' Creo l'attributo count
        navigator.CreateAttribute("", "count", "", "5")

        Console.WriteLine(doc.OuterXml)
    End Sub

End Class
