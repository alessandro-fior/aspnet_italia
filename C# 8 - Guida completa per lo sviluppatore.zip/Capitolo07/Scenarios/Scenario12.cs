﻿using System;
using System.Reflection;

namespace Capitolo7.Scenarios
{
    public static class Scenario12
    {
        /// <summary>
        /// Esempio 7.19, 7.20
        /// </summary>
        public static void Run()
        {
            // Recuperiamo un riferimento al tipo
            Type personType = Type.GetType("Capitolo7.Scenarios.Scenario12+Person");

            // Tramite il costruttore di default (senza parametri)
            // ne costruiamo un'istanza
            ConstructorInfo constructor = personType.GetConstructor(Type.EmptyTypes);
            object person = constructor.Invoke(null);

            // Tramite PropertyInfo valorizziamo Name e Age
            PropertyInfo nameProperty = personType.GetProperty("Name");
            nameProperty.SetValue(person, "Matteo Tumiati", null);

            PropertyInfo ageProperty = personType.GetProperty("Age");
            ageProperty.SetValue(person, 28, null);

            // Visualizziamo su Console il risultato di Person.ToString()
            Console.WriteLine(person.ToString());
        }

        public class Person
        {
            public string Name { get; set; }
            public int Age { get; set; }

            public override string ToString() => $"{Name} ha {Age} anni";
        }
    }
}