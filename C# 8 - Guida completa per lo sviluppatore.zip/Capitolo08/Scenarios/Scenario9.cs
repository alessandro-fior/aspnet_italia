﻿using System;
using System.Threading;

namespace Capitolo8.Scenarios
{
    public static class Scenario9
    {
        /// <summary>
        /// Esempio 8.9
        /// </summary>
        public static void Run()
        {
            var method = new SomeDelegate((parameter) =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Ciao da {0}", parameter);
                return parameter.Length;
            });

            method.BeginInvoke("Matteo Tumiati", null, null);
            
            Console.WriteLine("Esecuzione avviata");
            Thread.Sleep(2000);
        }

        public delegate int SomeDelegate(string parameter);
    }
}