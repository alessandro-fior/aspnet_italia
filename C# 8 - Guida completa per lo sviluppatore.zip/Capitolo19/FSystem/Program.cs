﻿using Microsoft.Win32;
using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Text;
using System.Threading.Tasks;

namespace FSystem
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var choice = Console.ReadLine();

            switch (choice)
            {
                case "19.1":
                    Example1();
                    break;
                case "19.2":
                    Example2();
                    break;
                case "19.3":
                    Example3();
                    break;
                case "19.4":
                    Exmple4();
                    break;
                case "19.5":
                    Exmple5();
                    break;
                case "19.6":
                    Example6();
                    break;
                case "19.7":
                    Example7();
                    break;
                case "19.8":
                    Example8();
                    break;
                case "19.9":
                    Example9();
                    break;
                case "19.10":
                    await Example10();
                    break;
                case "19.11":
                    Example11();
                    break;
                case "19.12":
                    Example12();
                    break;
                case "19.13":
                    Example13();
                    break;
                default:
                    break;

            }
        }

        private static void Example1()
        {
            DirectoryInfo dInfo = new DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19"));
            try
            {
                dInfo.Create();
                Console.WriteLine("Directory creata correttamente, premi un tasto per spostarla");
                Console.ReadLine();
                if (!Directory.Exists(
                Path.Combine(Environment.GetFolderPath(
                Environment.SpecialFolder.MyPictures), "Capitolo19")))
                {
                    dInfo.MoveTo(Path.Combine(
                    Environment.GetFolderPath(
                    Environment.SpecialFolder.MyPictures), "Capitolo19"));
                    Console.WriteLine("Directory spostata correttamente");
                }
                else
                {
                    Console.WriteLine("Directory già esistente!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Si è verificato un errore: {0}", ex.ToString());
            }
            Console.ReadLine();
        }
        private static void Example2()
        {
            try
            {
                Directory.CreateDirectory(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19"));
                Console.WriteLine("Directory creata correttamente");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Impossibile creare la directory: {0}", ex.ToString());
            }
            Console.ReadLine();
        }
        private static void Example3()
        {
            DirectoryInfo dInfo = new DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19"));
            try
            {
                dInfo.Create();
                Console.WriteLine("Directory creata correttamente, premi un tasto er eliminarla");
                Console.ReadLine();
                dInfo.Delete();
                Console.WriteLine("Directory Eliminata correttamente");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Si è verificato un errore: {0}", ex.ToString());
            }
            Console.ReadLine();
        }
        private static void Exmple4()
        {
            string myPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19");
            try
            {
                Directory.CreateDirectory(myPath);
                Console.WriteLine("Directory creata correttamente, premi un tasto per eliminarla");
                Console.ReadLine();
                Directory.Delete(myPath);
                Console.WriteLine("Directory Eliminata correttamente");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Impossibile creare la directory: {0}", ex.ToString());
            }
            Console.ReadLine();
        }
        private static void Exmple5()
        {
            DirectoryInfo dInfo = new DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19"));
            try
            {
                dInfo.Create();
                dInfo.CreateSubdirectory("Esempio 19.5");


                Console.WriteLine("Directory e sotto directory creata correttamente,premi un tasto per eliminarla");
                Console.ReadLine();
                dInfo.Delete(true);
                Console.WriteLine("Directory Eliminata correttamente");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Si è verificato un errore: {0}", ex.ToString());
            }
            Console.ReadLine();
        }
        private static void Example6()
        {
            DirectoryInfo dInfo = new DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19"));
            try
            {
                dInfo.Create();

                Console.WriteLine("Directory creata correttamente, premi un tasto per spostarla");
                Console.ReadLine();
                dInfo.MoveTo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Capitolo19"));
                Console.WriteLine("Directory spostata correttamente");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Si è verificato un errore: {0}", ex.ToString());
            }
            Console.ReadLine();
        }
        private static void Example7()
        {
            DirectoryInfo dInfo = new DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19"));
            try
            {
                dInfo.Create();
                Console.WriteLine("Directory creata correttamente, premi un tasto per spostarla”);


                Console.ReadLine();
                if (!Directory.Exists(
                Path.Combine(Environment.GetFolderPath(
                Environment.SpecialFolder.MyPictures), "Capitolo19")))
                {
                    dInfo.MoveTo(
                    Path.Combine(Environment.GetFolderPath(
                    Environment.SpecialFolder.MyPictures), "Capitolo19"));
                    Console.WriteLine("Directory spostata correttamente");
                }
                else
                {
                    Console.WriteLine("Directory già esistente");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Si è verificato un errore: {0}", ex.ToString());
            }
            Console.ReadLine();
        }
        private static void Example8()
        {
            DirectoryInfo[] directories = new DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)).GetDirectories();
            try
            {
                foreach (DirectoryInfo directoryInfo in directories)
                {
                    string copyPath = Path.Combine(
                    Environment.GetFolderPath(
                    Environment.SpecialFolder.MyDocuments),
                    string.Format("{0} copia", directoryInfo.Name));
                    Directory.CreateDirectory(copyPath);
                    Console.WriteLine(string.Format("Directory {0} copiata correttamente", directoryInfo.Name));
                    FileInfo[] files = directoryInfo.GetFiles();
                    foreach (FileInfo fileInfo in files)
                    {
                        fileInfo.CopyTo(Path.Combine(
                        copyPath, string.Format("{0} copia{1} ",
                        Path.GetFileNameWithoutExtension(fileInfo.Name),
                        Path.GetExtension(fileInfo.Name))));
                        Console.WriteLine(string.Format("File {0} copiato correttamente",
                        fileInfo.Name));
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Si è verificato un errore: {0}", ex.ToString());
            }
            Console.ReadLine();
        }
        private static void Example9()
        {
            DirectoryInfo dInfo = new DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments));
            try
            {
                DirectoryInfo[] directories = dInfo.GetDirectories("*", SearchOption.TopDirectoryOnly);
                foreach (DirectoryInfo directory in directories)
                {
                    Console.WriteLine("{0} {1}", directory.FullName,
                    directory.LastAccessTime);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Si è verificato un errore: {0}",
                ex.ToString());
            }
            Console.ReadLine();
        }
        private async static Task Example10()
        {
            try
            {
                string myPath = Path.Combine(
                Environment.GetFolderPath(
                Environment.SpecialFolder.MyDocuments), "myfile.txt");
                using (var myfileStream = File.Create(myPath))
                {
                    byte[] info = new UTF8Encoding(true).GetBytes("Un saluto dall'autore di questo capitolo.");
                    await myfileStream.WriteAsync(info, 0, info.Length);
                    myfileStream.Close();
                    using (StreamReader mySteamiReader = File.OpenText(myPath))
                    {
                        while (mySteamiReader.Peek() >= 0)
                        {
                            Console.WriteLine("Il file contiene: {0}",
                            mySteamiReader.ReadLine());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Si è verificato un errore: {0}", ex.ToString());
            }
            Console.ReadLine();
        }
        private static void Example11()
        {
            try
            {
                IsolatedStorageFile isoFile = IsolatedStorageFile.GetStore(
                IsolatedStorageScope.User | IsolatedStorageScope.Assembly | IsolatedStorageScope.Domain, null);
                if (!isoFile.DirectoryExists("Documenti"))
                {
                    isoFile.CreateDirectory("Documenti");
                }
                IsolatedStorageFileStream isoStream =
                isoFile.CreateFile("myFile.txt");
                byte[] info = new UTF8Encoding(true)
                .GetBytes("Un saluto dall'autore di questo capitolo.");
                isoStream.Write(info, 0, info.Length);
                isoStream.Close();
                using (StreamReader mySteamiReader = new StreamReader(
                isoFile.OpenFile("myFile.txt", FileMode.Open)))
                {
                    while (mySteamiReader.Peek() >= 0)
                    {
                        Console.WriteLine("il file contiene: {0}", mySteamiReader.ReadLine());
                    }
                    mySteamiReader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Si è verificato un errore: {0}", ex.ToString());
            }
            Console.ReadLine();
        }
        private static void Example12()
        {
            static void Main(string[] args)
            {
                RegistryKey registrykey = Registry.LocalMachine;
                registrykey = registrykey.OpenSubKey("HARDWARE\\\\DESCRIPTION\\\\System\\\\CentralProcessor\\\\0");
                object value = registrykey.GetValue("ProcessorNameString");
                Console.WriteLine("Il tuò processore è:" + value);
                Console.ReadLine();
            }
        }
        private static void Example13()
        {
            RegistryKey chapter19 = Registry.CurrentUser.CreateSubKey("Capitolo19");
            RegistryKey autor = chapter19.CreateSubKey("Autore");
            autor.SetValue("Name", "Marco");
            Console.WriteLine("Chiave creata con successo");
            Console.ReadLine();
        }
    }
}



