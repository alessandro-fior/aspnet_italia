﻿using Chapter16.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.ModelBinding;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Chapter16
{
    public partial class _07_DataBinding : System.Web.UI.Page
    {
        NorthwindContext db = new NorthwindContext();

        public IQueryable<Customer> GetCustomers([QueryString("n")] string name)
        {
            var customers = db.Customers.AsQueryable();

            if (!String.IsNullOrEmpty(name))
                customers = customers.Where(f => f.CompanyName.Contains(name));

            return customers;
        }


        public override void Dispose()
        {

            if (db != null)
                db.Dispose();

            base.Dispose();
        }
    }
}