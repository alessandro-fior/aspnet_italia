﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario21
    {
        /// <summary>
        /// Esempio 8.25, 8.26
        /// </summary>
        public static void Run()
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();

            SequentialOperations().Wait();

            watch.Stop();
            var elapsedSequence = watch.ElapsedMilliseconds;

            watch.Reset();
            watch.Start();

            ParallelOperations().Wait();

            watch.Stop();
            var elapsedParallel = watch.ElapsedMilliseconds;

            Console.WriteLine($"Elapsed: {elapsedSequence}ms");
            Console.WriteLine($"Elapsed: {elapsedParallel}ms");
        }

        public static async Task SequentialOperations()
        {
            Console.WriteLine("---- SequentialOperations ----");

            HttpClient client = new HttpClient();
            var firstResult = await client.GetStringAsync("http://www.google.com");
            Console.WriteLine(firstResult);

            var secondResult = await client.GetStringAsync("http://www.yahoo.com");
            Console.WriteLine(secondResult);
            
            var thirdResult = await client.GetStringAsync("http://www.bing.com");
            Console.WriteLine(thirdResult);
        }

        public static async Task ParallelOperations()
        {
            Console.WriteLine("---- ParallelOperations ----");

            HttpClient client = new HttpClient();

            var tasks = new List<Task<string>>()
            {
                client.GetStringAsync("http://www.google.com"),
                client.GetStringAsync("http://www.yahoo.com"),
                client.GetStringAsync("http://www.bing.com")
            };

            await Task.WhenAll(tasks);

            foreach (var task in tasks)
            {
                Console.WriteLine(task.Result);
            }
        }
    }
}