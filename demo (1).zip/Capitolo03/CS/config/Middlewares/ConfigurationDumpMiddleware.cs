using System;
using System.Net.Http;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using ConfigSample.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace ConfigSample.Middlewares
{
    public class ConfigurationDumpMiddleware
    {
        private readonly IOptionsMonitor<SmtpOptions> smtpOptions;
        private readonly IOptionsMonitor<ConnectionStringOptions> connectionStringOptions;
        private readonly ILogger<EmailErrorsMiddleware> logger;
        private readonly RequestDelegate next;

        //Riceviamo i servizi come parametri del costruttore
        //Si dice che questo middleware DIPENDE da essi
        public ConfigurationDumpMiddleware(
            RequestDelegate next,
            IOptionsMonitor<SmtpOptions> smtpOptions,
            IOptionsMonitor<ConnectionStringOptions> connectionStringOptions,
            ILogger<EmailErrorsMiddleware> logger
        )
        {
            this.smtpOptions = smtpOptions;
            this.connectionStringOptions = connectionStringOptions;
            this.logger = logger;
            //L'oggetto next, di tipo RequestDelegate, rappresenta il prossimo middleware configurato nella pipeline (se presente)
            this.next = next;
        }

        public async Task Invoke(HttpContext context) {
            
            //Se in query string è presente la chiave "error", simuliamo un errore
            //In modo da testare il comportamento dell'EmailErrorsMiddleware
            if (context.Request.QueryString.Value.StartsWith("?error")) {
                throw new Exception("L'applicazione ha prodotto un errore! (Vedi se ti è arrivata l'email di notifica o se è apparso un errore in console)");
            }

            //Questo middleware produce una risposta per il client
            //e quindi non esegue il metodo next.Invoke
            string content = GetContent();
            await context.Response.WriteAsync(content, Encoding.UTF8);
        }

        private string GetContent() {

            //Otteniamo i valori di configurazione correnti dagli oggetti IOptionsMonitor<T>
            var connectionStrings = connectionStringOptions.CurrentValue;
            var smtp = smtpOptions.CurrentValue;

            //Mettiamo insieme una risposta html per il client
            var sb = new StringBuilder();
            sb.AppendLine("<!DOCTYPE html><html><body>");
            sb.AppendLine("<h1>Configurazione attuale</h1>");

            sb.AppendLine("<h3>Connection strings</h3>");
            sb.AppendLine("<ul>");
            sb.AppendLine($"<li>Default: {connectionStrings.Default}</li>");
            sb.AppendLine("</ul>");

            sb.AppendLine("<h3>SMTP</h3>");
            sb.AppendLine("<ul>");
            sb.AppendLine($"<li>Host: {smtp.Host}</li>");
            sb.AppendLine($"<li>Port: {smtp.Port}</li>");
            sb.AppendLine($"<li>EnableSsl: {smtp.EnableSsl}</li>");
            sb.AppendLine($"<li>Username: {smtp.Username}</li>");
            sb.AppendLine($"<li>Password: {smtp.Password}</li>");
            sb.AppendLine($"<li>Email: {smtp.Email}</li>");
            sb.AppendLine("</ul>");

            sb.AppendLine("<hr>");
           
            sb.AppendLine("<h2>Note</h2>");
            sb.AppendLine($"<p>Il contenuto di questa pagina &egrave; stato generato dal <code>{this.GetType().Name}</code> situato nella directory /Middlewares</p>");
            sb.AppendLine("<p>Inoltre, quando si verifica un errore nell'applicazione, l'<code>EmailErrorsMiddleware</code> tenter&agrave; di inviare un'email usando le impostazioni del server SMTP situate nel file appsettings.json. Modificare tali impostazioni in modo che siano valide, altrimenti verr&agrave; loggato l'errore 'Impossibile inviare l'e-mail' in console.</p>");
			sb.AppendLine("<a href=\"?error=1\">Clicca qui per simulare un errore nell'applicazione</a>");
            sb.AppendLine("</body></html>");

            return sb.ToString();
        }
    }
}