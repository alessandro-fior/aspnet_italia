﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace Capitolo7.Scenarios
{
    public static class Scenario16
    {
        /// <summary>
        /// Esempio 7.26, 7.27, 7.28
        /// </summary>
        public static void Run()
        {
            var people = new List<Person>
            {
                new Person { FirstName = "Mario", LastName = "Rossi", Age = 43 },
                new Person { FirstName = "Giuseppe", LastName = "Verdi", Age = 38 }
            };

            var report = BuildReport(people);
            Console.WriteLine(report);
        }

        [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
        public class ReportPropertyAttribute : Attribute
        {
            public string Header { get; set; }

            public ReportPropertyAttribute(string header)
            {
                this.Header = header;
            }
        }

        public class Person
        {
            [ReportProperty("Nome")]
            public string FirstName { get; set; }

            [ReportProperty("Cognome")]
            public string LastName { get; set; }
            
            [ReportProperty("Età")]
            public int Age { get; set; }
        }

        public static string BuildReport<T>(IEnumerable<T> items)
        {
            var headers = new Dictionary<PropertyInfo, string>();

            // Lettura dei metadati
            foreach (PropertyInfo prop in typeof(T).GetProperties())
            {
                object[] attributes = prop.GetCustomAttributes(typeof(ReportPropertyAttribute), true);
                
                if (attributes.Length > 0)
                {
                    ReportPropertyAttribute reportAttribute = (ReportPropertyAttribute)attributes[0];
                    headers.Add(prop, reportAttribute.Header);
                }
            }

            // ... Qui logica per produrre il report in base
            // al contenuto del dictionary headers ...

            return string.Join(";", headers.Values);
        }
    }
}