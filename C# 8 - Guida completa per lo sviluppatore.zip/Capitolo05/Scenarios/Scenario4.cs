﻿using System;
using System.Collections;

namespace Capitolo5.Scenarios
{
    public static class Scenario4
    {
        /// <summary>
        /// Esempio 5.6
        /// </summary>
        public static void Run()
        {
            Console.WriteLine("---Stack---");

            // creo uno stack ed inserisco tre oggetti
            var myStack = new Stack();
            myStack.Push("Marco");
            myStack.Push(5);
            myStack.Push(new object());

            // rimuovo due elementi dallo stack
            Console.WriteLine(myStack.Pop());
            Console.WriteLine(myStack.Pop());
            Console.WriteLine("---Queue---");

            // creo una coda e inserisco tre oggetti 
            var myQueue = new Queue();
            myQueue.Enqueue("Marco");
            myQueue.Enqueue(5);
            myQueue.Enqueue(new object());

            // rimuovo due elementi dalla coda
            Console.WriteLine(myQueue.Dequeue());
            Console.WriteLine(myQueue.Dequeue());
        }
    }
}