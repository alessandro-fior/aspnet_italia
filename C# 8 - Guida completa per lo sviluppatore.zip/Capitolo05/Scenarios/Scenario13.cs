﻿using System;

namespace Capitolo5.Scenarios
{
    public static class Scenario13
    {
        /// <summary>
        /// Esempio 5.18
        /// </summary>
        public static void Run()
        {
            int myInt = default(int);
            Nullable<int> nullableInt = default(Nullable<int>);

            Console.WriteLine(myInt); // Stampa 0
            Console.WriteLine(nullableInt); // Stampa una riga vuota

            // Assegnazione di un valore intero
            myInt = 5;
            nullableInt = 7; 

            var res = myInt + nullableInt; // res è di tipo Nullable<int>
            
            if (nullableInt.HasValue) // Verifica presenza di un valore
            {
                var value = nullableInt.Value; // Contiene il valore int
                Console.WriteLine($"Il valore non è null ed è: {value}");
            }
            else
            {
                Console.WriteLine($"L'oggetto {nameof(nullableInt)} non ha valore");
            }
        }
    }
}