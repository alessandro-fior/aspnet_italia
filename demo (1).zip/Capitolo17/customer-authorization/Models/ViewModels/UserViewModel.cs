using System.Collections.Generic;

namespace CustomerAuthorization.Models.ViewModels
{
    public class UserViewModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public List<OrderViewModel> Orders { get; set; }
    }
}