﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CustomCookieAuth.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;

namespace CustomCookieAuth.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            if (User.Identity.IsAuthenticated) {
                return Redirect("/");
            }
            return View();
        }

        public async Task<IActionResult> Logout() {
            await HttpContext.SignOutAsync(
                scheme: CookieAuthenticationDefaults.AuthenticationScheme
                );
            return Redirect("/");
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginModel login, string redirectUrl = null)
        {
            if (!ModelState.IsValid) {
                ViewBag.Error = "You didn't enter username and/or password";
                return View();
            }

            //Verifichiamo se esiste un utente con le credenziali fornite
            //Il metodo GetUserByCredentials contiene la logica personalizzata
            //per tale verifica. Lo user è anch'esso un nostro oggetto personalizzato
            var user = await GetUserByCredentials(login.Username, login.Password);
            if (user == null)
            {
                //Nessun utente trovato, vuol dire che le credenziali non erano valide
                ViewBag.Error = "Credentials are not valid!";
                return View();
            }

            //Creiamo una ClaimsIdentity e aggiungiamo i claim dell'utente loggato
            var claimsIdentity = new ClaimsIdentity(
                authenticationType: CookieAuthenticationDefaults.AuthenticationScheme
            );
            claimsIdentity.AddClaim(new Claim(ClaimTypes.Name, user.Username));
            claimsIdentity.AddClaim(new Claim(ClaimTypes.Role, user.Role));

            //Incapsuliamo tutto in una ClaimsPrincipal
            var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);

            //Emettiamo il cookie di autenticazione fornendo delle opzioni
            var authProperties = new AuthenticationProperties
            {
                //L'utente vuole restare loggato?
                IsPersistent = login.RememberMe
            };
            await HttpContext.SignInAsync(
              scheme: CookieAuthenticationDefaults.AuthenticationScheme,
              principal: claimsPrincipal,
              properties: authProperties);

            //Login effettuato: indirizziamo l'utente alla pagina di provenienza
            return Redirect(redirectUrl ?? "/");
        }

        private Task<User> GetUserByCredentials(string username, string password)
        {
            //TODO: qui logica per verificare nel database se le credenziali esistono
            if (username == "admin" && password == "password") {
                return Task.FromResult(new User {
                    Username = "admin",
                    Role = "Administrator",
                    FullName = "Mario Rossi",
                    CreatedAt = new DateTime(2018, 1, 1),
                });
            }
            return Task.FromResult(default(User));
        }
    }
}
