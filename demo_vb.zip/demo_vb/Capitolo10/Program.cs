﻿using System;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Text;

namespace ASPItalia.Books.Chapter10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*** DATA PROVIDERS ***\n");
            DbProviders();

            Console.WriteLine("\n*** DATA PROVIDER FACTORY (MS ACCESS) ***\n");
            DbProviderFactory("MdbNorthwind");
            
            Console.WriteLine("\n*** DATA PROVIDER FACTORY (MS SQL SERVER) ***\n");
            DbProviderFactory("SqlNorthwind");
            
            Console.WriteLine("\n*** EXECUTENONQUERY ***\n");
            ExecuteNonQuery();

            Console.WriteLine("\n*** EXECUTEREADER ***\n");
            ExecuteReader();

            Console.WriteLine("\n*** EXECUTESCALAR ***\n");
            ExecuteScalar();

            Console.ReadLine();
        }

        private static void DbProviders()
        {
            DataTable dbProviders = DbProviderFactories.GetFactoryClasses();

            foreach (DataRow row in dbProviders.Rows)
            {
                Console.WriteLine(row[0]);
            }
        }

        private static void DbProviderFactory(string connectionName)
        {
            if (ConfigurationManager.ConnectionStrings[connectionName] != null)
            {
                String providerInvariantName = string.Empty;
                String connectionString = string.Empty;
                String cmdText = "SELECT * FROM Customers WHERE CustomerID LIKE 'A%'";

                DataTable data = new DataTable();
                
                // Nome invariante del managed data provider
                providerInvariantName = ConfigurationManager.ConnectionStrings[connectionName].ProviderName;

                // Stringa di connessione
                connectionString = ConfigurationManager.ConnectionStrings[connectionName].ConnectionString;

                // MS Access
                if (connectionName.Equals("MdbNorthwind"))
                {
                    connectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + connectionString;
                }

                // Creazione dell'oggetto factory
                DbProviderFactory factory = DbProviderFactories.GetFactory(providerInvariantName);

                // Interrogazione del database
                using (DbConnection conn = factory.CreateConnection())
                {
                    conn.ConnectionString = connectionString;
                    conn.Open();

                    // Modalità disconnessa: popolamento di un oggetto DataTable
                    using (DbDataAdapter adatpter = factory.CreateDataAdapter())
                    {
                        DbCommand selectCmd = factory.CreateCommand();
                        selectCmd.CommandText = cmdText;
                        selectCmd.Connection = conn;
                        adatpter.SelectCommand = selectCmd;
                        adatpter.Fill(data);
                    } // L'adapter viene chiuso automaticamente alla fine del blocco Using

                } // La connessione viene chiusa automaticamente alla fine del blocco Using

                Console.WriteLine(connectionString + "\n");
                Console.WriteLine(cmdText + "\n");

                foreach (DataRow row in data.Rows)
                {
                    Console.WriteLine(row[0]);
                }
            }
        }

        private static void ExecuteNonQuery()
        {
            // Creazione della connessione
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlNorthwind"].ConnectionString))
            {
                // Apertura della connessione
                conn.Open();

                // Creazione del comando
                using (SqlCommand cmd = new SqlCommand("UPDATE Customers SET City='Bergamo' WHERE CustomerID=@CustomerID", conn))
                {
                    // Aggiungi un parametro
                    cmd.Parameters.AddWithValue("@CustomerID", "MAGAA");

                    // Ritorna il numero di righe interessate dal comando di aggiornamento
                    int rowsAffected = cmd.ExecuteNonQuery();

                    Console.WriteLine(cmd.CommandText.Replace(cmd.Parameters[0].ParameterName, "'" + cmd.Parameters[0].Value + "'\n"));
                    Console.WriteLine(rowsAffected.ToString());

                } // Il comando viene chiuso automaticamente alla fine del blocco Using

            } // La connessione viene chiusa automaticamente alla fine del blocco Using
        }

        private static void ExecuteReader()
        {
            StringBuilder builder = new StringBuilder();

            // Creazione della connessione
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlNorthwind"].ConnectionString))
            {
                // Apertura della connessione
                conn.Open();

                // Creazione del comando
                using (SqlCommand cmd = new SqlCommand("SELECT TOP (10) CustomerID, CompanyName, ContactName, City FROM Customers", conn))
                {
                    // Ritorna un resultset
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        // Ciclo sul risultato della query
                        while (reader.Read())
                        {
                            builder.Append(string.Concat(reader.GetString(0), " - ", reader.GetString(1), " - ", reader.GetString(2), " - ", reader.GetString(3), "\n"));
                        }

                    }  // Il data reader viene chiuso automaticamente alla fine del blocco Using

                    Console.WriteLine(cmd.CommandText + "\n");
                    Console.WriteLine(builder.ToString());

                } // Il comando viene chiuso automaticamente alla fine del blocco Using

            } // La connessione viene chiusa automaticamente alla fine del blocco Using
        }

        private static void ExecuteScalar()
        {
            // Creazione della connessione
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlNorthwind"].ConnectionString))
            {
                // Apertura della connessione
                conn.Open();

                // Creazione del comando
                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Customers", conn))
                {
                    // Ritorna un valore intero
                    int count = (int)cmd.ExecuteScalar();

                    Console.WriteLine(cmd.CommandText + "\n");
                    Console.WriteLine(count.ToString());

                } // Il comando viene chiuso automaticamente alla fine del blocco Using

            } // La connessione viene chiusa automaticamente alla fine del blocco Using
        }
    }
}
