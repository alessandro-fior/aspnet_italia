﻿
Public Class Resources

    Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        Me.Resources("RedBrush") = New SolidColorBrush(Colors.Yellow)
    End Sub

End Class
