# Priorità delle fonti di configurazione
Questo progetto dimostra come costruire la configurazione attingendo da varie fonti. Si tratta di un'applicazione ASP.NET Core minimale creata con il comando `dotnet new web`. All'interno del file [Startup.cs](Startup.cs), nel costruttore della classe viene creata la configurazione coinvolgendo i file `appsettings.json`, `appsettings.NOMEAMBIENTE.json` e le variabili d'ambiente con prefisso `ASPNETCORE_`.

ASP.NET Core costruisce la configurazione "appiattendo" i valori ottenuti dalle fonti indicate. Le fonti che appaiono più in basso nella lista sono considerate più prioritarie e i loro valori vanno perciò a ridefinire quelli eventualmente definiti nelle precedenti fonti.

## Esercizi
Fai pratica con le fonti di configurazione seguendo questi passi:

 1. Avvia l'applicazione con il comando `dotnet run`, apri il browser e visita l'indirizzo `http://localhost:5000` per visualizzare una pagina che mostrerà i valori attuali configurati. Nota come la connection string sia quella definita nel file `appsettings.Development.json`. Questo file è stato configurato come più prioritario rispetto al file `appsettings.json`, come si vede alla riga 23 in `Startup.cs`. Il file `appsettings.Development.json` viene considerato quando l'ambiente è `Development`;
 2. Arresta l'applicazione, poi vai nel file `Program.cs` e commenta la linea 22 per fare in modo che l'ambiente passi a `Production` (è l'impostazione di default). Riavvia l'applicazione e nota come la connection string sia ora quella definita nel file `appsettings.json`, dato che il file `appsettings.Development.json` non viene più preso in considerazione;
 3. Mentre l'applicazione è in esecuzione, modifica il contenuto del file `appsettings.json` e ricarica la pagina per verificare come i valori vengano aggiornati a caldo;
 4. Arresta l'applicazione e imposta una variabile d'ambiente chiamata ASPNETCORE_SMTP:HOST. Riapri il terminale e riavvia l'applicazione per vedere come il valore vada a ridefinire quello contenuto nel file `appsettings.json`. Questo succede perché le variabili d'ambiente sono state configurate alla riga 24 di `Startup.cs` come fonte prioritaria rispetto ai file json.

 ## Uso dei servizi `IOptionsMonitor<T>`
 Quest'applicazione usa due middleware personalizzati che si trovano nella directory `/Middlewares`. Tali middleware usano i servizi `IOptionsMonitor<SmtpOptions>` e `IOptionsMonitor<ConnectionStringOptions>` per accedere ai valori di configurazione in maniera fortemente tipizzata. I servizi sono stati registrati alle righe 33 e 34 del file [Startup.cs](Startup.cs) grazie all'extension method `Configure`, mentre i middleware alle righe 56 e 61.