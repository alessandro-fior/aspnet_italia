﻿using System;
using System.Data.Entity;
using System.Linq;

namespace Capitolo11
{
	class Program
	{
		static void Main(string[] args)
		{
			QueryLista();
			QuerySingolo();
			QueryProjection();
			QueryInclude();
			InsertCustomer();
			UpdateCustomerConnected();
			UpdateCustomerDisconnected();
			DeleteCustomerConnected();
			DeleteCustomerDisconnected();
			Console.ReadLine();
		}

		private static void DeleteCustomerDisconnected()
		{
			Customer custToDelete;
			using (var ctx = new NorthwindModel())
			{
				custToDelete = ctx.Customers.Find("STEMO");
			}

			using (var ctx = new NorthwindModel())
			{
				ctx.Customers.Attach(custToDelete);
				ctx.Customers.Remove(custToDelete);
			}
		}

		private static void DeleteCustomerConnected()
		{
			using (var ctx = new NorthwindModel())
			{
				var cust = ctx.Customers.Find("STEMO");
				ctx.Customers.Remove(cust);
			}
		}

		private static void UpdateCustomerDisconnected()
		{
			Customer cust;
			using (var ctx = new NorthwindModel())
			{
				cust = ctx.Customers.Find("STEMO");
			}

			cust.Address = "Piazza Venezia 10";

			using (var ctx = new NorthwindModel())
			{
				ctx.Customers.Attach(cust);
				ctx.Entry(cust).State = EntityState.Modified;
				ctx.SaveChanges();
			}
		}

		private static void UpdateCustomerConnected()
		{
			using (NorthwindModel ctx = new NorthwindModel())
			{
				var cust = ctx.Customers.Find("STEMO");
				cust.Address = "Piazza del popolo 1";
				ctx.SaveChanges();
			}
		}

		private static void InsertCustomer()
		{
			using (NorthwindModel ctx = new NorthwindModel())
			{
				var c = new Customer
				{
					CustomerID = "STEMO",
					CompanyName = "Stefano Mostarda",
					ContactName = "Stefano Mostarda",
					Address = "Via Del Corso 14",
					City = "Roma",
					Country = "Italy",
					PostalCode = "00100",
					Region = "Lazio",
					ContactTitle = "Sig",
					Phone = "00000",
					Fax = "00000"
				};

				ctx.Customers.Add(c);
				ctx.SaveChanges();
			}
		}

		private static void QueryInclude()
		{
			using (var ctx = new NorthwindModel())
			{
				var orders = ctx.Orders.Include(o => o.Order_Details);
				foreach (var o in orders)
				{
					Console.WriteLine($"{o.OrderID}-{o.Order_Details.Count}");
				}
			}
		}

		private static void QueryProjection()
		{
			using (var ctx = new NorthwindModel())
			{
				var customers = ctx.Customers.Select(c => new { c.CustomerID, c.CompanyName });
				foreach (var cust in customers)
				{
					Console.WriteLine($"{cust.CustomerID}-{cust.CompanyName}");
				}
			}
		}

		private static void QuerySingolo()
		{
			using (var ctx = new NorthwindModel())
			{
				var item1 = ctx.Customers.First(c => c.CustomerID == "ALFKI");
				var item2 = ctx.Customers.Find("ALFKI");
				Console.WriteLine(item1.CustomerID);
			}
		}

		private static void QueryLista()
		{
			using (var ctx = new NorthwindModel())
			{
				var customers1 = from c in ctx.Customers
												 where c.Country == "Italy"
												 select c;

				var customers2 = ctx.Customers.Where(c => c.Country == "Italy");
				Console.WriteLine(customers1.Count());
				Console.WriteLine(customers2.Count());
			}
		}
	}
}
