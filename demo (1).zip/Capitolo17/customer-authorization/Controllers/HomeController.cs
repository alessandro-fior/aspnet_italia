﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CustomerAuthorization.Models;
using System.Security.Claims;
using CustomerAuthorization.Models.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using CustomerAuthorization.Models.ViewModels;

namespace CustomerAuthorization.Controllers
{
    public class HomeController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        //Riceviamo lo UserManager nel costruttore del controller
        // grazie alla dependency injection di ASP.NET Core
        public HomeController(UserManager<ApplicationUser> userManager)
        {
            this.userManager = userManager;
        }
        public async Task<IActionResult> Index()
        {
            var viewModel = new DemoUsersViewModel {
                DemoUsersCreated = await userManager.Users.AnyAsync()
            };
            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> CreateTestUsers() {
            if (!await userManager.Users.AnyAsync()) {   
                await CreateAdministrator(userManager);
                await CreateCustomer1(userManager);
                await CreateCustomer2(userManager);
            }
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        #region Utenti creati a scopo di demo
        private async Task CreateAdministrator(UserManager<ApplicationUser> userManager)
        {
            const string userEmail = "admin@example.com";
            const string userPassword = "Password1!";

            var user = new ApplicationUser {
                Email = userEmail,
                UserName = userEmail,
                EmailConfirmed = true,
                LockoutEnabled = true,
            };
            var claims = new List<Claim> {
                new Claim(ClaimTypes.Role, "Administrator")
            };
            await userManager.CreateAsync(user, userPassword);
            await userManager.AddClaimsAsync(user, claims);
        }
        private async Task CreateCustomer1(UserManager<ApplicationUser> userManager)
        {
            const string userEmail = "customer1@example.com";
            const string userPassword = "Customer1!";

            var user = new ApplicationUser {
                Email = userEmail,
                UserName = userEmail,
                EmailConfirmed = true,
                LockoutEnabled = true,
                Orders = new List<Order> {
                    new Order { Amount = 400, CreatedAt = new DateTime(2017, 12, 20) },
                    new Order { Amount = 250, CreatedAt = new DateTime(2018, 1, 10) },
                    new Order { Amount = 450, CreatedAt = new DateTime(2018, 1, 27) },
                }
            };
            var claims = new List<Claim> {
                new Claim(ClaimTypes.Email, userEmail),
                new Claim(ClaimTypes.Role, "Customer"),
                new Claim("Tenant", "Customer1")
            };
            await userManager.CreateAsync(user, userPassword);
            await userManager.AddClaimsAsync(user, claims);
        }
        private async Task CreateCustomer2(UserManager<ApplicationUser> userManager)
        {
            const string userEmail = "customer2@example.com";
            const string userPassword = "Customer2!";

            var user = new ApplicationUser {
                Email = userEmail,
                UserName = userEmail,
                EmailConfirmed = true,
                LockoutEnabled = true,
                Orders = new List<Order> {
                    new Order { Amount = 300, CreatedAt = new DateTime(2018, 1, 23) },
                    new Order { Amount = 650, CreatedAt = new DateTime(2018, 1, 27) },
                }
            };
            var claims = new List<Claim> {
                new Claim(ClaimTypes.Email, userEmail),
                new Claim(ClaimTypes.Role, "Customer"),
                new Claim("Tenant", "Customer2")
            };
            await userManager.CreateAsync(user, userPassword);
            await userManager.AddClaimsAsync(user, claims);
        }
        #endregion
    }
}
