﻿using Capitolo5.Scenarios;

namespace Capitolo5
{
    class Program
    {
        static void Main(string[] args)
        {
            // cambiare il nome dello scenario da testare per osservare l'output corrispondente
            Scenario1.Run();
        }
    }
}