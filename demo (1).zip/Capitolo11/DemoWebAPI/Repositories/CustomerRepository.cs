﻿using System;
using System.Collections.Generic;
using System.Linq;
using DemoWebAPI.Models;

namespace DemoWebAPI.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private static ICollection<Customer> customers;

        public CustomerRepository()
        {
            if (customers != null && customers.Any())
                return;

            customers = new List<Customer>
            {
                new Customer
                {
                    Id = Guid.NewGuid(),
                    DateOfBirth = new DateTime(1991, 4, 24),
                    FirstName = "Matteo",
                    LastName = "Tumiati"
                },
                new Customer
                {
                    Id = Guid.NewGuid(),
                    DateOfBirth = new DateTime(1988, 3, 29),
                    FirstName = "Mario",
                    LastName = "Rossi"
                },
                new Customer
                {
                    Id = Guid.NewGuid(),
                    DateOfBirth = new DateTime(1948, 12, 12),
                    FirstName = "Giuseppe",
                    LastName = "Verdi"
                },
                new Customer
                {
                    Id = Guid.NewGuid(),
                    DateOfBirth = new DateTime(1974, 10, 16),
                    FirstName = "Marco",
                    LastName = "Bianchi"
                }
            };
        }

        public bool CustomerExists(Guid id)
        {
            if (customers == null || !customers.Any())
                return false;

            return customers.Any(x => x.Id == id);
        }

        public Customer GetCustomer(Guid id)
        {
            if (customers == null || !customers.Any())
                return null;

            return customers.FirstOrDefault(x => x.Id == id);
        }

        public IEnumerable<Customer> GetCustomers()
        {
            return customers;
        }

        public void AddCustomer(Customer customer)
        {
            if (customers == null || !customers.Any() || customer == null)
                return;

            customer.Id = Guid.NewGuid();
            customers.Add(customer);
        }

        public void AddCustomers(IEnumerable<Customer> customers)
        {
            if (customers == null || !customers.Any())
                return;

            foreach (var customer in customers)
                this.AddCustomer(customer);
        }

        public void UpdateCustomer(Customer customer)
        {
            if (customer == null)
                return;

            var internalCustomer = customers.FirstOrDefault(x => x.Id == customer.Id);
            internalCustomer.FirstName = customer.FirstName;
            internalCustomer.LastName = customer.LastName;
        }
        
        public void DeleteCustomer(Guid id)
        {
            customers.Remove(customers.FirstOrDefault(x => x.Id == id));
        }

        public bool SaveChanges()
        {
            return true;
        }
    }
}