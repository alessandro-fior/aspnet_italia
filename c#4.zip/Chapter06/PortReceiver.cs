﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace ASPItalia.Books.Chapter06
{
    public class PortDataReceivedEventArgs : EventArgs
    {
        public string Data { get; set; }
    }

    public class PortReceiver
    {
        public delegate void PortDataReceivedEventHandler(
          object sender, PortDataReceivedEventArgs e);
        public event PortDataReceivedEventHandler PortDataReceived;

        protected virtual void OnPortDataReceived(string data)
        {
            if (this.PortDataReceived != null)
            {
                var e = new PortDataReceivedEventArgs();
                e.Data = data;
                this.PortDataReceived(this, e);
            }
        }

        public event CancelEventHandler PortDataReceiving;

        protected virtual void OnPortDataReceiving(CancelEventArgs e)
        {
            if (this.PortDataReceiving != null)
                this.PortDataReceiving(this, e);
        }

        public string Data { get; set; }

        public void ReceiveData()
        {
            var e = new CancelEventArgs(false);
            this.OnPortDataReceiving(e);

            // qui verifichiamo se un sottoscrittore
            // ha cancellato la ricezione dati
            if (!e.Cancel)
            {
                this.Data = "Data received";
                this.OnPortDataReceived(Data);
            }
        }


        // .. codice di interfacciamento con la porta ..
    }
}
