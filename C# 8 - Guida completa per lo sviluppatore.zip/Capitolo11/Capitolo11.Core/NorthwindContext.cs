using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Capitolo11.Core
{
	public partial class NorthwindContext : DbContext
	{
		public virtual DbSet<Customer> Customers { get; set; }
		public virtual DbSet<OrderDetail> Order_Details { get; set; }
		public virtual DbSet<Order> Orders { get; set; }

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			var config = new ConfigurationBuilder()
					.AddJsonFile("appsettings.json", true, true)
					.Build();

			optionsBuilder.UseSqlServer(config.GetConnectionString("NorthwindContext"));
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<Customer>(e =>
			{
				e.Property(e => e.CustomerID).IsFixedLength();
			});

			modelBuilder.Entity<OrderDetail>(e =>
			{
				e.ToTable("Order Details");
				e.Property(e => e.UnitPrice);
				e.HasKey(p => new { p.OrderID, p.ProductID });
			});

			modelBuilder.Entity<Order>(e =>
			{
				e.Property(e => e.CustomerID).IsFixedLength();
				e.Property(e => e.Freight);
				e.HasMany(e => e.Order_Details).WithOne(e => e.Order).OnDelete(DeleteBehavior.Cascade);
			});
		}
	}
}
