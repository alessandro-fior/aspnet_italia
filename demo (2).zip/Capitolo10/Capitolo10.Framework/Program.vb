﻿Imports System.Data.SqlClient
Imports System.Text
Imports System.Transactions

Module Program

	Dim connectionString As String

	Sub Main(args As String())
		connectionString = System.Configuration.ConfigurationManager.ConnectionStrings("db").ConnectionString
		CreaConnessione().Wait()
		ExecuteNonQuery().Wait()
		ExecuteReader().Wait()
		ExecuteScalar().Wait()
		DbTransaction().Wait()
		TransactionScope().Wait()
		Console.ReadLine()
	End Sub

	Private Async Function CreaConnessione() As Task
		Dim conn = New SqlConnection(connectionString)

		Try
			Await conn.OpenAsync()
		Catch ex As SqlException
		Finally
			If conn.State = ConnectionState.Open Then conn.Close()
		End Try

		Using connection = New SqlConnection(connectionString)

			Try
				Await connection.OpenAsync()
			Catch ex As SqlException
			End Try
		End Using
	End Function

	Private Sub CreaStringaConnessione()
		Dim builder = New SqlConnectionStringBuilder()
		builder.DataSource = "(local)"
		builder.InitialCatalog = "northwind"
		builder.IntegratedSecurity = True
		Console.WriteLine(builder.ConnectionString)
	End Sub

	Private Async Function ExecuteNonQuery() As Task
		Using conn As SqlConnection = New SqlConnection(connectionString)
			Await conn.OpenAsync()

			Using cmd As SqlCommand = New SqlCommand("UPDATE Customers SET City='Bergamo' WHERE CustomerID=@CustomerID", conn)
				cmd.Parameters.AddWithValue("@CustomerID", "MAGAA")
				Dim rowsAffected As Integer = Await cmd.ExecuteNonQueryAsync()
				Console.WriteLine(cmd.CommandText.Replace(cmd.Parameters(0).ParameterName, "'" & cmd.Parameters(0).Value & "'" & vbLf))
				Console.WriteLine(rowsAffected.ToString())
			End Using
		End Using
	End Function

	Private Async Function ExecuteReader() As Task
		Dim builder As StringBuilder = New StringBuilder()

		Using conn As SqlConnection = New SqlConnection(connectionString)
			Await conn.OpenAsync()

			Using cmd As SqlCommand = New SqlCommand("SELECT TOP (10) CustomerID, CompanyName, ContactName, City FROM Customers", conn)

				Using reader As SqlDataReader = Await cmd.ExecuteReaderAsync()

					While reader.Read()
						builder.Append(String.Concat(reader.GetString(0), " - ", reader.GetString(1), " - ", reader.GetString(2), " - ", reader.GetString(3), vbLf))
					End While
				End Using

				Console.WriteLine(cmd.CommandText & vbLf)
				Console.WriteLine(builder.ToString())
			End Using
		End Using
	End Function

	Private Async Function ExecuteScalar() As Task
		Using conn As SqlConnection = New SqlConnection(connectionString)
			Await conn.OpenAsync()

			Using cmd As SqlCommand = New SqlCommand("SELECT COUNT(*) FROM Customers", conn)
				Dim count As Integer = CInt((Await cmd.ExecuteScalarAsync()))
				Console.WriteLine(cmd.CommandText & vbLf)
				Console.WriteLine(count.ToString())
			End Using
		End Using
	End Function

	Private Async Function DbTransaction() As Task
		Using connection = New SqlConnection(connectionString)
			Await connection.OpenAsync()

			Using transaction = connection.BeginTransaction()

				Try

					Using command = New SqlCommand("update customers set companyname = 'alfred' where customerid = 'ALFKI'", connection)
						Await command.ExecuteNonQueryAsync()
					End Using

					Using command = New SqlCommand("update customers set companyname = 'customer2' where customerid = 'AARON'", connection)
						Await command.ExecuteNonQueryAsync()
					End Using

					transaction.Commit()
				Catch ex As SqlException
					transaction.Rollback()
				End Try
			End Using
		End Using
	End Function

	Private Async Function TransactionScope() As Task
		Using scope As New TransactionScope()
			Using connection As New SqlConnection(connectionString)
				Using command As New SqlCommand("update customers set companyname = 'alfred' where customerid = 'ALFKI'", connection)
					Await command.ExecuteNonQueryAsync()
				End Using

				Using command = New SqlCommand("update customers set companyname = 'customer2' where customerid = 'AARON'", connection)

					Await command.ExecuteNonQueryAsync()
				End Using

				scope.Complete()
			End Using
		End Using
	End Function
End Module
