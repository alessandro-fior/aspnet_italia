﻿using System.Linq;
using System.Xml.XPath;
using System.Xml;
using System;

public class Sample16
{

    public static void Run()
    {
        XPathDocument doc = new XPathDocument("test.xml");
        var navigator = doc.CreateNavigator();

        // Creo il gestore dei namespace
        XmlNamespaceManager nsManager = new XmlNamespaceManager(navigator.NameTable);
        // Associo il prefisso al namespace
        nsManager.AddNamespace("p", "http://schemas.aspitalia.com/book40/products");

        // Navigo direttamente sull'attributo
        XPathExpression exp = navigator.Compile("number(/p:products/p:product[1]/@idCategory)");
        // Imposto il resolver dei namespace
        exp.SetContext(nsManager);

        // Leggo il valore
        int idCategory = (int)navigator.Evaluate(exp);

        Console.WriteLine(idCategory);
    }

}
