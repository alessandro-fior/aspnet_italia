﻿Imports Chapter16.Models

Public Class _05_ListControl
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Using entities = New NorthwindContext()
            Dim customers = entities.Customers.OrderBy(Function(c) c.CompanyName)
            DropDownList1.DataSource = customers.ToList()
            DropDownList1.DataBind()
        End Using

    End Sub

End Class