﻿export function startVideo(videoElement) {
  return navigator.mediaDevices.getUserMedia({
    video: true
  })
    .then(c => {
      videoElement.srcObject = c;
      videoElement.play();
    })
}

export function takeSnapshot(videoElement, canvasElement) {
  var context = canvasElement.getContext('2d');
  context.drawImage(videoElement, 0, 0, 200, 200);

  return canvasElement.toDataURL('image/png');
}