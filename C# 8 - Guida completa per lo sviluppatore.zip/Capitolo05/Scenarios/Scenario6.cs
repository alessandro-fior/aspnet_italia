﻿using System;
using System.Collections;

namespace Capitolo5.Scenarios
{
    public static class Scenario6
    {
        /// <summary>
        /// Esempio 5.8
        /// </summary>
        public static void Run()
        {
            // creo una array list ed aggiungo parametri di tipi diversi
            var list = new ArrayList();
            list.Add(10);
            list.Add("Some string");
            list.Add(DateTime.Now);
            list.Add(new ArrayList());
            list.Add(new System.Globalization.CultureInfo("en-US"));

            // il casting funziona solo sugli oggetti dello stesso tipo...
            // in questo caso l'oggetto in posizione 0 è un intero e non un DateTime
            // per cui osservare la generazione della exception. 
            DateTime secondItem = (DateTime)list[0];
        }
    }
}