﻿Imports System.Windows.Markup

Public Class Bindings2

    Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        Me.Language = XmlLanguage.GetLanguage("it-IT")
    End Sub
End Class
