﻿using System;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario16
    {
        /// <summary>
        /// Esempio 8.18
        /// </summary>
        public static void Run()
        {
            var problematicTask = Task.Factory.StartNew(() =>
            {
                throw new ApplicationException("Errore!");
            });

            try
            {
                problematicTask.Wait();
            }
            catch (AggregateException ex)
            {
                Console.WriteLine("Il task ha sollevato la seguente eccezione:");
                Console.WriteLine(ex.InnerException);
            }
        }
    }
}