﻿using JWT;
using System;
using System.IdentityModel.Tokens.Jwt;

namespace Capitolo15.Helpers
{
    public class JWTHelper
    {
        /// <summary>
        /// Decodifica il token JWT e ne estrae il body come json
        /// </summary>
        /// <param name="jwt">JWT token</param>
        /// <returns></returns>
        public static string DecodeToken(string jwt)
        {
            if (string.IsNullOrEmpty(jwt))
                return string.Empty;

            var jwtHandler = new JwtSecurityTokenHandler();
            var token = jwtHandler.ReadJwtToken(jwt);
            return token.Payload.SerializeToJson();
        }
    }
}