using Microsoft.CodeAnalysis.CSharp;

namespace RoslynDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var syntaxTree = CSharpSyntaxTree.ParseText(@"
public class Test
{
  public string MyProperty { get; set; }
}");

            var root = syntaxTree.GetRoot();

            var nodes = root.DescendantNodes();

        }
    }
}
