﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports System.Net.Mail
Imports System.ComponentModel

Class MainWindow
  Private Sub Button1_Click( _
                           ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs) _
                         Handles Button1.Click

    Dim client As New SmtpClient("xxx.xxx.xxx.xxx")
    client.Credentials = New NetworkCredential("username", "password")

    Dim message As New MailMessage(
      New MailAddress("indirizzo_mittente"),
      New MailAddress("indirizzo_destinatario"))
    message.DeliveryNotificationOptions = _
      DeliveryNotificationOptions.OnFailure Or _
      DeliveryNotificationOptions.OnSuccess Or _
      DeliveryNotificationOptions.Delay

    message.Body = TextBox2.Text
    message.Subject = "messaggio di prova"

    AddHandler client.SendCompleted, AddressOf ClientSendCompleted
    client.SendAsync(message, Nothing)
  End Sub

  Private Sub ClientSendCompleted(ByVal sender As Object, _
    ByVal e As AsyncCompletedEventArgs)
    If (e.Error IsNot Nothing) Then
      TextBox2.Text = e.Error.ToString()
    Else
      TextBox2.Text = "inviato"
    End If
  End Sub
End Class
