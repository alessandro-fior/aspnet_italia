﻿using System;

namespace Chapter03
{
    // questo codice è compatibile anche con .NET Framework 4.8
    // per provarlo con .NET Framework, è sufficiente creare un nuovo progetto e copiarlo
    class Program
    {
        static void Main(string[] args)
        {
            // Testo di commento su singola riga
            Console.Write("Hello, World!"); // Commento dopo il codice 

            /* Testo di commento
               ripartito su più righe */
            Console.ReadLine();
        }
        static void Sample_3_3()
        {
            int x = 2;                  // Intero che contiene 2
            bool y = true;              // Valore booleano che vale true
            string s1 = "Hello";        // Punta ad un'area di memoria
            string s2 = null;           // Non punta a nulla
            object obj1 = new object(); // Crea un nuovo oggetto
            object obj2 = null;         // Non punta a nulla
        }

        static void Sample_3_6()
        {
            int i = 1, j = 2, k = 3;
            string x, y, z;
        }

        static void Sample_3_7()
        {
            const double PI = 3.1416;
            const string HELLO = "Hello World";
        }

        static void Sample_3_8()
        {
            object x = new object(); // Punta ad una nuova istanza
            object y = null;         // Punta a null
            object z;                // Punta a null
            object obj = x;          // obj si riferisce alla stessa istanza di x
        }

        static void Sample_3_9()
        {
            // Dichiarazione di una variabile intera senza e con type inference
            int i = 1;                // i è di tipo intero
            var j = 1;                // j è di tipo intero (type inference)

            // Dichiarazione di una stringa senza e con type inference
            string x = "Hello World"; // x è di tipo string
            var y = "Hello World";    // y è di tipo string (type inference)
        }

        static void Sample_3_10()
        {
            bool x, y = false;          // Variabili booleane (default = false)
            x = true;                   // Assegnazione del valore true
            x = !y;                     // Negazione booleana (x vale true)
            x = (18 > 8);               // A x viene assegnato il valore booleano
                                        // risultante dalla valutazione
                                        // dell'espressione di confronto (true)

            int i, j, k;                // Variabili intere
            i = 2;                      // Assegnazione
            j = i + 1;                  // Somma e assegnazione
            k = i * 2;                  // Prodotto e assegnazione

            int num;                    // Variabile intera
            num = i * j + k;            // Prodotto, somma e assegnazione

            bool isOdd;                 // Variabile booleana
            isOdd = (num % 2) != 0;     // Espressione che valuta se num è dispari

            string hello;               // Variabile di tipo string
            hello = "Hello " + "World"; // Concatenazione di stringhe
        }

        static void Sample_3_11()
        {
            int num = 0;           // Variabile intera
            num = 2 * 3 + 4 * 5;   // num vale 26
            num = 2 * (3 + 4) * 5; // num vale 70 
        }

        static void Sample_3_12()
        {
            int x = 0;    // Variabile intera (4 byte)
            byte y = 100; // Variabile di tipo byte (1 byte)
            x = y;        // Conversione implicita
            y = (byte)x; // Conversione esplicita
            y = x;        // Errore di compilazione
            x = 1000;     // Valore non incluso nel range del tipo byte
            y = (byte)x; // Errore di overflow a runtime
        }

        static void Sample_3_13()
        {
            string[] x = new string[3]; // Vettore composto da tre stringhe
            x[0] = "Hello ";            // Contiene "Hello "
            x[1] = "World";             // Contiene "World"
            x[2] = x[0] + x[1];         // Contiene "Hello World"

            int[] y = { 1, 2, 3 };      // Vettore composto da tre interi
            int z = y[1];
        }

        static void Sample_3_14()
        {
            var x1 = new[] { 0, 1, 2, 3, 4, 5 };       // int[]
            var x2 = new[] { 0, 0.5, 1, 1.5, 2 };      // double[]
            var x3 = new[] { "Daniele", "Bochicchio" };    // string[]
            var x4 = new[] { 1, "x", 2, "y", 3, "z" }; // Errore

        }

        static void Sample_3_15()
        {
            int[,,] coords = new int[3, 3, 3]; // Coordinate spaziali (dim. 3)
            coords[0, 0, 0] = 1;               // Origine (x = 0, y = 0, z = 0)
            coords[1, 1, 1] = 2;               // x = 1, y = 1, z = 1
            coords[2, 2, 2] = 3;               // x = 2, y = 2, z = 2
        }

        // 3.16
        enum Gender // Enumerazione di tipo int (default) - Sesso
        {
            Male,     // Vale 0 (int) - Maschio
            Female    // Vale 1 (int) - Femmina
        }

        // 3.17
        enum DayOfWeek : byte // Giorno della settimana
        {
            Monday = 1,         // Vale 1 (byte) - Lunedì
            Tuesday = 2,        // Vale 2 (byte) - Martedì
            Wednesday = 3,      // Vale 3 (byte) - Mercoledì
            Thursday = 4,       // Vale 4 (byte) - Giovedì
            Friday = 5,         // Vale 5 (byte) - Venerdì
            Saturday = 6,       // Vale 6 (byte) - Sabato
            Sunday = 7          // Vale 7 (byte) - Domenica
        }

        static void Sample_3_18()
        {
            Gender x = Gender.Male;  // Variabile di tipo Gender
            int y = 0, z = 2;        // Variabili intere
            y = (int)Gender.Female; // y vale 1
            y = (int)x;             // y vale 0
            x = (Gender)y;          // Valore ammissibile
            x = (Gender)z;          // Errore – Valore 2 non ammissibile
        }

        // 3.19
        // Funzione che calcola la somma di due interi
        static int Sum(int x, int y)
        {
            return x + y;
        }

        // Procedura che scrive un messaggio a video
        static void Write(string text)
        {
            Console.Write(text);
        }

        // 3.20
        // Passaggio per valore
        //static int Sum(int x, int y)
        //{
        //    return x + y;
        //}

        // Passaggio per valore e per riferimento
        static void Sum(int x, int y, out int result)
        {
            result = x + y;
        }

        // Passaggio per riferimento in ingresso
        static int Test(in int x)
        {
            x = 11; // questa istruzione produce un errore di compilazione
        }

        static void Sample_3_20()
        {
            int num = Sum(11, 22);      // num vale 33
            Sum(111, 222, out num);     // num vale 333

            Sum(111, 222, out _);      // con _ ignoriamo il valore di ritorno

            Sum(111, 222, out var y);  // il valore in uscita sarà nella variabile y
        }

        // Funzione che somma tre numeri con due parametri opzionali
        static int Sum(int x, int y = 0, int z = 0)
        {
            return x + y + z;
        }

        static void Sample_3_21()
        {
            // Numeri interi
            int i = 18, j = 8, k = 5;

            // Invocazione classica: il risultato è 31
            Sum(i, j, k);

            // Uso dei parametri opzionali
            Sum(i, j);             // Equivale a: Sum(i, j, 0) e il risultato è 26
            Sum(i);                // Equivale a: Sum(i, 0, 0) e il risultato è 18

            // Uso dei parametri nominali
            Sum(z: i, y: j, x: k); // Equivale a: Sum(k, j, i) e il risultato è 31
            Sum(z: k, i);          // Errore di compilazione

            // Uso di un parametro nominale per assegnare un valore diverso da
            // quello di default all'ultimo parametro opzionale
            Sum(i, z: k);          // Equivale a: Sum(i, 0, k) e il risultato è 23
            Sum(i, , k);            // Errore di compilazione

        }

        static void Sample_3_22()
        {
            string name = null;  // warning
            string? name2 = null; // OK

            void PrintName(string? s)
            {
                Console.WriteLine(s.Length); // warning
                if (s != null)
                    Console.WriteLine(s.Length); // OK
            }
        }

        static void Sample_3_24_26()
        {
            // 3.24
            string name = "Daniele";
            switch (name)
            {
                case "Matteo": // Valore singolo
                               // ...
                    break;
                case "Cristian": // Viene eseguito lo stesso blocco di
                case "Daniele":  // codice nel caso in cui il valore di
                case "Marco":    // name sia uno dei tre indicati
                                 // ...
                    break;
                default:         // Blocco di default opzionale
                                 // ...
                    break;
            }

            // 3.25
            var person = new Customer { Name = "Daniele Bochicchio" };
            switch (person)
            {
                case Customer a when (a.Active):  // se è un Customer attivo
                                                  // ...
                    break;
                case Supplier b when (b.IsValid): // se è un Supplier con validità in corso
                                                  // ...
                    break;
                default:                         // blocco di default opzionale
                                                 // ...
                    break;
                case null:                       // caso speciale per gestire i null
                                                 // ...
                    break;
            }

            string GetDescription(Person person)
            {
                return person switch
                {
                    Supplier s => $"Fornitore {s.Name}",
                    Customer c => $"Cliente {c.Name}",
                    _ => "{person.FirstName} {person.LastName}" // default
                };
            }
        }

        // 3.24-3.26
        public class Person
        {
            public string Name { get; internal set; }
        }

        public class Customer : Person
        {
            public bool Active { get; set; }
        }

        public class Supplier : Customer
        {
            public bool IsValid { get; set; }
        }

        // 3.27
        static void Sample_3_27()
        {
            int i = 2;
            // Se i è dispari, isOdd vale true
            bool isOdd = (i % 2 == 1) ? true : false;

            // Se x è null, ritorna y, altrimenti ritorna x
            string x = null;
            string y = "Hello World";
            string z = x ?? y; // z vale "Hello World"	
        }

        static void Sample_3_28()
        {
            var customer = new Customer { Name = "Daniele Bochicchio" };
            // codice precedente
            string name = "";
            if (customer != null)
                name = customer.Name;

            // nuova sintassi
            string name2 = customer?.Name; // null se customer è null
        }

        static void Sample_3_29()
        {
            int[] x = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int y = 0; // Somma dei numeri contenuti nel vettore 
            int i = 0; // Indice del vettore

            // Somma i dieci numeri contenuti nel vettore
            // Alla fine del ciclo y vale 55 e i vale 10
            while (i < 10)
            {
                y += x[i];
                i++; // Incremento di 1
            }
        }

        static void Sample_3_30()
        {
            int[] x = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int y = 0; // Somma dei numeri contenuti nel vettore 
            int i = 0; // Indice del vettore

            // Somma i dieci numeri contenuti nel vettore
            // Alla fine del ciclo y vale 55 e i vale 10
            do
            {
                y += x[i];
                i++; // Incremento di 1
            }
            while (i < 10); // Condizione finale
        }

        static void Sample_3_31()
        {
            int[] x = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int y = 0; // Somma dei numeri contenuti nel vettore 

            // Somma i dieci numeri contenuti nel vettore
            // Alla fine del ciclo y vale 55
            for (int i = 0; i < 10; i++)
            {
                y += x[i];
            }
        }
        static void Sample_3_32()
        {
            int[] x = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int y = 0; // Somma dei numeri contenuti nel vettore 

            // Somma i dieci numeri contenuti nel vettore
            // Alla fine del ciclo y vale 55
            foreach (int item in x)
            {
                y += item;
            }
        }

        static void Sample_3_33()
        {
            int[] x = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int y = 0; // Somma dei numeri contenuti nel vettore 

            // Somma i primi quattro numeri diversi da 5 contenuti nel vettore
            // Alla fine del ciclo y vale 10
            foreach (int item in x)
            {
                if (item == 5)
                    break;
                y += item;
            }
        }

        static void Sample_3_34()
        {
            int[] x = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int y = 0; // Somma dei numeri contenuti nel vettore 

            // Somma i numeri diversi da 5 contenuti nel vettore
            // Alla fine del ciclo y vale 50
            foreach (int item in x)
            {
                if (item == 5)
                    continue;
                y += item;
            }
        }

        // 3.35
        // Somma i numeri contenuti nel vettore passato come parametro
        // Se il vettore è nullo ritorna zero, altrimenti esegue la somma
        int Sum3_35(int[] x)
        {
            if (x == null)
            {
                return 0;
            }

            int y = 0;
            foreach (int item in x)
            {
                y += item;
            }

            return y;
        }

        static void Sample_3_36()
        {
            int[] x = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int y = 0; // Somma dei numeri contenuti nel vettore 

            // Somma i primi quattro numeri diversi da 5 contenuti nel vettore
            // Alla fine del ciclo y vale 10 e la somma viene visualizzata a video
            foreach (int item in x)
            {
                if (item == 5)
                    goto finish;
                y += item;
            }

            finish: // Etichetta
            Console.Write("Somma: " + y);
        }

        static void Sample_3_37()
        {
            string name = "Daniele";
            string city = "Rionero in Vulture";

            string fullName = string.Format("Ti chiami {0} e vieni da {1}",
                                 name, city);
        }

        static void Sample_3_38()
        {
            string name = "Daniele";
            string city = "Milano";

            string fullName = $"Ti chiami {name} e vieni da {city}";

        }

    }
}
