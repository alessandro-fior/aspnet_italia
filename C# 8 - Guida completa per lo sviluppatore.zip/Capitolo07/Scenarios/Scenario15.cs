﻿using System;
using System.Dynamic;

namespace Capitolo7.Scenarios
{
    public static class Scenario15
    {
        /// <summary>
        /// Esempio 7.23
        /// </summary>
        public static void Run()
        {
            dynamic myObject = new ExpandoObject();

            // Aggiunta di un metodo all'oggetto tramite lambda expression
            // ToText restituisce una string e pertanto è di tipo Func<string>
            myObject.ToText = (Func<string>)(
                () => string.Format("{0} ha {1} anni", myObject.Name, myObject.Age)
            );
            
            // Aggiunta dinamica di due proprietà
            myObject.Name = "Matteo Tumiati";
            myObject.Age = 28;
            
            // Invocazione del metodo definito in precedenza
            Console.WriteLine(myObject.ToText());
        }
    }
}