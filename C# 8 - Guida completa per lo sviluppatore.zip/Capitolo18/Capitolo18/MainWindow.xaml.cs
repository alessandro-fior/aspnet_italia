﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp8
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private byte[] key;
        private byte[] vector;
        byte[] keyCrypted;
        byte[] vectorCrypted;
        TripleDESCryptoServiceProvider cryptoProvider;
        private byte[] keyDecrypted;
        private byte[] vectorDecrypted;

        public MainWindow()
        {
            InitializeComponent();
        }

        public void DemoCript()
        {
            //generazione automatica da parte provider
            cryptoProvider = new TripleDESCryptoServiceProvider();
            key = cryptoProvider.Key;
            vector = cryptoProvider.IV;

            //dichiarazione esplicita diretta
            key = new byte[] { 0xea, 12, 0x43, 0xf5, 0x42, 0x63, 0x16, 0xd6, 6, 0x58, 0x7c, 0x2c, 0xdd, 0x22, 9, 0x16 };

            string password = "password per generare chiave";
            string salt = "salt per generare chiave";

            byte[] passwordByte = Encoding.UTF8.GetBytes(password);
            byte[] saltByte = Encoding.UTF8.GetBytes(salt);

            key = new PasswordDeriveBytes(passwordByte, saltByte).CryptDeriveKey("TripleDES", "SHA1", 192, this.vector);

            byte[] dataByte = Encoding.UTF8.GetBytes(textToCript.Text);

            using (ICryptoTransform encryptor = cryptoProvider.CreateEncryptor(this.key, this.vector))
            {
                using (Stream stream = File.Create(@"c:\temp\encrypted.txt"))
                {
                    using (CryptoStream cryptoStream = new CryptoStream(stream, encryptor, CryptoStreamMode.Write))
                    {
                        cryptoStream.Write(dataByte, 0, dataByte.Length);
                        cryptoStream.FlushFinalBlock();
                    }
                }
            }
        }
        public void DemoDeCript()
        {
            using (ICryptoTransform encryptor = this.cryptoProvider.CreateDecryptor(this.key, this.vector))
            {
                using (Stream stream = File.OpenRead(@"c:\temp\encrypted.txt"))
                {
                    using (Stream cryptoStream = new CryptoStream(stream,
                        encryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader reader = new StreamReader(cryptoStream))
                        {
                            textToDECript.Text = reader.ReadToEnd();
                        }
                    }
                }
            }
        }
        public void DemoCriptAsim()
        {
            using (RSACryptoServiceProvider asCryptoProvider = new RSACryptoServiceProvider())
            {
                File.WriteAllText(@"c:\temp\PublicKey.xml", asCryptoProvider.ToXmlString(false));
                File.WriteAllText(@"c:\temp\PublicAndPrivate.xml", asCryptoProvider.ToXmlString(true));
            }

            TripleDESCryptoServiceProvider cryptoProvider = new TripleDESCryptoServiceProvider();
            key = cryptoProvider.Key;
            vector = cryptoProvider.IV;

            //lettura chiave pubblica per cifratura asimmetrica
            string publicKeyOnly = File.ReadAllText(@"c:\temp\PublicKey.xml");

            //cifratura asimmetrica della chiave simmetrica
            using (RSACryptoServiceProvider asCryptoProvider = new RSACryptoServiceProvider())
            {
                asCryptoProvider.FromXmlString(publicKeyOnly);
                keyCrypted = asCryptoProvider.Encrypt(key, true);
                vectorCrypted = asCryptoProvider.Encrypt(vector, true);
            }
            //dati riservati
            byte[] dataByte = Encoding.UTF8.GetBytes(textToCript.Text);

            //cifratura simmetrica con chiave e vettore autogenerati
            using (ICryptoTransform encryptor = cryptoProvider.CreateEncryptor(key, vector))
            {
                using (Stream stream = File.Create(@"c:\temp\encrypted.txt"))
                {
                    using (CryptoStream cryptoStream = new CryptoStream(stream,
                        encryptor, CryptoStreamMode.Write))
                    {
                        cryptoStream.Write(dataByte, 0, dataByte.Length);
                        cryptoStream.FlushFinalBlock();
                    }
                }
            }
        }
        public void DemoDeCriptAsim()
        {


            //lettura chiave pubblica e privata
            string publicPrivate = File.ReadAllText(@"c:\temp\PublicAndPrivate.xml");

            //decifratura chiave simmetrica e vettore, con algoritmo asimmetrico
            using (RSACryptoServiceProvider asCryptoProvider = new RSACryptoServiceProvider())
            {
                asCryptoProvider.FromXmlString(publicPrivate);
                keyDecrypted = asCryptoProvider.Decrypt(keyCrypted, true);
                vectorDecrypted = asCryptoProvider.Decrypt(vectorCrypted, true);
            }

            //decifratura dati riservati con chiave simmetrica decifrata
            using (ICryptoTransform encryptor =
                this.cryptoProvider.CreateDecryptor(keyDecrypted,
                vectorDecrypted))
            {
                using (Stream stream = File.OpenRead(@"c:\temp\encrypted.txt"))
                {
                    using (Stream cryptoStream = new CryptoStream(stream,
                        encryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader reader = new StreamReader(cryptoStream))
                        {
                            textToDECript.Text = reader.ReadToEnd();
                        }
                    }
                }
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DemoCript();
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            DemoDeCript();
        }
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            DemoCriptAsim();
        }
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            DemoDeCriptAsim();
        }
    }
}
