﻿Imports Microsoft.Win32
Imports System.IO
Imports System.Net.Sockets
Imports System.Threading
Imports System.Net
Imports System.Windows.Media.Drawing

Class MainWindow
  Public Delegate Sub ManageDataDelegate(ByVal result As MemoryStream)

  Public Sub New()
    InitializeComponent()

    Dim threadServer = New Thread(New ThreadStart(AddressOf ReiceveData))
    threadServer.IsBackground = True
    threadServer.Start()
  End Sub

  Private Sub ReiceveData()
    Dim server As New TcpListener(New IPEndPoint(IPAddress.Any, 1234))
    server.Start()

    While (True)
      If server.Pending() Then
        Dim localClient As TcpClient = server.AcceptTcpClient()
        Dim netStream As NetworkStream = localClient.GetStream()

        If netStream.CanRead Then
          Dim dataStream As MemoryStream = New MemoryStream()
          Dim dataByte As Byte() = New Byte(1023) {}
          Dim i As Integer = 0

          Do
            i = netStream.Read(dataByte, 0, 1024)
            If i > 0 Then
              dataStream.Write(dataByte, 0, i)
            End If
          Loop While i > 0

          dataStream.Seek(0, SeekOrigin.Begin)
          Dispatcher.BeginInvoke(New ManageDataDelegate( _
                                 AddressOf ViewData), dataStream)

        End If
        localClient.Close()
        netStream.Close()
      End If
    End While
  End Sub

  Private Sub ViewData(ByVal datas As MemoryStream)
    'Dim _path As String = String.Format("d:\esempio.jpg")
    'Using stream As FileStream = File.OpenWrite(_path)
    'Dim dataByte As Byte() = New Byte(1023) {}
    'Dim i As Integer = 0

    'Do
    'i = datas.Read(dataByte, 0, 1024)
    'If i > 0 Then
    'stream.Write(dataByte, 0, i)
    'End If
    'Loop While i > 0
    'End Using

    Dim bmpImage As BitmapImage = New BitmapImage()
    bmpImage.BeginInit()
    bmpImage.StreamSource = datas
    bmpImage.EndInit()

    Dim img As Image = New Image()
    img.Stretch = Stretch.Uniform
    img.Source = bmpImage
    StackPanel1.Children.Add(img)

    'datas.Close()
  End Sub

  Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button2.Click
    Dim fileDialog As New OpenFileDialog()
    fileDialog.Filter = "immagini (*.jpg)|*.jpg"
    Dim show As Boolean? = fileDialog.ShowDialog()
    If show IsNot Nothing And show.Value = True Then
      Using s As Stream = fileDialog.OpenFile()
        TextBlock1.Tag = fileDialog.FileName
        TextBlock1.Text = fileDialog.SafeFileName
      End Using
    End If
  End Sub

  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button1.Click
    Using fileStream As Stream = File.OpenRead(TextBlock1.Tag.ToString())
      Dim client As New TcpClient()
      client.Connect("localhost", 1234)
      Dim netStream As NetworkStream = client.GetStream()

      Dim sendBuffer(1023) As Byte
      Dim bytesRead As Integer = 0

      Do
        bytesRead = fileStream.Read(sendBuffer, 0, 1024)
        If bytesRead > 0 Then
          netStream.Write(sendBuffer, 0, bytesRead)
        End If
      Loop While bytesRead > 0

      netStream.Close()
    End Using
  End Sub


End Class



