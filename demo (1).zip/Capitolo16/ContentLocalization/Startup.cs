﻿using System;
using System.Globalization;
using ContentLocalization.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace ContentLocalization
{
    // NOTE: provare l'esecuzione con i seguenti url
    // http://localhost:5000/?key=abc
    // http://localhost:5000/?key=abc&ui-culture=it-IT oppure &ui-culture=en-US
    // http://localhost:5000/?key=title
    // http://localhost:5000/?key=title&ui-culture=it-IT oppure &ui-culture=en-US
    // http://localhost:5000/?all elenca tutte le chiavi
    // http://localhost:5000/

    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        { 
            // registrazione dei servizi di base
            services.AddTransient<ICustomService, CustomService>();
            services.AddTransient<IAggregatorService, AggregatorService>();

            // aggiunta della localizzazione
            services.AddLocalization(options => 
            {
                // i file di risorse si trovano nella cartella "Resources"
                // a partire dalla root del progetto
                options.ResourcesPath = "Resources";
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.Run(async (context) =>
            {
                // se nella query string c'è il parametro "ui-culture", 
                // allora questo verrà impostato come CurrentUICulture per le prossime request
                // altrimenti di default verrà utilizzata la InvariantCulture
                if (context.Request.Query.ContainsKey("ui-culture"))
                {
                    string culture = context.Request.Query["ui-culture"];
                    CultureInfo.CurrentUICulture = new CultureInfo(culture);
                }

                // aggiunge alla response la cultura corrente
                await context.Response.WriteAsync($"CurrentUICulture: {CultureInfo.CurrentUICulture}" +
                                                  $"{Environment.NewLine}");

                var reply = string.Empty;

                // se nella query string è presenta "key", allora viene 
                // caricato il custom service e recuperata la chiave corrispondente
                if (context.Request.Query.ContainsKey("key"))
                {
                    var customService = context.RequestServices.GetService<ICustomService>();
                    reply = customService.SendReply(context.Request.Query["key"]);
                }

                // se invece nella query string è presente la chiave "all", 
                // viene caricato l'aggregator service che elencherà tutte le chiavi
                else if (context.Request.Query.ContainsKey("all"))
                {
                    var aggregatorService = context.RequestServices.GetService<IAggregatorService>();
                    reply = aggregatorService.GetAllKeys();
                }

                // scenario di default in caso non ci sia una route riconosciuta
                else
                {
                    reply = "Utilizzare \"key={0}\" oppure \"all\" nella query string per vedere i contenuti localizzati";
                }

                // scrive la risposta
                await context.Response.WriteAsync(reply);
            });
        }
    }
}