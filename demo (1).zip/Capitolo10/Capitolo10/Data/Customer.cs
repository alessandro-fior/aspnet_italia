﻿using System.Collections.Generic;

namespace Capitolo10.Data
{
	public partial class Customer
	{
		public Customer()
		{
			Orders = new HashSet<Order>();
		}

		public string CustomerId { get; set; }
		public string CompanyName { get; set; }
		public string ContactName { get; set; }
		public string ContactTitle { get; set; }
		public AddressInfo Address { get; set; }
		public string Phone { get; set; }
		public string Fax { get; set; }

		public virtual ICollection<Order> Orders { get; set; }
	}
}
