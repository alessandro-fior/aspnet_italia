﻿using System;
using System.Collections.Generic;

namespace Capitolo5.Scenarios
{
    public static class Scenario8
    {
        /// <summary>
        /// Esempio 5.10, 5.11
        /// </summary>
        public static void Run()
        {
            // qui abbiamo usato un array, ma un qualsiasi
            // IEnumerable<string> va bene
            var source = new string[] { "String1", "String2", "String3" };
            var strings = new List<string>(source);
            Console.WriteLine($"La lista contiene {strings.Count} elementi");

            // Inizializzazione inline
            var strings2 = new List<string>
            {
                "String1",
                "String2",
                "String3"
            };
            Console.WriteLine($"La lista contiene {strings2.Count} elementi");

            // Inizializzazione inline con indici espliciti
            var strings3 = new List<string>
            {
                [0] = "String1",
                [4] = "String5",
                [2] = "String3"
            };            
            Console.WriteLine($"La lista contiene {strings3.Count} elementi");
        }
    }
}