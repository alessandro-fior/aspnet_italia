Imports System
Imports System.IO
Imports System.IO.IsolatedStorage
Imports System.Text
Imports Microsoft.Win32

Module Program
    Sub Main(args As String())
        Dim choice = Console.ReadLine()

        Select Case choice
            Case "19.1"
                Example1()
            Case "19.2"
                Example2()
            Case "19.3"
                Example3()
            Case "19.4"
                Exmple4()
            Case "19.5"
                Exmple5()
            Case "19.6"
                Example6()
            Case "19.7"
                Example7()
            Case "19.8"
                Example8()
            Case "19.9"
                Example9()
            Case "19.10"
                Example10()
            Case "19.11"
                Example11()
            Case "19.12"
                Example12()
            Case "19.13"
                Example13()
            Case Else
        End Select
    End Sub
    Private Sub Example1()
        Dim dInfo As DirectoryInfo = New DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19"))

        Try
            dInfo.Create()
            Console.WriteLine("Directory creata correttamente, premi un tasto per spostarla")
            Console.ReadLine()

            If Not Directory.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Capitolo19")) Then
                dInfo.MoveTo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Capitolo19"))
                Console.WriteLine("Directory spostata correttamente")
            Else
                Console.WriteLine("Directory gi� esistente!")
            End If

        Catch ex As Exception
            Console.WriteLine("Si � verificato un errore: {0}", ex.ToString())
        End Try

        Console.ReadLine()
    End Sub

    Private Sub Example2()
        Try
            Directory.CreateDirectory(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19"))
            Console.WriteLine("Directory creata correttamente")
        Catch ex As Exception
            Console.WriteLine("Impossibile creare la directory: {0}", ex.ToString())
        End Try

        Console.ReadLine()
    End Sub

    Private Sub Example3()
        Dim dInfo As DirectoryInfo = New DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19"))

        Try
            dInfo.Create()
            Console.WriteLine("Directory creata correttamente, premi un tasto er eliminarla")
            Console.ReadLine()
            dInfo.Delete()
            Console.WriteLine("Directory Eliminata correttamente")
        Catch ex As Exception
            Console.WriteLine("Si � verificato un errore: {0}", ex.ToString())
        End Try

        Console.ReadLine()
    End Sub

    Private Sub Exmple4()
        Dim myPath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19")

        Try
            Directory.CreateDirectory(myPath)
            Console.WriteLine("Directory creata correttamente, premi un tasto per eliminarla")
            Console.ReadLine()
            Directory.Delete(myPath)
            Console.WriteLine("Directory Eliminata correttamente")
        Catch ex As Exception
            Console.WriteLine("Impossibile creare la directory: {0}", ex.ToString())
        End Try

        Console.ReadLine()
    End Sub

    Private Sub Exmple5()
        Dim dInfo As DirectoryInfo = New DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19"))

        Try
            dInfo.Create()
            dInfo.CreateSubdirectory("Esempio 19.5")
            Console.WriteLine("Directory e sotto directory creata correttamente,premi un tasto per eliminarla")
            Console.ReadLine()
            dInfo.Delete(True)
            Console.WriteLine("Directory Eliminata correttamente")
        Catch ex As Exception
            Console.WriteLine("Si � verificato un errore: {0}", ex.ToString())
        End Try

        Console.ReadLine()
    End Sub

    Private Sub Example6()
        Dim dInfo As DirectoryInfo = New DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19"))

        Try
            dInfo.Create()
            Console.WriteLine("Directory creata correttamente, premi un tasto per spostarla")
            Console.ReadLine()
            dInfo.MoveTo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Capitolo19"))
            Console.WriteLine("Directory spostata correttamente")
        Catch ex As Exception
            Console.WriteLine("Si � verificato un errore: {0}", ex.ToString())
        End Try

        Console.ReadLine()
    End Sub

    Private Sub Example7()
        Dim dInfo As DirectoryInfo = New DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Capitolo19"))

        Try
            dInfo.Create()
            Console.WriteLine("Directory creata correttamente, premi un tasto per spostarla")
            Console.ReadLine()

            If Not Directory.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Capitolo19")) Then
                dInfo.MoveTo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Capitolo19"))
                Console.WriteLine("Directory spostata correttamente")
            Else
                Console.WriteLine("Directory gi� esistente")
            End If

        Catch ex As Exception
            Console.WriteLine("Si � verificato un errore: {0}", ex.ToString())
        End Try

        Console.ReadLine()
    End Sub

    Private Sub Example8()
        Dim directories As DirectoryInfo() = New DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)).GetDirectories()

        Try

            For Each directoryInfo As DirectoryInfo In directories
                Dim copyPath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), String.Format("{0} copia", directoryInfo.Name))
                Directory.CreateDirectory(copyPath)
                Console.WriteLine(String.Format("Directory {0} copiata correttamente", directoryInfo.Name))
                Dim files As FileInfo() = directoryInfo.GetFiles()

                For Each fileInfo As FileInfo In files
                    fileInfo.CopyTo(Path.Combine(copyPath, String.Format("{0} copia{1} ", Path.GetFileNameWithoutExtension(fileInfo.Name), Path.GetExtension(fileInfo.Name))))
                    Console.WriteLine(String.Format("File {0} copiato correttamente", fileInfo.Name))
                Next
            Next

        Catch ex As Exception
            Console.WriteLine("Si � verificato un errore: {0}", ex.ToString())
        End Try

        Console.ReadLine()
    End Sub

    Private Sub Example9()
        Dim dInfo As DirectoryInfo = New DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments))

        Try
            Dim directories As DirectoryInfo() = dInfo.GetDirectories("*", SearchOption.TopDirectoryOnly)

            For Each directory As DirectoryInfo In directories
                Console.WriteLine("{0} {1}", directory.FullName, directory.LastAccessTime)
            Next

        Catch ex As Exception
            Console.WriteLine("Si � verificato un errore: {0}", ex.ToString())
        End Try

        Console.ReadLine()
    End Sub

    Private Async Function Example10() As Task
        Try
            Dim myPath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "myfile.txt")

            Using myfileStream = File.Create(myPath)
                Dim info As Byte() = New UTF8Encoding(True).GetBytes("Un saluto dall'autore di questo capitolo.")
                Await myfileStream.WriteAsync(info, 0, info.Length)
                myfileStream.Close()

                Using mySteamiReader As StreamReader = File.OpenText(myPath)

                    While mySteamiReader.Peek() >= 0
                        Console.WriteLine("Il file contiene: {0}", mySteamiReader.ReadLine())
                    End While
                End Using
            End Using

        Catch ex As Exception
            Console.WriteLine("Si � verificato un errore: {0}", ex.ToString())
        End Try

        Console.ReadLine()
    End Function

    Private Sub Example11()
        Try
            Dim isoFile As IsolatedStorageFile = IsolatedStorageFile.GetStore(IsolatedStorageScope.User Or IsolatedStorageScope.Assembly Or IsolatedStorageScope.Domain, Nothing)

            If Not isoFile.DirectoryExists("Documenti") Then
                isoFile.CreateDirectory("Documenti")
            End If

            Dim isoStream As IsolatedStorageFileStream = isoFile.CreateFile("myFile.txt")
            Dim info As Byte() = New UTF8Encoding(True).GetBytes("Un saluto dall'autore di questo capitolo.")
            isoStream.Write(info, 0, info.Length)
            isoStream.Close()

            Using mySteamiReader As StreamReader = New StreamReader(isoFile.OpenFile("myFile.txt", FileMode.Open))

                While mySteamiReader.Peek() >= 0
                    Console.WriteLine("il file contiene: {0}", mySteamiReader.ReadLine())
                End While

                mySteamiReader.Close()
            End Using

        Catch ex As Exception
            Console.WriteLine("Si � verificato un errore: {0}", ex.ToString())
        End Try

        Console.ReadLine()
    End Sub

    Private Sub Example12()
        Dim registrykey As RegistryKey = Registry.LocalMachine
        registrykey = registrykey.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0")
        Dim value As Object = registrykey.GetValue("ProcessorNameString")
        Console.WriteLine("Il tu� processore �:" & value)
        Console.ReadLine()
    End Sub

    Private Sub Example13()
        Dim chapter19 As RegistryKey = Registry.CurrentUser.CreateSubKey("Capitolo19")
        Dim autor As RegistryKey = chapter19.CreateSubKey("Autore")
        autor.SetValue("Name", "Marco")
        Console.WriteLine("Chiave creata con successo")
        Console.ReadLine()
    End Sub
End Module
