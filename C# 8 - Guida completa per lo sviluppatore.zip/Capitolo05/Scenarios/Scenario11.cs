﻿using System;

namespace Capitolo5.Scenarios
{
    public static class Scenario11
    {
        /// <summary>
        /// Esempio 5.16
        /// </summary>
        public static void Run()
        {
            int a = 5;
            int b = 8;

            Console.WriteLine($"[Pre-Swap] A: {a}, B: {b}");
            
            Swap(ref a, ref b);

            Console.WriteLine($"[Post-Swap] A: {a}, B: {b}");
        }

        private static void Swap<T>(ref T first, ref T second)
        {
            T temp = first;
            first = second;
            second = temp;
        }
    }
}