﻿Imports System.ServiceModel.Activation

<AspNetCompatibilityRequirements(RequirementsMode:=AspNetCompatibilityRequirementsMode.Allowed)>
Public Class Products
    Implements IProducts

    Public Function GetAllProducts() As Product() _
        Implements IProducts.GetAllProducts

        Return New Product() {
                New Product With {.ID = 1, .Name = "prodotto 1"}
            }

    End Function
End Class
