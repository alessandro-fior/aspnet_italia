﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web

Public Class DettaglioOrdine
	Public Property Id As Int32
	Public Property Quantita As Int32
	Public Property Prezzo As Double
	Public Property Prodotto As Prodotto
End Class
