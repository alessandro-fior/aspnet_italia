﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Markup;

namespace Capitolo14
{
    /// <summary>
    /// Interaction logic for Bindings.xaml
    /// </summary>
    public partial class Bindings : Window
    {
        public Bindings()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            this.Language = XmlLanguage.GetLanguage("it-IT");

            Category[] list = {
                new Category {
                    Products = new Product[] {
                        new Product {Description = "Cat 1 - Prodotto 1", Id = 1},
                        new Product {Description = "Cat 2 - Prodotto 2", Id = 2}},
                    Description = "Categoria 1",
                    Id = 1
                },
                new Category {
                    Products = new Product[] {
                        new Product {Description = "Cat 2 - Prodotto 3", Id = 1},
                        new Product {Description = "Cat 2 - Prodotto 4", Id = 2}},
                    Description = "Categoria 2",
                    Id = 2
                }
            };

            this.DataContext = list;
        }
    }


    public class Category
    {
        public int Id { get; set; }

        public string Description { get; set; }

        public Product[] Products { get; set; }
    }

    public class Product
    {
        public int Id { get; set; }

        public string Description { get; set; }
    }
}
