﻿Imports System.ComponentModel

Namespace ASPItalia.Books.Chapter06
    Public Class PortDataReceivedEventArgs
        Inherits EventArgs

        Property Data As String
    End Class

    Public Class PortReceiver
        Public Delegate Sub PortDataReceivedEventHandler(
          ByVal sender As Object, ByVal e As PortDataReceivedEventArgs)

        Public Event PortDataReceived As PortDataReceivedEventHandler

        Protected Overridable Sub OnPortDataReceived(ByVal data As String)
            Dim e As New PortDataReceivedEventArgs()
            e.Data = data

            RaiseEvent PortDataReceived(Me, e)
        End Sub

        Public Event PortDataReceiving As CancelEventHandler

        Protected Overridable Sub OnPortDataReceiving(
            ByVal e As CancelEventArgs)
            RaiseEvent PortDataReceiving(Me, e)
        End Sub

        Property Data As String

        Public Sub ReceiveData()
            Dim e As New CancelEventArgs(False)
            OnPortDataReceiving(e)

            ' qui verifichiamo se un sottoscrittore 
            ' ha cancellato la ricezione dati
            If Not e.Cancel Then
                Data = "Data received"
                OnPortDataReceived(Data)
            End If
        End Sub

        ' .. codice di interfacciamento con la porta ..
    End Class
End Namespace