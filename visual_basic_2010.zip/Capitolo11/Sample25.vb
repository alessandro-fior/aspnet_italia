﻿Imports System.Linq
Imports System.Xml.XPath
Imports System.Xml
Imports System.Xml.Xsl



Public Class Sample25

    Public Shared Sub Run()

        Dim xslt As New XslCompiledTransform()
        ' Carico la trasformazione XSLT
        xslt.Load("test.xslt")

        ' Trasformo l'XML e lo mostro nella finestra di Output
        xslt.Transform("test.xml", Nothing, Console.Out)

    End Sub

End Class
