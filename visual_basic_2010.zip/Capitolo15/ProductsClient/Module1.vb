﻿
Module Module1

    Sub Main()
        ' Creo il proxy
        Dim client As New Services.ProductsClient
        ' Ottengo la lista dei prodotti
        Dim products() As Product = client.GetAllProducts()

        Console.WriteLine(products(0).Name)

        ' Attendo fino a quando l'utente preme invio
        Console.ReadLine()

        Dim context As New OData.NorthwindEntities(New Uri("http://localhost:41306/northwind.svc"))
        Dim product = (From p In context.Products
                        Where p.ProductName = "Chai"
                        Select p).FirstOrDefault()
        Console.WriteLine(products(0).Name)

        Console.ReadLine()
    End Sub

End Module
