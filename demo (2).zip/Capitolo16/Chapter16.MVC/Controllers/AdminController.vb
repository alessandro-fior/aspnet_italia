﻿Imports System.Web.Mvc
Imports Chapter16.MVC.Models

Namespace Controllers
    Public Class AdminController
        Inherits Controller

        Private db As New StoreContext()

        '
        ' GET: /Admin/

        Public Function Index() As ActionResult
            Return View(db.Customers.ToList())
        End Function

        '
        ' GET: /Admin/Details/5

        Public Function Details(Optional id As Integer = 0) As ActionResult
            Dim customer As Customer = db.Customers.Find(id)
            If customer Is Nothing Then
                Return HttpNotFound()
            End If
            Return View(customer)
        End Function

        '
        ' GET: /Admin/Create

        Public Function Create() As ActionResult
            Return View()
        End Function

        '
        ' POST: /Admin/Create

        <HttpPost>
        <ValidateAntiForgeryToken>
        Public Function Create(customer As Customer) As ActionResult
            If ModelState.IsValid Then
                db.Customers.Add(customer)
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If

            Return View(customer)
        End Function

        '
        ' GET: /Admin/Edit/5

        Public Function Edit(Optional id As Integer = 0) As ActionResult
            Dim customer As Customer = db.Customers.Find(id)
            If customer Is Nothing Then
                Return HttpNotFound()
            End If
            Return View(customer)
        End Function

        '
        ' POST: /Admin/Edit/5

        <HttpPost>
        <ValidateAntiForgeryToken>
        Public Function Edit(customer As Customer) As ActionResult
            If ModelState.IsValid Then
                ' opzione 1: prendiamo il dato dal db e applichiamo le differenze
                Dim dbItem = db.Customers.First(Function(x) x.ID = customer.ID)
                TryUpdateModel(Of Customer)(dbItem)
                ' opzione 2: segniamo tutto come modificato
                'db.Entry(customer).State = EntityState.Modified;
                db.SaveChanges()
            End If
            Return View(customer)
        End Function

        '
        ' GET: /Admin/Delete/5

        Public Function Delete(Optional id As Integer = 0) As ActionResult
            Dim customer As Customer = db.Customers.Find(id)
            If customer Is Nothing Then
                Return HttpNotFound()
            End If
            Return View(customer)
        End Function

        '
        ' POST: /Admin/Delete/5

        <HttpPost, ActionName("Delete")>
        <ValidateAntiForgeryToken>
        Public Function DeleteConfirmed(id As Integer) As ActionResult
            Dim customer As Customer = db.Customers.Find(id)
            db.Customers.Remove(customer)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(disposing As Boolean)
            db.Dispose()
            MyBase.Dispose(disposing)
        End Sub

    End Class
End Namespace