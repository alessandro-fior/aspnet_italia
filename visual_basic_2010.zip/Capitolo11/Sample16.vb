﻿Imports System.Linq
Imports System.Xml.Linq
Imports <xmlns:p="http://schemas.aspitalia.com/book40/products">
Imports <xmlns:d="http://schemas.aspitalia.com/book40/details">


Public Class Sample16

    Public Shared Sub Run()

        Dim doc As XDocument =
                <?xml version="1.0"?>
                <p:products>
                    <p:product idProduct="4">
                        <!-- Nuovo prodotto -->
                        <p:description>Prodotto 4</p:description>
                    </p:product>
                </p:products>

        Console.WriteLine(doc)
    End Sub

End Class
