﻿using System.Web.UI;

namespace Chapter16.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}