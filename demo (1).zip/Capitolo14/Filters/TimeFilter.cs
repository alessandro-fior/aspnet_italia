﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Capitolo14.Filters
{
    public class TimeFilter : IActionFilter
    {
        public int Hour { get; }

        public TimeFilter(int hour)
        {
            Hour = hour;
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            bool anonymous = !context.HttpContext.User.Identity.IsAuthenticated;
            bool outOfTime = DateTime.Now.Hour < Hour;

            if (anonymous && outOfTime)
            {
                context.Result = new ViewResult { ViewName = "OutOfTime" };
            }
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
        }
    }
}