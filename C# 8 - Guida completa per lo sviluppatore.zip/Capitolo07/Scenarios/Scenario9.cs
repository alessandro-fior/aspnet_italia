﻿using System;
using System.Data.SqlClient;
using System.Security;

namespace Capitolo7.Scenarios
{
    public static class Scenario9
    {
        /// <summary>
        /// Esempio 7.15
        /// </summary>
        public static void Run()
        {
            try
            {
                ValidateCredentials("username", "Pa$$w0rd");
            }
            catch (SecurityException ex)
            {
                Console.WriteLine($"Generata eccezione di tipo SecurityException. InnerType di tipo: {ex.InnerException.GetType()}");
            }
        }

        public static bool ValidateCredentials(string username, string password)
        {
            try
            {
                
                SqlConnection conn = new SqlConnection(@"Data Source=.;Database=GUARANTEED_TO_FAIL;Connection Timeout=1");
                conn.Open();

                // codice per validare username e password su database
                // oscurato per generare volontariamente una eccezione

                return true;
            }
            catch (SqlException ex)
            {
                throw new SecurityException("Non è stato possibile validare le credenziali", ex);
            }
        }
    }
}