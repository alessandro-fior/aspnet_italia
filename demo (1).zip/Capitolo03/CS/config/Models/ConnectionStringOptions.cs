namespace ConfigSample.Models
{
    public class ConnectionStringOptions
    {
        public string Default { get; set; }
    }
}