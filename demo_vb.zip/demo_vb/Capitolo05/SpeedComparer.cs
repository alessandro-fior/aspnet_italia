﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPItalia.Books.Chapter05
{
    public class Vehicle
    {
        public int Speed { get; set; }
    }

    public class Car : Vehicle
    {
    }

    public class SpeedComparer : IComparer<Vehicle>
    {
        public int Compare(Vehicle x, Vehicle y)
        {
            return x.Speed - y.Speed;
        }
    }

}
