using System;

namespace BasicAuth.Models {
    public class User {
        public string Username { get; set; } 
        public string Password { get; set; }
        public string Role { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string FavoriteColor { get; set; }
    }
}