using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using CustomerAuthorization.Models;
using CustomerAuthorization.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CustomerAuthorization.Controllers
{
    [Authorize]
    public class CustomerController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        public CustomerController(UserManager<ApplicationUser> userManager)
        {
            this.userManager = userManager;
        }

        [Authorize(Roles = "Customer,Administrator")]
        public IActionResult Index()
        {
            //Reindirizziamo l'utente in base al ruolo
            if (User.HasClaim(claim => claim.Type == ClaimTypes.Role && claim.Value == "Administrator")) {
                //Se è un Administrator, visualizzerà tutti i customer
                return RedirectToAction(nameof(IndexAll));
            } else {
                //Altrimenti, se è un Customer, potrà visualizzare solo sé stesso
                return RedirectToAction(nameof(Detail), new { name = User.Identity.Name });
            }
        }

        [Authorize(Roles = "Administrator")]
        public async Task<IActionResult> IndexAll()
        {
            //Solo gli utenti con ruolo Administrator
            //potranno eseguire questa action
            var claim = new Claim(ClaimTypes.Role, "Customer");
            var customers = (await userManager.GetUsersForClaimAsync(claim))
            .Select(customer => new UserViewModel { Id = customer.Id, Name = customer.UserName })
            .ToList();
            return View(customers);
        }

        public async Task<IActionResult> Detail(string name,
          [FromServices] IAuthorizationService authService)
        {
            var result = await authService.AuthorizeAsync(User, name, "SelfOrAdministrator");
            if (result.Succeeded) {
                var user = await userManager.Users
                .Include(u => u.Orders)
                .FirstOrDefaultAsync(u => u.UserName == name);
                if (user == null) {
                    return RedirectToAction(nameof(Index));    
                }
                var userModel = new UserViewModel {
                    Id = user.Id,
                    Name = user.UserName,
                    Orders = user.Orders.Select(order => new OrderViewModel { 
                        Id = order.OrderId,
                        Amount = order.Amount,
                        CreatedAt = order.CreatedAt
                    }).ToList()
                };
                return View(userModel);
            } else {
                return RedirectToAction("AccessDenied", "Account");
            }
        }
    }
}