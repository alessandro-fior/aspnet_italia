﻿Partial Public Class OrderDetail
	Public Property OrderID As Integer
	Public Property ProductID As Integer
	Public Property UnitPrice As Decimal
	Public Property Quantity As Short
	Public Property Discount As Single
	Public Overridable Property Order As Order
End Class
