﻿Namespace ASPItalia.Books.Chapter07
    Public Class AnotherPerson

        <ReportProperty("Nome")>
        Public Property FirstName As String

        <ReportProperty("Cognome")>
        Public Property LastName As String

        <ReportProperty("Età")>
        Public Property Age As Integer

    End Class

End Namespace