﻿namespace Aspitalia.Books.Chapter4
{
    // Classe astratta che implementa un'interfaccia
    public abstract class Person : IWritable
    {
        // Campi privati
        private string _fullName; // Nome completo
        private int _age;         // Età

        // Proprietà
        public string FullName
        {
            get { return _fullName; }
            set { _fullName = value; }
        }

        // Proprietà
        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }

        // Costruttore di default
        public Person()
        {
            _fullName = string.Empty;
            _age = 18;
        }

        // Costruttore con parametri
        public Person(string name, int age)
        {
            _fullName = name;
            _age = age;
        }

        // Metodo virtuale
        public virtual string GetFirstName()
        {
            return this._fullName.Split(' ')[0];
        }

        // Metodo astratto (è il metodo definito nell'interfaccia)
        public abstract void Write();

        // Override del metodo ToString di Object
        public override string ToString()
        {
            return FullName;
        }
    }
}
