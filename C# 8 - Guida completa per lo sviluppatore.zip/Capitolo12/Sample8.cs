﻿using System.Xml;
using System.IO;
using System;

public class Sample8
{

    public static void Run()
    {
        // Impostazioni di scrittura
        var settings = new XmlWriterSettings
        {
            Indent = true,
            NewLineOnAttributes = true
        };

        string ns = "http://schemas.aspitalia.com/book40/products";

        var stringWriter = new StringWriter();

        using XmlWriter writer = XmlWriter.Create(stringWriter, settings);
        writer.WriteStartDocument();

        // Nuovo tag products
        writer.WriteStartElement("products", ns);
        writer.WriteComment("Nuovo prodotto");

        // Nuovo tag product con attributo
        writer.WriteStartElement("product", ns);
        writer.WriteAttributeString("idProduct", "4");

        // Noto testuale
        writer.WriteElementString("description", ns, "Prodotto 4");

        // Chiudo i tag
        writer.WriteEndElement();
        writer.WriteEndElement();

        writer.WriteEndDocument();

        Console.WriteLine(stringWriter);
    }

}
