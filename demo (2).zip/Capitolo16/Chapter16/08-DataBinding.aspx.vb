﻿Imports System.Web.ModelBinding
Imports Chapter16.Models

Partial Public Class _08_DataBinding
    Inherits System.Web.UI.Page
    Private db As New NorthwindContext()

    Public Function GetCustomers(<QueryString("n")> name As String) As IQueryable(Of Customer)
        Dim customers = db.Customers.AsQueryable()

        If Not [String].IsNullOrEmpty(name) Then
            customers = customers.Where(Function(f) f.CompanyName.Contains(name))
        End If

        Return customers
    End Function

    Public Sub UpdateCustomer(c As Customer)
        ' opzione 1: prendiamo il dato dal db e applichiamo le differenze
        Dim dbItem = db.Customers.First(Function(x) x.ID = c.ID)

        Page.TryUpdateModel(dbItem)
        ' opzione 2: segniamo tutto come modificato
        'db.Entry(c).State = EntityState.Modified;
        db.SaveChanges()
    End Sub

    Public Overrides Sub Dispose()
        If db IsNot Nothing Then
            db.Dispose()
        End If

        MyBase.Dispose()
    End Sub
End Class
