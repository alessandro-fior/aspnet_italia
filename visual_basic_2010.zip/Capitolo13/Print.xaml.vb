﻿Imports System.Windows.Xps
Imports System.Windows.Xps.Packaging
Imports System.IO
Imports System.Printing

Public Class Print

    Private Sub Print_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)

        ' Ottengo la stampante predefinita locale
        Using queue As PrintQueue = LocalPrintServer.GetDefaultPrintQueue()

            ' Ottengo il writer sulla stampante
            Dim writer As XpsDocumentWriter = PrintQueue.CreateXpsDocumentWriter(queue)

            Dim source As IDocumentPaginatorSource = DirectCast(Me.document, IDocumentPaginatorSource)
            writer.Write(source.DocumentPaginator)

        End Using
    End Sub

    Private Sub SaveXPS_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        ' Creo il file
        Using doc As New XpsDocument("test.xps", FileAccess.ReadWrite)

            Dim writer As XpsDocumentWriter = XpsDocument.CreateXpsDocumentWriter(doc)

            ' Scrivo il FlowDocument
            Dim source As IDocumentPaginatorSource = DirectCast(Me.document, IDocumentPaginatorSource)
            writer.Write(source.DocumentPaginator)

        End Using
    End Sub
End Class
