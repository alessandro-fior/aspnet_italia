﻿Imports System
Imports System.IO
Imports System.Text

Module Module1
    Sub Main()
        Try
            Dim myfileStream As FileStream
            Dim myPath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments), "myfile.txt")
            myfileStream = File.Create(myPath)
            Dim info As Byte() = New UTF8Encoding(True).GetBytes("Un saluto dall'autore di questo capitolo.")
            myfileStream.Write(info, 0, info.Length)
            myfileStream.Close()
            Dim mySteamiReader As StreamReader = File.OpenText(myPath)
            Do While mySteamiReader.Peek() >= 0
                Console.WriteLine("il file contiene: {0}", mySteamiReader.ReadLine())
            Loop
            mySteamiReader.Close()
        Catch ex As Exception
            Console.WriteLine("Si è verificato un errore: {0}", ex.ToString())
        End Try
        Console.ReadLine()
    End Sub
End Module
