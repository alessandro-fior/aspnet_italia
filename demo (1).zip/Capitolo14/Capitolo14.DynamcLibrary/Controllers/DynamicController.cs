﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Mvc;

namespace Capitolo14.DynamcLibrary.Controllers
{
    public class DynamicController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
