﻿using System.Xml;
using System.IO;
using System.Xml.Linq;
using System.Linq;
using System;

public class Sample11
{

    public static void Run()
    {
        // Caricamento del documento
        XDocument doc = XDocument.Load("test.xml");

        XNamespace productNs = "http://schemas.aspitalia.com/book40/products";
        XNamespace dns = "http://schemas.aspitalia.com/book40/details";

        // Tutti gli attributi idProduct degli elementi product 
        foreach (XAttribute attribute in doc.Root.Elements().Attributes("idProduct"))
        {
            Console.WriteLine("idProduct {0}", (string)attribute);
        }

        // Il primo nodo (commento)
        Console.WriteLine("Comment: {0}", doc.Root.Nodes().First());

        // Il primo elemento product
        XElement product = doc.Root.Elements(productNs + "product").ElementAt(1);
        Console.WriteLine("Description: {0}", (string)product.Element(productNs + "description"));

        // Somma dell'attributo value per tutti
        // i detail di tipo Weight
        int sum = (from d in doc.Root.Descendants(dns + "detail")
                   where d.Attribute("name").Value == "Weight"
                   select (int)d.Attribute("value")).Sum();
        Console.WriteLine("Total weight: {0}", sum);
    }
}