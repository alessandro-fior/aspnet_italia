﻿Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Data.Common
Imports System.IO
Imports System.Text

Module Module1

	Sub Main(args As String())
		'EnumerateProviders();
		'SelectDbProvider("SqlNorthwind");
		'SelectDbProvider("MdbNorthwind");
		'ExecuteReader();
		'ExecuteScalar();
		'ExecuteNonQuery();
		ExecuteDataset()
		Console.ReadLine()
	End Sub

	Private Sub ExecuteDataset()
		Dim ds As New DataSet()

		' Creazione della connessione
		Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("SqlNorthwind").ConnectionString)
			' Apertura della connessione
			conn.Open()

			' Creazione del comando
			Using selectCmd As New SqlCommand("SELECT * FROM Customers;SELECT * FROM Suppliers;", conn)
				' Creazione dell'adapter
				Using adapter As New SqlDataAdapter(selectCmd)
					' Popolamento dell'oggetto DataSet contenente due oggetti DataTable

					adapter.Fill(ds)
					' L'adapter viene chiuso automaticamente alla fine del blocco Using
				End Using
				' Il comando viene chiuso automaticamente alla fine del blocco Using
			End Using
		End Using
		' La connessione viene chiusa automaticamente alla fine del blocco Using
		' Il primo oggetto DataTable si riferisce ai clienti
		For Each item As DataRow In ds.Tables(0).Rows
			Console.WriteLine(item(0))
		Next

		' Il secondo oggetto DataTable si riferisce ai fornitori
		For Each item As DataRow In ds.Tables(1).Rows
			Console.WriteLine(item(0))
		Next
	End Sub

	Private Sub EnumerateProviders()
		Dim providers As DataTable = DbProviderFactories.GetFactoryClasses()
		For Each provider As DataRow In providers.Rows
			Console.WriteLine(provider(0))
		Next
	End Sub

	Private Sub SelectDbProvider(connStringName As String)
		Dim dt As New DataTable()

		' Nome invariante del managed data provider
		Dim providerInvariantName = ConfigurationManager.ConnectionStrings(connStringName).ProviderName

		' Stringa di connessione
		Dim connectionString = ConfigurationManager.ConnectionStrings(connStringName).ConnectionString

		' MS Access
		If connStringName.Equals("MdbNorthwind") Then
			connectionString = GetFullPathNameFromDBFileName(connectionString)
			connectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & Convert.ToString(connectionString)
		End If

		' Creazione dell'oggetto factory
		Dim factory As DbProviderFactory = DbProviderFactories.GetFactory(providerInvariantName)

		' Interrogazione del database
		Using conn As DbConnection = factory.CreateConnection()
			conn.ConnectionString = connectionString
			conn.Open()

			' Modalità disconnessa: popolamento di un oggetto DataTable
			Using adatpter As DbDataAdapter = factory.CreateDataAdapter()
				Dim selectCmd As DbCommand = factory.CreateCommand()
				selectCmd.CommandText = "SELECT * FROM Customers"
				selectCmd.Connection = conn
				adatpter.SelectCommand = selectCmd
				adatpter.Fill(dt)
				' L'adapter viene chiuso automaticamente alla fine del blocco Using
			End Using
		End Using
		' La connessione viene chiusa automaticamente alla fine del blocco Using
		Console.WriteLine(providerInvariantName)
		Console.WriteLine(connectionString)

		' Data binding della griglia di dati
		For Each item As DataRow In dt.Rows
			Console.WriteLine(Convert.ToString(item(0)) & "-" & Convert.ToString(item(1)))
		Next
	End Sub

	' Ricava il percorso assoluto dal percorso relativo del file MDB
	Private Function GetFullPathNameFromDBFileName(relativeFileName As String) As String
		relativeFileName = relativeFileName.Replace("/"c, "\"c)

		If relativeFileName.StartsWith("~\") Then
			relativeFileName = relativeFileName.Substring(2)
		ElseIf relativeFileName.StartsWith("\") Then
			relativeFileName = relativeFileName.Substring(1)
		End If

		Return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativeFileName)
	End Function

	Private Sub ExecuteReader()
		Dim builder As New StringBuilder()

		' Creazione della connessione
		Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("SqlNorthwind").ConnectionString)
			' Apertura della connessione
			conn.Open()

			' Creazione del comando
			Using cmd As New SqlCommand("SELECT CustomerID, CompanyName, ContactName, City FROM Customers", conn)
				' Ritorna un resultset
				Using reader As SqlDataReader = cmd.ExecuteReader()
					' Ciclo sul risultato della query
					While reader.Read()
						Console.WriteLine(String.Concat(reader.GetString(0), " - ", reader.GetString(1), " - ", reader.GetString(2), " - ", _
						 reader.GetString(3)))

					End While
					' Il data reader viene chiuso automaticamente alla fine del blocco Using
				End Using
				' Il comando viene chiuso automaticamente alla fine del blocco Using
			End Using
		End Using
		' La connessione viene chiusa automaticamente alla fine del blocco Using
	End Sub

	Private Sub ExecuteScalar()
		' Creazione della connessione
		Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("SqlNorthwind").ConnectionString)
			' Apertura della connessione
			conn.Open()

			' Creazione del comando
			Using cmd As New SqlCommand("SELECT COUNT(*) FROM Customers", conn)
				' Ritorna un valore intero
				Dim count As Integer = CInt(cmd.ExecuteScalar())


				Console.WriteLine(count.ToString())
				' Il comando viene chiuso automaticamente alla fine del blocco Using
			End Using
		End Using
		' La connessione viene chiusa automaticamente alla fine del blocco Using
	End Sub

	Private Sub ExecuteNonQuery()
		' Creazione della connessione
		Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("SqlNorthwind").ConnectionString)
			' Apertura della connessione
			conn.Open()

			' Creazione del comando
			Using cmd As New SqlCommand("UPDATE Customers SET City='Bergamo' WHERE CustomerID=@CustomerID", conn)
				' Aggiungi un parametro
				cmd.Parameters.AddWithValue("@CustomerID", "MAGAA")

				' Ritorna il numero di righe interessate dal comando di aggiornamento
				Dim rowsAffected As Integer = cmd.ExecuteNonQuery()


				Console.WriteLine(rowsAffected.ToString())
				' Il comando viene chiuso automaticamente alla fine del blocco Using
			End Using
		End Using
		' La connessione viene chiusa automaticamente alla fine del blocco Using
	End Sub

End Module
