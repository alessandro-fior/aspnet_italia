﻿Imports System.Dynamic

Namespace ASPItalia.Books.Chapter07

    Public Class MyDynamicObject
        Inherits DynamicObject

        Public Overrides Function TryGetMember(
          ByVal binder As GetMemberBinder,
          ByRef result As Object) As Boolean

            result = "Property " + binder.Name
            Return True
        End Function

        Public Overrides Function TryInvokeMember(
          ByVal binder As InvokeMemberBinder, ByVal args() As Object,
          ByRef result As Object) As Boolean

            result = "Method " + binder.Name
            Return True
        End Function
    End Class


End Namespace