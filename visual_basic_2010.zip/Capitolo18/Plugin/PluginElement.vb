﻿Imports System.IO
Imports System.Security
Imports System.Security.Permissions

<Assembly: AllowPartiallyTrustedCallers()> 
Public Class PluginElement
  Inherits MarshalByRefObject

  <SecurityCritical()>
  Public Sub DirectWriteFile(ByVal data As String, ByVal path As String)
    Dim dataStream As Stream = File.OpenWrite(path)
    Dim str As StreamWriter = New StreamWriter(dataStream)
    str.Write(data)
    str.Close()
    dataStream.Close()
  End Sub

  <SecuritySafeCritical()>
  Public Sub WriteFile(ByVal data As String, ByVal path As String)
    Dim p As New FileIOPermission(FileIOPermissionAccess.Write, New String() {path})
    p.Demand()

    DirectWriteFile(data, path)
  End Sub
End Class
