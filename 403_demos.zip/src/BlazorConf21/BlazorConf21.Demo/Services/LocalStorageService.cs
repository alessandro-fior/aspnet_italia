﻿using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorConf21.Demo.Services
{
    public class LocalStorageService
    {
        IJSRuntime _jsRuntime;

        public LocalStorageService(IJSRuntime jsRuntime)
        {
            _jsRuntime = jsRuntime;
        }

        public ValueTask<T> GetItem<T>(string key)
        {
            return _jsRuntime.InvokeAsync<T>("localStorage.getItem", key);
        }

        public ValueTask SetItem(string key, object value)
        {
            return _jsRuntime.InvokeVoidAsync("localStorage.setItem", key, value);
        }

        public ValueTask<int> CountItems()
        {
            return _jsRuntime.InvokeAsync<int>("eval", "localStorage.length");
        }
    }
}
