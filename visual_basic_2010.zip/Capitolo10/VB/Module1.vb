﻿Module Module1

	Sub Main()
		FindCustomersByCountry()
		'FindCustomersById()
		'ProjectCustomers()
		'CreateOrder()
		'CreateCustomer()
		'FindCustomerById()
		'UpdateCustomerDisconnected()
		'DeleteCustomer()
		'DeleteCustomerDisconnected()
		'InvokeStoredProcedure()
		Console.ReadLine()
	End Sub

	Private Sub FindCustomersByCountry()
		Using ctx As New NorthwindEntities()
			Dim customers = From c In ctx.Customers
						Where c.Address.Country = "Italy"
						Select c
			For Each c In customers
				Console.WriteLine((c.CustomerID & " - ") + c.CompanyName)
			Next
		End Using
	End Sub

	Private Sub FindCustomersById()
		Using ctx As New NorthwindEntities()
			Dim customer = ctx.Customers.First(Function(c) c.CustomerID = "ALFKI")

			Console.WriteLine((customer.CustomerID & " - ") + customer.CompanyName)
		End Using
	End Sub

	Private Sub ProjectCustomers()
		Using ctx As New NorthwindEntities()
			Dim customers = ctx.Customers.Select(Function(c) New With {c.CustomerID, c.CompanyName})

			For Each c In customers
				Console.WriteLine((c.CustomerID & " - ") + c.CompanyName)
			Next
		End Using
	End Sub

	Private Sub CreateOrder()
		Using ctx As New NorthwindEntities()
			Dim o = New Order()

			o.Order_Details.Add(New Order_Detail())
			o.Order_Details.Add(New Order_Detail())
			o.Order_Details.Add(New Order_Detail())
			ctx.Orders.AddObject(o)
			ctx.SaveChanges()

			Console.WriteLine("OrderCreated")
		End Using
	End Sub

	Private Sub CreateCustomer()
		Using ctx As New NorthwindEntities()
			Dim c = New Customer()

			ctx.Customers.AddObject(c)
			ctx.SaveChanges()
			Console.WriteLine("CustomerCreated")
		End Using
	End Sub

	Private Sub UpdateCustomer()
		Using ctx As New NorthwindEntities()
			Dim cust = ctx.Customers.First(Function(c) c.CustomerID = "STEMO")
			cust.Address.Address = "Piazza del popolo 1"
			ctx.SaveChanges()
			Console.WriteLine("Customer Updated")
		End Using
	End Sub

	Private Sub UpdateCustomerDisconnected()
		Dim Cust As Customer = Nothing
		Using ctx As New NorthwindEntities()
			Cust = ctx.Customers.First(Function(c) c.CustomerID = "STEMO")
		End Using

		Cust.Address.Address = "Piazza Venezia 10"
		Using ctx As New NorthwindEntities()
			ctx.Customers.Attach(Cust)
			ctx.ObjectStateManager.ChangeObjectState(Cust, EntityState.Modified)
			ctx.SaveChanges()
		End Using
		Console.WriteLine("Customer updated")
	End Sub

	Private Sub DeleteCustomer()
		Using ctx As New NorthwindEntities()
			Dim Cust = ctx.Customers.First(Function(c) c.CustomerID = "STEMO")
			ctx.Customers.DeleteObject(Cust)
		End Using
		Console.WriteLine("Customer deleted")
	End Sub

	Private Sub DeleteCustomerDisconnected()
		Dim Cust As Customer = Nothing
		Using ctx As New NorthwindEntities()
			Cust = ctx.Customers.First(Function(c) c.CustomerID = "STEMO")
		End Using

		Using ctx As New NorthwindEntities()
			ctx.Customers.Attach(Cust)
			ctx.Customers.DeleteObject(Cust)
		End Using
		Console.WriteLine("Customer Deleted")
	End Sub

	Private Sub InvokeStoredProcedure()
		Using ctx As New NorthwindEntities()
			Dim result = ctx.Sales_by_Year(New DateTime(1996, 1, 1), New DateTime(1996, 12, 31))
			For Each r In result
				Console.WriteLine(((r.OrderID & " - ") + r.ShippedDate & " - ") + r.Year)
			Next
		End Using
	End Sub
End Module
