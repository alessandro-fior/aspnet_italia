﻿using Chapter16.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Chapter16
{
    public partial class Readme : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (var entities = new NorthwindContext())
            {
                if (entities.Customers.Count() == 0)
                {
                    entities.Customers.Add(new Customer { CompanyName = "Daniele Bochicchio" });
                    entities.Customers.Add(new Customer { CompanyName = "Cristian Civera" });
                    entities.Customers.Add(new Customer { CompanyName = "Marco De Sanctis" });
                    entities.Customers.Add(new Customer { CompanyName = "Alessio Leoncini" });
                    entities.Customers.Add(new Customer { CompanyName = "Marco Leoncini" });
                    entities.Customers.Add(new Customer { CompanyName = "Stefano Mostarda" });
                    entities.SaveChanges();
                }
            }
        }
    }
}