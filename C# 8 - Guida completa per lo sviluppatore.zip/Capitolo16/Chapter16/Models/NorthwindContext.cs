﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Chapter16.Models
{
    public class NorthwindContext : DbContext
    {
        public NorthwindContext() : base("NorthwindContext")
        {

        }
        public DbSet<Customer> Customers { get; set; }
    }
}