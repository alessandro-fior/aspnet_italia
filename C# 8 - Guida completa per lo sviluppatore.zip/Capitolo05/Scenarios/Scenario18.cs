﻿using System;
using System.Buffers;
using System.IO;
using System.Text;

namespace Capitolo5.Scenarios
{
    public static class Scenario18
    {
        /// <summary>
        /// Esempio 5.27, 5.28, 5.29
        /// </summary>
        public static void Run()
        {
            string fullName = "Matteo Tumiati";
            Console.WriteLine($"Il cognome è: {GetLastName(fullName)}");
            Console.WriteLine($"Il cognome è: {GetLastNameWithSpan(fullName).ToString()}");

            GetNames();
        }

        private static string GetLastName(string fullName)
        {
            var lastSpaceIndex = fullName.LastIndexOf(" ");
            return lastSpaceIndex == -1
            ? string.Empty
            : fullName.Substring(lastSpaceIndex + 1);
        }

        private static ReadOnlySpan<char> GetLastNameWithSpan(ReadOnlySpan<char> fullName)
        {
            var lastSpaceIndex = fullName.LastIndexOf(' ');

            return lastSpaceIndex == -1
                ? ReadOnlySpan<char>.Empty
                : fullName.Slice(lastSpaceIndex + 1);
        }

        private static void GetNames()
        {
            // creazione di un buffer di lettura
            byte[] buffer = ArrayPool<byte>.Shared.Rent(16000 * 8);
            int bytesRead;

            // apertura del file
            var stream = new FileStream(@"people.txt", FileMode.Open, FileAccess.Read);

            // lettura all'interno del buffer
            while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
            {
                // creazione dell'oggetto Memory<T>
                var memory = new ReadOnlyMemory<byte>(buffer, 0, length: bytesRead);

                // lettura come Span<T>
                ReadOnlySpan<byte> slice = memory.Span;

                // conversione e stampa su console...
                var content = Encoding.UTF8.GetString(slice);
                Console.WriteLine(content);
            }
        }
    }
}