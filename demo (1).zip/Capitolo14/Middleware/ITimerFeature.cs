﻿using System.Diagnostics;

namespace Capitolo14.Middleware
{
    public interface ITimerFeature
    {
        Stopwatch Stopwatch { get; }
    }
}
