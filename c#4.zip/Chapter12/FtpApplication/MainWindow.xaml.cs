﻿using System.IO;
using System.Net;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace FtpApplication
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }
    private void Button2_Click(object sender, RoutedEventArgs e)
    {
      OpenFileDialog fileDialog = new OpenFileDialog
      {
        Filter = "immagini (*.jpg)|*.jpg"
      };
      bool? show = fileDialog.ShowDialog();
      if (show.HasValue & show.Value)
      {
        using (Stream fileStream = fileDialog.OpenFile())
        {
          this.TextBlock1.Text = fileDialog.SafeFileName;
          this.TextBlock1.Tag = fileDialog.FileName;
          MemoryStream dataStream = new MemoryStream();
          byte[] dataByte = new byte[1024];
          int i = 0;
          do
          {
            i = fileStream.Read(dataByte, 0, 1024);
            if (i > 0)
            {
              dataStream.Write(dataByte, 0, i);
            }
          }
          while (i > 0);
          dataStream.Seek(0L, SeekOrigin.Begin);
          BitmapImage bmpImage = new BitmapImage();
          bmpImage.BeginInit();
          bmpImage.StreamSource = dataStream;
          bmpImage.EndInit();
          this.Image1.Source = bmpImage;
        }
      }
    }

    private void Button1_Click(object sender, RoutedEventArgs e)
    {
      using (Stream fileStream = File.OpenRead(this.TextBlock1.Tag.ToString()))
      {
        FtpWebRequest request = (FtpWebRequest)WebRequest.Create(string.Format("ftp://xxx.xxx.xxx.xxx/{0}", this.TextBlock1.Text));
        request.Method = WebRequestMethods.Ftp.UploadFile;
        request.Credentials = new NetworkCredential("username", "password");
        Stream requestStream = request.GetRequestStream();
        byte[] sendBuffer = new byte[1024];
        int bytesRead = 0;
        do
        {
          bytesRead = fileStream.Read(sendBuffer, 0, 1024);
          if (bytesRead > 0)
          {
            requestStream.Write(sendBuffer, 0, bytesRead);
          }
        }
        while (bytesRead > 0);
        requestStream.Close();

        this.TextBlock1.Text = ((FtpWebResponse)request.GetResponse()).StatusDescription;
      }
    }


  }
}
