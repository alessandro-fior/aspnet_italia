﻿Namespace ASPItalia.Books.Chapter13

    Class MainWindow


        Private Sub Resources_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
            Dim r As New Resources
            r.ShowDialog()
        End Sub

        Private Sub Styles_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
            Dim s As New Styles
            s.ShowDialog()
        End Sub


        Private Sub Templates_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
            Dim t As New Templates
            t.ShowDialog()
        End Sub

        Private Sub Bindings_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
            Dim b As New Bindings
            b.ShowDialog()
        End Sub

        Private Sub Bindings2_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
            Dim b As New Bindings2()
            b.ShowDialog()
        End Sub

        Private Sub Events_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
            Dim ev As New Events
            ev.ShowDialog()
        End Sub

        Private Sub Print_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
            Dim p As New Print
            p.ShowDialog()
        End Sub
    End Class

End Namespace