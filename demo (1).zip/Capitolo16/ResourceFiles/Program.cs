﻿using System.Collections;
using System.IO;
using System.Resources;
using System.Globalization;
using System.Collections.Generic;
using static System.Console;

namespace ResourceFiles
{
    class Program
    {
        // NOTE: la lingua inglese non è presente con un file di risorse dedicato
        // pertanto il ResourceManager farà il fallback sul file Resources.resx, 
        // mentre per l'italiano recupererà il valore dal file Resources.it-IT.resx


        static void Main(string[] args)
        {
            // preparo una lista di culture
            var cultures = new List<CultureInfo>
            {
                new CultureInfo("it-IT"), // lingua italiana parlata in Italia
                new CultureInfo("en-US")  // lingua inglese parlata in America
            };

            // creo un oggetto di tipo ResourceManager per leggere le chiavi
            ResourceManager rm = new ResourceManager(typeof(Resources));

            foreach (var culture in cultures)
            {
                // imposto la cultura corrente
                CultureInfo.CurrentCulture = culture;
                CultureInfo.CurrentUICulture = culture;

                // mostro sulla console alcune informazioni relative alla cultura corrente
                // e i valori corrispondenti alle chiavi recuperate
                WriteLine($"CurrentUICulture: {CultureInfo.CurrentUICulture}");
                WriteLine($"Risorsa con proprietà \"title\": {Resources.title}");
                WriteLine($"Risorsa con proprietà \"description\": {Resources.description}");

                // mostro gli stessi valori, ma tramite RM
                WriteLine($"Risorsa con proprietà \"title\": {rm.GetString("title")}");
                WriteLine($"Risorsa con proprietà \"description\": {rm.GetString("description")}");

                WriteLine("*******************");
            }

            // recupero il percorso dove il file di risorse verrà creato/letto
            var path = Path.Combine(Directory.GetCurrentDirectory(), "runtime-resource.resx");

            // scrivo il file di risorse
            WriteResourceFile(path);

            // leggo il file di risorse
            ReadResourceFile(path);

            ReadKey();
        }

        static void WriteResourceFile(string path)
        {
            // apro lo stream in scrittura sul file
            using (FileStream fs = File.OpenWrite(path))
            {
                // creo un nuovo oggetto di tipo ResourceWriter
                using (ResourceWriter rw = new ResourceWriter(fs))
                {
                    // aggiungo le risorse necessarie
                    rw.AddResource("Title", "Titolo della risorsa generata a runtime");
                    rw.AddResource("Description", "Descrizione della risorsa generata a runtime");

                    // genero il file di risorse
                    rw.Generate();                    
                }                
            }
        }

        static void ReadResourceFile(string path)
        {
            // apro lo stream in lettura sul file
            using (FileStream fs = File.OpenRead(path))
            {
                // creo un nuovo oggetto di tipo ResourceReader
                using (ResourceReader rr = new ResourceReader(fs))
                {
                    // recupero l'elenco delle chiavi e valori all'interno di un dizionario
                    IDictionaryEnumerator enumerator = rr.GetEnumerator();

                    // scorro tutte le chiavi ed i valori del dizionario
                    // per mostrarne i valori a schermo
                    while (enumerator.MoveNext())
                        WriteLine($"{enumerator.Key} : {enumerator.Value}");
                }
            }
        }
    }
}