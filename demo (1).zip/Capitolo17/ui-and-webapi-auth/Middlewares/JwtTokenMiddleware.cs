using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using UiAndApiAuth.Services;

namespace UiAndApiAuth.Middlewares
{
    public class JwtTokenMiddleware {
        private readonly IJwtTokenProvider tokenProvider;
        private readonly RequestDelegate next;
        public JwtTokenMiddleware(IJwtTokenProvider tokenProvider, RequestDelegate next)
        {
            this.tokenProvider = tokenProvider;
            this.next = next;
        }
        public async Task Invoke(HttpContext context) {
            //Nel momento in cui un altro middleware produce la risposta
            //emettiamo il token come intestazione
            context.Response.OnStarting(() => {
                var identity = context.User.Identity as ClaimsIdentity;
                if (identity.IsAuthenticated && identity.AuthenticationType != CookieAuthenticationDefaults.AuthenticationScheme) {
                    //Invia un nuovo token come intestazione della risposta
                    //Il client potrà leggerlo e usarlo per la prossima richiesta
                    context.Response.Headers.Add("X-Token", tokenProvider.CreateToken(identity));
                }
                return Task.CompletedTask;
            });
            await next.Invoke(context);
        }
    }
}
