﻿Imports System.Net.Sockets
Imports System.Text

Class MainWindow


    Private Async Sub Button_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Dim client = New UdpClient()
        client.Connect("localhost", 8080)
        Dim sendByte As Byte() = Encoding.ASCII.GetBytes(txb1.Text)
        Await client.SendAsync(sendByte, sendByte.Length)
    End Sub

    Private Async Function ReiceveDataAsync() As Task
        Dim server = New UdpClient(8080)

        While True
            Dim result = Await server.ReceiveAsync()
            Dim reiceveByte = result.Buffer
            Dim reiceveString = Encoding.ASCII.GetString(reiceveByte)
            txb2.Text += String.Format(" {0}", reiceveString)
        End While
    End Function

    Private Sub Window_Loaded(sender As Object, e As RoutedEventArgs)
        ReiceveDataAsync()
    End Sub
End Class
