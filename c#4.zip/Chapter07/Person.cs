﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPItalia.Books.Chapter07
{
    public class Person
    {
        [ReportProperty("Nome")]
        public string FirstName { get; set; }

        [ReportProperty("Cognome")]
        public string LastName { get; set; }

        [ReportProperty("Età")]
        public int Age { get; set; }
    }
}
