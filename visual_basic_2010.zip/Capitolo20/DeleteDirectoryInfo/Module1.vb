﻿Imports System
Imports System.IO

Module Module1
    Sub Main()
        Dim dInfo As DirectoryInfo = New DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments), "Capitolo20"))
        Try
            dInfo.Create()
            Console.WriteLine("Cartella creata correttamente, premi un tasto per eliminarla")
            Console.ReadLine()
            dInfo.Delete()
            Console.WriteLine("Cartella Eliminata correttamente")
        Catch ex As Exception
            Console.WriteLine("Si è verificato un errore: {0}", ex.ToString())
        End Try
        Console.ReadLine()
    End Sub
End Module
