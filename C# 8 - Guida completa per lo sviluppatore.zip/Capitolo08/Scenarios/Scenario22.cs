﻿using System.Threading;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario22
    {
        /// <summary>
        /// Esempio 8.27
        /// </summary>
        public static void Run()
        {
            Task.Run(() => SomeMethod());
        }

        public static string SomeMethod()
        {
            // codice qui...
            Thread.Sleep(3000);
            return "test";
        }
    }
}