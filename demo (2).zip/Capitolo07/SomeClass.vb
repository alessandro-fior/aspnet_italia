﻿Imports System.Reflection
Imports System.Xml.Serialization
Imports System.Runtime.InteropServices
Imports System.Web.Services

' A livello di assembly
<Assembly: AssemblyVersion("1.0.0.0")> 

Namespace ASPItalia.Books.Chapter07

    ' A livello di classe
    <Serializable()>
    Public Class SomeClass

        ' A livello di proprietà
        <XmlIgnore()>
        Public Property MyProperty As String

        ' A livello di field
        <NonSerialized()>
        Private myField As String

        ' A livello di argomento di un metodo
        Public Sub SomeMethod(
          <MarshalAs(UnmanagedType.LPWStr)> ByVal value As String)
            ' ...
        End Sub

        <WebMethod(BufferResponse:=True)>
        Public Sub SomeMethod()
            ' ...
        End Sub

        Sub SomeProblematicMethod()
            Throw New NotImplementedException
        End Sub

    End Class

End Namespace
