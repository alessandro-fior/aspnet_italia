﻿Imports System.Net
Imports System.IO
Imports System.Text
Imports Microsoft.Win32

Class MainWindow
  Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button2.Click
    Dim fileDialog As New OpenFileDialog()
    fileDialog.Filter = "immagini (*.jpg)|*.jpg"
    Dim show As Boolean? = fileDialog.ShowDialog()
    If show IsNot Nothing And show.Value = True Then
      Using fileStream As Stream = fileDialog.OpenFile()
        TextBlock1.Text = fileDialog.SafeFileName
        TextBlock1.Tag = fileDialog.FileName

        Dim dataStream As MemoryStream = New MemoryStream()
        Dim dataByte As Byte() = New Byte(1023) {}
        Dim i As Integer = 0

        Do
          i = fileStream.Read(dataByte, 0, 1024)
          If i > 0 Then
            dataStream.Write(dataByte, 0, i)
          End If
        Loop While i > 0

        dataStream.Seek(0, SeekOrigin.Begin)

        Dim bmpImage As BitmapImage = New BitmapImage()
        bmpImage.BeginInit()
        bmpImage.StreamSource = dataStream
        bmpImage.EndInit()
        Image1.Source = bmpImage
      End Using
    End If
  End Sub

  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button1.Click
    Using fileStream As Stream = File.OpenRead(TextBlock1.Tag.ToString())
      Dim uploadUri As String = _
        String.Format("ftp://xxx.xxx.xxx.xxx/{0}", _
                      TextBlock1.Text)

      Dim request As FtpWebRequest = _
      CType(WebRequest.Create(uploadUri), FtpWebRequest)
      request.Method = WebRequestMethods.Ftp.UploadFile
      request.Credentials = _
        New NetworkCredential("username", "password")

      Dim requestStream As Stream = request.GetRequestStream()

      Dim sendBuffer(1023) As Byte
      Dim bytesRead As Integer = 0

      Do
        bytesRead = fileStream.Read(sendBuffer, 0, 1024)
        If bytesRead > 0 Then
          requestStream.Write(sendBuffer, 0, bytesRead)
        End If
      Loop While bytesRead > 0

      requestStream.Close()

      Dim response As FtpWebResponse = _
        CType(request.GetResponse(), FtpWebResponse)

      TextBlock1.Text = response.StatusDescription
    End Using
  End Sub
End Class

