﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPItalia.Books.Chapter05
{
    public class ListNode<T>
    {
        public T Value { get; set; }
        public ListNode<T> NextNode { get; set; }
    }
}
