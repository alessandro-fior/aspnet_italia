using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CustomerAuthorization.Models.ViewModels
{
    public class CustomReportViewModel
    {
        public int Year { get; set; }
        public decimal Amount { get; set; }
    }
}