﻿using System;
using System.Collections.Generic;
using AutoMapper;
using DemoWebAPI.Models;
using DemoWebAPI.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;

namespace DemoWebAPI.Controllers
{
    [Route("api/customers")]
    public class CustomersController : Controller
    {
        private readonly ICustomerRepository customerRepository;
        private readonly IUrlHelper urlHelper;

        /// <summary>
        /// Crea una nuova istanza della classe <see cref="DemoWebAPI.Controllers.CustomersController" />
        /// </summary>
        /// <param name="customerRepository">Il repository per recuperare i clienti</param>
        /// <param name="urlHelper">Helper per ricostruire gli url</param>
        public CustomersController(ICustomerRepository customerRepository, IUrlHelper urlHelper)
        {
            this.customerRepository = customerRepository;
            this.urlHelper = urlHelper;
        }

        /// <summary>
        /// Recupera l'elenco dei clienti
        /// </summary>
        /// <returns>L'elenco dei clienti</returns>
        [HttpGet]
        [HttpHead]
        public IActionResult GetCustomers()
        {
            var customers = customerRepository.GetCustomers();            
            var customersForRead = Mapper.Map<IEnumerable<CustomerForRead>>(customers);

            return Ok(customersForRead);
        }

        /// <summary>
        /// Recupera un cliente
        /// </summary>
        /// <param name="id">L'identificativo di un cliente</param>
        /// <returns>Un cliente selezionato tramite il suo identificativo</returns>
        [HttpGet("{id}", Name = "GetCustomer")]
        public IActionResult GetCustomer(Guid id)
        {
            var customer = customerRepository.GetCustomer(id);

            if (customer == null)
                return NotFound();

            var customerForRead = Mapper.Map<CustomerForRead>(customer);

            return StatusCode(StatusCodes.Status200OK, customerForRead);
        }

        /// <summary>
        /// Recupera un cliente
        /// </summary>
        /// <param name="id">L'identificativo di un cliente</param>
        /// <returns>Il cliente selezionato tramite il suo identificativo</returns> 
        [HttpGet("/api/getcustomerwithlinks/{id}")]
        public IActionResult GetCustomerV2(Guid id)
        {
            var customer = customerRepository.GetCustomer(id);

            if (customer == null)
                return NotFound();

            var customerForRead = Mapper.Map<CustomerForReadV2>(customer);

            return StatusCode(StatusCodes.Status200OK, AddLinks(customerForRead));
        }

        /// <summary>
        /// Aggiunge i link per la discoverability
        /// </summary>
        /// <param name="customer">Il cliente</param>
        /// <returns>Il cliente selezionato con i link</returns>
        private CustomerForReadV2 AddLinks(CustomerForReadV2 customer)
        {
            customer.Links.Add(new Link(urlHelper.Link("GetCustomer", new { id = customer.Id }), "self", "GET"));
            customer.Links.Add(new Link(urlHelper.Link("CreateCustomer", null), "self", "POST"));
            customer.Links.Add(new Link(urlHelper.Link("UpdateCustomer", new { id = customer.Id }), "update_customer", "PUT"));
            customer.Links.Add(new Link(urlHelper.Link("PartialUpdateCustomer", new { id = customer.Id }), "partial_update_customer", "PATCH"));

            return customer;
        }

        /// <summary>
        /// Crea un nuovo cliente
        /// </summary>
        /// <param name="customer">Il cliente da creare</param>
        /// <returns>Il cliente creato</returns>
        [HttpPost(Name = "CreateCustomer")]
        public IActionResult CreateCustomer([FromBody] CustomerForCreate customer)
        {
            if (customer == null || !ModelState.IsValid)
                return BadRequest();

            var mappedCustomer = Mapper.Map<Customer>(customer);
            customerRepository.AddCustomer(mappedCustomer);

            if (!customerRepository.SaveChanges())
                return StatusCode(StatusCodes.Status500InternalServerError, "Impossibile salvare le modifiche.");

            var createdCustomer = Mapper.Map<CustomerForRead>(mappedCustomer);

            return CreatedAtAction(nameof(GetCustomer), new { id = createdCustomer.Id }, createdCustomer);
        }

        /// <summary>
        /// Aggiorna il cliente
        /// </summary>
        /// <param name="id">L'identificativo del cliente</param>
        /// <param name="customer">Il cliente</param>
        /// <returns>N/A</returns>
        [HttpPut("{id}", Name = "UpdateCustomer")]
        public IActionResult UpdateCustomer(Guid id, [FromBody] CustomerForUpdate customer)
        {
            if (customer == null)
                return BadRequest();

            var mappedCustomer = Mapper.Map<Customer>(customer);
            mappedCustomer.Id = id;
            customerRepository.UpdateCustomer(mappedCustomer);

            if (!customerRepository.SaveChanges())
                return StatusCode(StatusCodes.Status500InternalServerError, "Impossibile salvare le modifiche");

            return NoContent();
        }

        /// <summary>
        /// Aggiornamento parziale di un cliente
        /// </summary>
        /// <param name="id">L'identificativo del cliente</param>
        /// <param name="patchDocument">L'elenco delle operazioni da effettuare sul cliente</param>
        /// <returns>N/A</returns>
        [HttpPatch("{id}", Name = "PartialUpdateCustomer")]
        public IActionResult PartialUpdateCustomer(Guid id, [FromBody] JsonPatchDocument<CustomerForUpdate> patchDocument)
        {
            if (patchDocument == null)
                return BadRequest();

            var customer = customerRepository.GetCustomer(id);
            var mappedCustomer = Mapper.Map<CustomerForUpdate>(customer);
            patchDocument.ApplyTo(mappedCustomer);

            customer = Mapper.Map<Customer>(mappedCustomer);
            customer.Id = id;
            customerRepository.UpdateCustomer(customer);

            if (!customerRepository.SaveChanges())
                return StatusCode(StatusCodes.Status500InternalServerError, "Impossibile salvare le modifiche");

            return NoContent();
        }

        /// <summary>
        /// Elimina un cliente
        /// </summary>
        /// <param name="id">Identificativo di un cliente</param>
        /// <returns>N/A</returns>
        [HttpDelete("{id}")]
        public IActionResult DeleteCustomer(Guid id)
        {
            if (!customerRepository.CustomerExists(id))
                return StatusCode(StatusCodes.Status404NotFound);

            customerRepository.DeleteCustomer(id);
            
            return StatusCode(StatusCodes.Status204NoContent);
        }

        /// <summary>
        /// Recupera l'elenco dei metodi abilitati sulla route corrente
        /// </summary>
        /// <returns>N/A</returns>
        [HttpOptions]
        public IActionResult GetCustomersOptions()
        {
            Response.Headers.Add("Allow", "GET,POST,OPTIONS");
            return Ok();
        }
    }
}