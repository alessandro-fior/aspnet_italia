﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.IO;

namespace WebClient1
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private async void Button1_Click(object sender, RoutedEventArgs e)
    {
      var client = new WebClient();
      var dataStream = await client.OpenReadTaskAsync(new UriBuilder("http", "localhost", 1503, TextBox1.Text).Uri);
      var reader = new StreamReader(dataStream);
      var data = await reader.ReadToEndAsync();
      TextBox2.Text = data;
    }

    private async void Button2_Click(object sender, RoutedEventArgs e)
    {
      var client = new WebClient();
      var dataStream = await client.OpenWriteTaskAsync(String.Format(@"C:\{0}", TextBox1.Text));
      var str = new StreamWriter(dataStream);
      await str.WriteAsync(TextBox2.Text);
      str.Close();
      dataStream.Close();
    }
  }
}
