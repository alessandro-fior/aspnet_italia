using System;

namespace CustomerAuthorization.Models.Entities
{
    public class Order {
        public int OrderId { get; set;}
        public decimal Amount { get; set; }
        public DateTime CreatedAt { get; set; }
        public string CustomerId { get; set; }
        public ApplicationUser Customer { get; set; }
    }
}