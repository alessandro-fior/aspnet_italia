﻿using System;

namespace Capitolo7.Scenarios
{
    public static class Scenario6
    {
        /// <summary>
        /// Esempio 7.8, 7.9, 7.10, 7.11
        /// </summary>
        public static void Run()
        {
            var myObject = new DisposableObject();

            try
            {
                myObject.SomeMethod();
            }
            finally
            {
                myObject.Dispose();
            }

            // sintassi alternativa #1
            //using (var myObject = new DisposableObject())
            //{
            //    myObject.SomeMethod();
            //}

            // sintassi alternativa #2
            // in questo caso, però, il metodo Dispose verrà invocato
            // solo alla chiusura del metodo Run
            //using var myObject = new DisposableObject();
            //myObject.SomeMethod();
        }

        public class DisposableObject : IDisposable
        {
            public void SomeMethod()
            {
                // qualche logica...
            }

            protected virtual void Dispose(bool disposing)
            {
                if (disposing)
                {
                    // qui si liberano le risorse gestite
                }

                // qui si liberano le risorse non gestite
            }

            public void Dispose()
            {
                this.Dispose(true);
                GC.SuppressFinalize(this);
            }

            ~DisposableObject()
            {
                this.Dispose(false);
            }
        }
    }
}