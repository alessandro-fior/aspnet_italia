﻿using System.ComponentModel.DataAnnotations;
using ViewsLocalization.Resources.Validation;

namespace ViewsLocalization.Models.Home
{
    public class ContactModel
    {
        [Required(ErrorMessageResourceName = "RequiredError", ErrorMessageResourceType = typeof(ErrorMessages))]
        [MaxLength(50, ErrorMessageResourceName = "MaxLengthError", ErrorMessageResourceType = typeof(ErrorMessages))]
        [Display(Name = "Name", ResourceType = typeof(ErrorMessages))]
        public string Name { get; set; }

        [Required(ErrorMessageResourceName = "RequiredError", ErrorMessageResourceType = typeof(ErrorMessages))]
        [MaxLength(500)]
        [Display(Name = "Comment", ResourceType = typeof(ErrorMessages))]
        public string Comment { get; set; }        
    }
}
