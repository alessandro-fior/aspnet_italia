﻿using System;
using System.Threading;

namespace Capitolo8.Scenarios
{
    public static class Scenario10
    {
        /// <summary>
        /// Esempio 8.10
        /// </summary>
        public static void Run()
        {
            var method = new SomeDelegate((parameter) =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Ciao da {0}", parameter);
                return parameter.Length;
            });

            IAsyncResult asyncResult = method.BeginInvoke("Matteo Tumiati", null, null);
            Console.WriteLine("Esecuzione avviata");

            // Attesa del termine dell'operazione e recupero risultato
            int result = method.EndInvoke(asyncResult);            
            Console.WriteLine("Il risultato è {0}", result);
        }

        public delegate int SomeDelegate(string parameter);
    }
}