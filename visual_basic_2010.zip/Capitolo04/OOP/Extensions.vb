﻿Imports System.Runtime.CompilerServices

Namespace Aspitalia.Books.Chapter4

    Public Module Extensions
        <Extension()>
        Public Function IsNull(ByVal value As String) As Boolean
            Return value Is Nothing
        End Function
    End Module

End Namespace
