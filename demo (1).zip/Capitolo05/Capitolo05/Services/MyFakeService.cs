﻿using Capitolo05.Models;
using System.Collections.Generic;

namespace Capitolo05.Services
{
    public class MyFakeService : IMyService
    {
        public IEnumerable<Person> GetPeople()
        {
            for (int i = 0; i < 10; i++)
            {
                yield return new Person
                {
                    ID = i + 1,
                    FirstName = "Daniele",
                    LastName = "Bochicchio " + i,
                };
            }
        }
    }
}
