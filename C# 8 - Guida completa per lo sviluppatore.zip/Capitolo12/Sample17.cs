﻿using System.Linq;
using System.Xml.XPath;
using System.Xml;
using System;
using System.IO;

public class Sample17
{

    public static void Run()
    {

        // Carico il documento
        var doc = new XmlDocument();
        doc.Load(Path.Combine(Environment.CurrentDirectory, "test.xml"));

        // Creo il gestore dei namespace
        var nsManager = new XmlNamespaceManager(doc.NameTable);
        // Associo il prefisso al namespace
        nsManager.AddNamespace("p", "http://schemas.aspitalia.com/book40/products");

        // Creo il navigatore sui XmlNode
        XPathNavigator navigator = doc.CreateNavigator();

        // Ricerco l'attributo
        navigator = navigator.SelectSingleNode("/p:products/p:product[1]/@idCategory", nsManager);
        navigator.SetValue("5");

        Console.WriteLine(navigator.ValueAsInt);
    }

}
