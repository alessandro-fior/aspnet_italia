﻿
Public Class Resources

    Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        Me.Resources("RedBrush") = New SolidColorBrush(Colors.Yellow)
    End Sub

End Class
