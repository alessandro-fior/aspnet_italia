# Autorizzazione degli utenti
Questa applicazione dimostrativa usa ASP.NET Core Identity e ASP.NET Core MVC per autenticare e autorizzare i suoi utenti. I dati sono memorizzati nel db Sqlite `app.db`.

All'avvio dell'applicazione si dovrà cliccare un bottone per creare 3 utenti dimostrativi, come risulta dall'action `CreateTestUsers` alla riga 34 dell'[HomeController](Controllers/HomeController.cs).
 1. **Amministratore**: può visualizzare l'elenco completo dei clienti e dei loro ordini. Accede con username _admin@example.com_ e password _Password1!_
 2. **Cliente VIP**: ha acquisito lo status di VIP in quanto ha inviato più di 1000 euro di ordini e per questo può accedere all'elenco delle offerte speciali. Può visualizzare solo il suo profilo, creare o eliminare ordini. Inoltre, può visualizzare un report a lui dedicato. Accede con username _customer1@example.com_ e password _Customer1!_
 3. **Cliente normale**: può visualizzare il suo profilo, creare o eliminare ordini. Accede con username _customer2@example.com_ e password _Customer2!_

L'applicazione reagirà diversamente in base all'utente con cui si è fatto il login perché usa gli attributi `Authorize` e il servizio `IAuthorizationService` per proteggere le proprie action.

* L'action `IndexAll` del [CustomerController](Controllers/CustomerController.cs) estrae l'intero elenco dei clienti ma è protetto con l'attributo `[Authorize(Roles = "Administrator")]` per consentire l'accesso solo all'amministratore;
* Analogamente, nell'[OrderController](Controllers/OrderController.cs), l'action `Create` è stata protetta con `[Authorize(Roles = "Customer")]` per consentire di inviare ordini solo agli utenti con ruolo "Customer";
* Nell'[OrderController](Controllers/OrderController.cs), l'action `Delete` usa il servizio `IAuthorizationService` per attuare la policy `SelfOrAdministrator` in relazione all'ordine che si intende eliminare. Tale policy, definita nella classe [Startup](Startup.cs), verificherà che che l'autore dell'ordine sia l'utente corrente, oppure che sia stato un utente con ruolo "Administrator" a richiedere l'eliminazione;
* Lo [SpecialOfferController](Controllers/SpecialOfferController.cs) usa l'attributo `[Authorize]` per attuare la policy `VipCustomers` che impedirà l'accesso agli utenti non VIP. Lo status di VIP viene controllato ogni volta dal [MinimumPurchaseAuthorizationHandler](Authorization/MinimumPurchaseAuthorizationHandler.cs) accedendo al database e conteggiando il totale degli ordini inviati dal cliente.


## Esercizi
 * Aggiungere uno o più ordini a Cliente2 dalla pagina /Order in modo che il suo totale superi i 1000 euro. In questo modo diventerà anch'esso un cliente VIP e potrà accedere alla pagina  /SpecialOffer.
 * Modificare il [MinimumPurchaseAuthorizationHandler](Authorization/MinimumPurchaseAuthorizationHandler.cs) in modo che sfrutti la cache per evitare di interrogare il database ad ogni richiesta. Invalidare o aggiornare la cache quando il cliente invia un nuovo ordine dall'[OrderController](Controllers/OrderController.cs).