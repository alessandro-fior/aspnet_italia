﻿
Imports System.Data.Entity
Imports System.Data.Entity.Infrastructure
Imports System.Net
Imports System.Web.Http
Imports System.Web.Http.Description

Public Class EFCustomersController
    Inherits ApiController

    Private db As New SampleContext()

    ' GET: api/EFCustomers
    Public Function GetCustomers() As IQueryable(Of Customer)
        Return db.Customers
    End Function

    ' GET: api/EFCustomers/5
    <ResponseType(GetType(Customer))>
    Public Function GetCustomer(id As Integer) As IHttpActionResult
        Dim customer As Customer = db.Customers.Find(id)
        If customer Is Nothing Then
            Return NotFound()
        End If

        Return Ok(customer)
    End Function

    ' PUT: api/EFCustomers/5
    <ResponseType(GetType(System.Void))>
    Public Function PutCustomer(id As Integer, customer As Customer) As IHttpActionResult
        If Not ModelState.IsValid Then
            Return BadRequest(ModelState)
        End If

        If id <> customer.Id Then
            Return BadRequest()
        End If

        db.Entry(customer).State = EntityState.Modified

        Try
            db.SaveChanges()
        Catch generatedExceptionName As DbUpdateConcurrencyException
            If Not CustomerExists(id) Then
                Return NotFound()
            Else
                Throw
            End If
        End Try

        Return StatusCode(HttpStatusCode.NoContent)
    End Function

    ' POST: api/EFCustomers
    <ResponseType(GetType(Customer))>
    Public Function PostCustomer(customer As Customer) As IHttpActionResult
        If Not ModelState.IsValid Then
            Return BadRequest(ModelState)
        End If

        db.Customers.Add(customer)
        db.SaveChanges()

        Return CreatedAtRoute("DefaultApi", New With {
            Key .id = customer.Id
        }, customer)
    End Function

    ' DELETE: api/EFCustomers/5
    <ResponseType(GetType(Customer))>
    Public Function DeleteCustomer(id As Integer) As IHttpActionResult
        Dim customer As Customer = db.Customers.Find(id)
        If customer Is Nothing Then
            Return NotFound()
        End If

        db.Customers.Remove(customer)
        db.SaveChanges()

        Return Ok(customer)
    End Function

    Protected Overrides Sub Dispose(disposing As Boolean)
        If disposing Then
            db.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    Private Function CustomerExists(id As Integer) As Boolean
        Return db.Customers.Count(Function(e) e.Id = id) > 0
    End Function
End Class

