﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp1.Client.Models
{
    public class SampleClass
    {
        [Required]
        [StringLength(10, ErrorMessage = "Ops! Max 10 caratteri.")]
        [MinLength(3, ErrorMessage = "Minimo 3 caratteri")]
        public string Name { get; set; }
        
        [Range(1, 100000, ErrorMessage = "Numero non disponibile (1-100000).")]
        public int Number { get; set; }

        [Required]
        public DateTime Date { get; set; } = DateTime.Now;

        [Required]
        [Range(typeof(bool), "true", "true", 
            ErrorMessage = "Devi accettare")]
        public bool Accept { get; set; }

     
    }
}
