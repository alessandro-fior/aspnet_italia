﻿Imports System.Security
Imports System.Security.Permissions
Imports Plugin
Imports System.IO

<Assembly: SecurityTransparent()> 
Class MainWindow
  Dim plg As PluginElement

  Public Sub New()
    InitializeComponent()

    Dim ps1 As PermissionSet = New PermissionSet(PermissionState.None)
    ps1.AddPermission(New SecurityPermission(SecurityPermissionFlag.Execution))
    ps1.AddPermission(New FileIOPermission(FileIOPermissionAccess.Write, "d:\"))
    Dim domainSetup As AppDomainSetup = AppDomain.CurrentDomain.SetupInformation
    Dim sandbox As AppDomain = AppDomain.CreateDomain("sandbox", _
                                                      Nothing, _
                                                      domainSetup, ps1)
    plg = DirectCast(sandbox.CreateInstanceAndUnwrap("Plugin", _
                                                     "Plugin.PluginElement"), PluginElement)
  End Sub

  Private Sub Button_Click(ByVal sender As System.Object, _
                           ByVal e As System.Windows.RoutedEventArgs)
    Dim dataStream As Stream = File.OpenWrite( _
        String.Format("d:\file1.txt"))

    Dim str As StreamWriter = New StreamWriter(dataStream)
    str.Write(TextBox2.Text)
    str.Close()
    dataStream.Close()
  End Sub

  Private Sub Button_Click_1(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs)
    plg.WriteFile(TextBox3.Text, "d:\writeDaPlugin.txt")
  End Sub

  Private Sub Button_Click_2(ByVal sender As System.Object, _
                             ByVal e As System.Windows.RoutedEventArgs)
    ' System.MethodAccessException was unhandled
    ' Message=Attempt by security transparent method 
    ' 'WpfApplication1.MainWindow.Button_Click_2(System.Object, System.Windows.RoutedEventArgs)'
    ' to access security critical method 
    ' 'Plugin.PluginElement.DirectWriteFile(System.String, System.String)' failed.
    plg.DirectWriteFile(TextBox4.Text, "d:\writeDirectDaPlugin.txt")
  End Sub

End Class