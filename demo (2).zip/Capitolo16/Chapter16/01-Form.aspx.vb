﻿Public Class _01_Form
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub ShowFirstName(sender As Object, e As EventArgs)
        YourName.Text = "Il tuo nome è " + FirstName.Text
    End Sub


End Class