using System.Threading.Tasks;
using CustomerAuthorization.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace CustomerAuthorization.Controllers
{
    [Authorize(Policy = "VipCustomers")]
    public class SpecialOfferController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}