Per il corretto funzionamento delle demo � necessario scaricare i video di esempio dai seguenti indirizzi:
http://www.archive.org/download/BathToyLakeHaweaWaves/hawea_512kb.mp4
http://www.archive.org/download/BathToyLakeHaweaWaves/hawea.ogv

e rinominarli in test.mp4 e test.ogv

I video sono in licenza Creative Commons
Nigel Parker
http://video.stickon.me/


MediaElement.js � in licenza GPLv2/MIT
https://github.com/johndyer/mediaelement/