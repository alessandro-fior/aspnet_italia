﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.HttpSys;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace EndpointConfig
{
    public class Program
    {
        public static void Main(string[] args)
        {
            BuildWebHost(args).Run();
        }

        public static IWebHost BuildWebHost(string[] args) {
            //Creiamo una configurazione per il web host
            //usando come fonti il file hosting.json e le variabili d'ambiente
            var config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddInMemoryCollection(configObject)
                .AddJsonFile("hosting.json")
                .AddEnvironmentVariables("ASPNETCORE_")
                .Build();

            return WebHost.CreateDefaultBuilder(args)
                //Forniamo l'oggetto config al WebHostBuilder
                .UseConfiguration(config)
                .UseStartup<Startup>()
                .Build();
        }

        private static Dictionary<string, string> configObject = new Dictionary<string, string> {
            {"Urls", "http://localhost:9000"}
        };
    }
}
