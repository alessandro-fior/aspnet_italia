﻿using System;

namespace Capitolo06.Models
{
    public class HomeViewModel
    {
        public string Title { get; set; }
        public DateTime TheDate { get; set; }
    }
}
