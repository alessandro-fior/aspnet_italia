﻿Imports System.Xml
Imports System.IO

Public Class Sample3

    Public Shared Sub Run()
        Dim doc As New XmlDocument()

        ' Uri: percorso relativo al file
        doc.Load("test.xml")

        ' Nome del tag e namespace dell'ultimo figlio
        Console.WriteLine("LocalName: {0} - Namespace: {1}",
          doc.DocumentElement.LastChild.LocalName,
          doc.DocumentElement.LastChild.NamespaceURI)

        ' Attributo idProduct sull'ultimo figlio (tag product)
        Dim product As XmlElement =
          DirectCast(doc.DocumentElement.LastChild, XmlElement)
        Console.WriteLine("idProduct: {0}",
          product.Attributes("idProduct").Value)
        Console.WriteLine("idProduct: {0}",
          product.GetAttribute("idProduct"))

        ' XML del primo figlio di products (il commento)
        Console.WriteLine("Comment: {0}",
          doc.DocumentElement.FirstChild.OuterXml)

        ' Tag description del secondo figlio (tag product)
        Dim description As XmlElement =
          doc.DocumentElement.ChildNodes(1)("description",
          "http://schemas.aspitalia.com/book40/products")

        ' InnerText interroga direttamente il value dei figli
        Console.WriteLine("Description: {0}", description.InnerText)
        ' Entro direttamente nel figlio che è un XmlText
        Console.WriteLine("Description: {0}", description.FirstChild.Value)

    End Sub

End Class
