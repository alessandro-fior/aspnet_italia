﻿Imports Microsoft.Extensions.Configuration
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Text
Imports System.Threading.Tasks
Imports System.Transactions

Module Program

	Shared connectionString As String

	Sub Main(args As String())
		Dim config = New ConfigurationBuilder().AddJsonFile("appsettings.json", True, True).Build()
		connectionString = config.GetConnectionString("db")
		Console.ReadLine()

	End Sub

End Module
