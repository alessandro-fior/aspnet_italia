﻿namespace ContentLocalization.Services
{
    public interface ICustomService
    {
        string SendReply(string key);
    }
}