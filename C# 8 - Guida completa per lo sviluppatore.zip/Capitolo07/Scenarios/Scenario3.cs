﻿using System;

namespace Capitolo7.Scenarios
{
    public static class Scenario3
    {
        /// <summary>
        /// Esempio 7.4
        /// </summary>
        public static void Run()
        {
            try
            {
                var result = Division(5, 0);

                // Questo codice non viene mai eseguito
                Console.WriteLine("Il risultato è {0}", result);
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Errore: non si può dividere per zero");
            }
            catch (OutOfMemoryException ex)
            {
                Console.WriteLine("Memoria terminata");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Si è verificato un errore generico");
            }
        }

        public static int Division(int a, int b)
        {
            int result = a / b;

            // in caso di errore questo codice non viene mai eseguito
            Console.WriteLine("Risultato calcolato con successo");
            return result;
        }
    }
}