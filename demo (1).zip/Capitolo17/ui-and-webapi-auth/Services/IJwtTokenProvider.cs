using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;

namespace UiAndApiAuth.Services {
    public interface IJwtTokenProvider {
        TokenValidationParameters GetTokenValidationParameters();
        string CreateToken(ClaimsIdentity identity);
    }
}