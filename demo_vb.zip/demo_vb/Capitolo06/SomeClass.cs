﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPItalia.Books.Chapter06
{
    public class SomeClass
    {
        public SomeClass(PortReceiver receiver)
        {
            receiver.PortDataReceived += DataReceived;
        }

        private void DataReceived(object sender, PortDataReceivedEventArgs e)
        {
            Console.WriteLine(e.Data);
        }
    }
}
