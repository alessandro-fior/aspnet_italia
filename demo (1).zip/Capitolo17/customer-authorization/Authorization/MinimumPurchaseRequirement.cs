using Microsoft.AspNetCore.Authorization;

namespace CustomerAuthorization.Authorization
{
    public class MinimumPurchaseRequirement : IAuthorizationRequirement
    {
        public MinimumPurchaseRequirement(decimal minimum)
        {
            Minimum = minimum;
        }
        public decimal Minimum { get; }
    }
}