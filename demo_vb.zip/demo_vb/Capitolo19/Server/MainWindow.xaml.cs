﻿using System;
using System.Text;
using System.Windows;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace Server
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
			ReiceveData();
		}

		private void Button1_Click(object sender, RoutedEventArgs e)
		{
			var client = new UdpClient();
			client.Connect("localhost", 8080);
			byte[] sendByte = Encoding.ASCII.GetBytes(this.TextBox1.Text);
			client.SendAsync(sendByte, sendByte.Length);
		}

		private async Task ReiceveData()
		{
			var server = new UdpClient(8080);
			while (true)
			{
				var result = await server.ReceiveAsync();
				var reiceveByte = result.Buffer;
				var reiceveString = Encoding.ASCII.GetString(reiceveByte);
				TextBox2.Text += String.Format(" {0}", reiceveString);
			}
		}
	}
}
