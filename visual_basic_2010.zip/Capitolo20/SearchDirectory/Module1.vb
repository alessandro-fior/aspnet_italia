﻿Imports System
Imports System.IO

Module Module1
    Sub Main()
        Dim dInfo As DirectoryInfo = New DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments))
        Try
            Dim directories() As DirectoryInfo = dInfo.GetDirectories("*", SearchOption.TopDirectoryOnly)
            Dim directory As DirectoryInfo
            For Each directory In directories
                Console.WriteLine("{0} {1}", directory.FullName, directory.LastAccessTime)
            Next directory
        Catch ex As Exception
            Console.WriteLine("Si è verificato un errore: {0}", ex.ToString())
        End Try
        Console.ReadLine()
    End Sub
End Module
