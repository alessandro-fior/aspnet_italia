﻿Imports System.Net.Sockets
Imports System.Text
Imports System.Net
Imports System.Threading

Class MainWindow
  Public Delegate Sub PrintDataDelegate(ByVal result As String)

  Public Sub New()
    InitializeComponent()

    Dim threadServer = New Thread(New ThreadStart(AddressOf ReiceveData))
    threadServer.Start()
  End Sub

  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button1.Click
    Dim client As New UdpClient()
    client.Connect("localhost", 8080)
    Dim sendByte As Byte() = Encoding.ASCII.GetBytes(TextBox1.Text)
    client.Send(sendByte, sendByte.Length)
  End Sub

  Private Sub ReiceveData()
    Dim server As New UdpClient(8080)
    While (True)
      Dim endPoint As New IPEndPoint(IPAddress.Any, 8080)
      Dim reiceveByte As Byte() = server.Receive(endPoint)
      Dim reiceveString As String = Encoding.ASCII.GetString(reiceveByte)
      Dispatcher.BeginInvoke(New PrintDataDelegate(AddressOf PrintData), reiceveString)
    End While
  End Sub

  Private Sub PrintData(ByVal str As String)
    TextBox2.Text += String.Format(" {0}", str)
  End Sub

End Class


