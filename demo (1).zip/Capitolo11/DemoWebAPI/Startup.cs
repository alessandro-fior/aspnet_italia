﻿using DemoWebAPI.Extensions;
using DemoWebAPI.Models;
using DemoWebAPI.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace DemoWebAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // aggiunge il supporto per MVC e agli input/output formatter
            services.AddMvc(options =>
            {
                options.ReturnHttpNotAcceptable = true;

                options.OutputFormatters.Add(new XmlDataContractSerializerOutputFormatter());
                options.InputFormatters.Add(new XmlDataContractSerializerInputFormatter(options));
            })
            .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            // aggiunge i servizi per repository e url helper
            services.AddTransient<ICustomerRepository, CustomerRepository>();
            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            services.AddScoped<IUrlHelper>(factory =>
            {
                var actionContext = factory.GetService<IActionContextAccessor>()
                                           .ActionContext;
                return new UrlHelper(actionContext);
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            // gestione degli errori e delle eccezioni con errore 500
            app.UseExceptionHandler(options =>
            {
                options.Run(async context =>
                {
                    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
                    await context.Response.WriteAsync("Qualcosa è andato storto.");
                });
            });

            // configurazione di automapper
            AutoMapper.Mapper.Initialize(config =>
            {
                config.CreateMap<Customer, CustomerForRead>()
                      .ForMember(o => o.Name, i => i.MapFrom(m => $"{m.FirstName} {m.LastName}"))
                      .ForMember(o => o.Age, i => i.MapFrom(m => m.DateOfBirth.GetAge()));

                config.CreateMap<Customer, CustomerForReadV2>()
                      .ForMember(o => o.Name, i => i.MapFrom(m => $"{m.FirstName} {m.LastName}"))
                      .ForMember(o => o.Age, i => i.MapFrom(m => m.DateOfBirth.GetAge()));

                config.CreateMap<CustomerForCreate, Customer>();
                config.CreateMap<CustomerForUpdate, Customer>();
                config.CreateMap<Customer, CustomerForUpdate>();
            });
            
            app.UseMvc();
        }
    }
}