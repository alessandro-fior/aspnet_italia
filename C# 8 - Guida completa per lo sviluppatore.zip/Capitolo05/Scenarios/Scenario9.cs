﻿using System;
using System.Collections.Generic;

namespace Capitolo5.Scenarios
{
    public static class Scenario9
    {
        /// <summary>
        /// Esempio 5.12, 5.13
        /// </summary>
        public static void Run()
        {
            var holidays = new Dictionary<string, DateTime>();
            holidays.Add("Natale", new DateTime(2019, 12, 25));
            holidays.Add("Capodanno", new DateTime(2019, 1, 1));
            holidays.Add("Compleanno", new DateTime(2019, 7, 10));

            // inizializzazione alternativa
            //var holidays = new Dictionary<string, DateTime>()
            //{
            //    ["Natale"] = new DateTime(2019, 12, 25),
            //    ["Capodanno"] = new DateTime(2019, 1, 1),
            //    ["Compleanno"] = new DateTime(2019, 7, 10)
            //};

            DateTime vigiliaCompleanno = DateTime.MinValue;

            if (holidays.ContainsKey("Compleanno"))
                vigiliaCompleanno = holidays["Compleanno"].AddDays(-1);
            else
                Console.WriteLine("La data cercata non esiste");

            Console.WriteLine($"La vigilia del compleanno è: {vigiliaCompleanno}");
        }
    }
}