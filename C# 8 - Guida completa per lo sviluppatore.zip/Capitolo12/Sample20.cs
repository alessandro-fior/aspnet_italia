﻿using System.Linq;
using System.Xml.XPath;
using System.Xml;
using System.Xml.Xsl;
using System;
using System.IO;


public class Sample20
{

    public static void Run()
    {
        var xslt = new XslCompiledTransform();
        // Carico la trasformazione XSLT
        xslt.Load(Path.Combine(Environment.CurrentDirectory, "test.xslt"));

        // Trasformo l'XML e lo mostro nella finestra di Output
        xslt.Transform(Path.Combine(Environment.CurrentDirectory, "test.xml"), null, Console.Out);
    }

}
