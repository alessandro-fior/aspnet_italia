﻿namespace Dottor.BlazorTips.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class MapAttribute : Attribute
    {
    }
}
