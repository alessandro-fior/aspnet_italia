﻿Imports Microsoft.EntityFrameworkCore
Imports Microsoft.Extensions.Configuration

Partial Public Class NorthwindContext
	Inherits DbContext

	Public Overridable Property Customers As DbSet(Of Customer)
	Public Overridable Property Order_Details As DbSet(Of OrderDetail)
	Public Overridable Property Orders As DbSet(Of Order)

	Protected Overrides Sub OnConfiguring(ByVal optionsBuilder As DbContextOptionsBuilder)
		Dim config = New ConfigurationBuilder().AddJsonFile("appsettings.json", True, True).Build
		optionsBuilder.UseSqlServer(config.GetConnectionString("NorthwindContext"))
	End Sub

	Protected Overrides Sub OnModelCreating(ByVal modelBuilder As ModelBuilder)
		modelBuilder.Entity(Of Customer)(Sub(entity)
																			 entity.Property(Function(e) e.CustomerID).IsFixedLength()
																		 End Sub)
		modelBuilder.Entity(Of OrderDetail)(Sub(entity)
																					entity.ToTable("Order Details")
																					entity.Property(Function(e) e.UnitPrice)
																					entity.HasKey(Function(p) New With {p.OrderID, p.ProductID})
																				End Sub)
		modelBuilder.Entity(Of Order)(Sub(entity)
																		entity.Property(Function(e) e.CustomerID).IsFixedLength()
																		entity.Property(Function(e) e.Freight)
																		entity.HasMany(Function(e) e.Order_Details).WithOne(Function(e) e.Order).OnDelete(DeleteBehavior.Cascade)
																	End Sub)
	End Sub
End Class
