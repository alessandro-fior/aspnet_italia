﻿Imports System.Data.Entity
Namespace Models
    Public Class StoreContext
        Inherits DbContext
        Public Property Customers() As DbSet(Of Customer)
    End Class
End Namespace