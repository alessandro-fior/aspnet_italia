﻿using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlazorConf21.Demo.Library.Services
{
    public class BrowserSizeService : IAsyncDisposable
    {
        private IJSRuntime _jsRuntime;
        private IJSObjectReference _module;

        public BrowserSizeService(IJSRuntime jsRuntime)
        {
            _jsRuntime = jsRuntime;
        }

        public async Task InitializeAsync()
        {
            _module = await _jsRuntime.InvokeAsync<IJSObjectReference>("import", "./_content/BlazorConf21.Demo.Library/browser-size.js");
            await _module.InvokeVoidAsync("registerResizeCallback");
        }

        public static event Func<Task> OnResize;

        [JSInvokable]
        public static async Task OnBrowserResize()
        {
            await OnResize?.Invoke();
        }

        public ValueTask DisposeAsync()
        {
            return _module.DisposeAsync();
        }

        public async Task<int> GetWidth()
        {
            return await _jsRuntime.InvokeAsync<int>("eval", "innerWidth");
        }

        public async Task<int> GetHeight()
        {
            return await _jsRuntime.InvokeAsync<int>("eval", "innerHeight");
        }
    }

}
