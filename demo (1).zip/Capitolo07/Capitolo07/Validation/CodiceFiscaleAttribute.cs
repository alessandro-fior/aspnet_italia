﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Capitolo07.Validation
{
    public class CodiceFiscaleAttribute : ValidationAttribute, IClientModelValidator
    {
        public override bool IsValid(object value)
        {
            var result = false;
            //TODO: convalidare codice fiscale con regole server side

            return result;
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var result = IsValid(value);

            if (result)
                return ValidationResult.Success;
            else
                return new ValidationResult(GetErrorMessage());
        }

        // lato client
        public void AddValidation(ClientModelValidationContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            MergeAttribute(context.Attributes, "data-val", "true");
            MergeAttribute(context.Attributes, "data-val-codicefiscale", GetErrorMessage());
        }

        private bool MergeAttribute(IDictionary<string, string> attributes, string key, string value)
        {
            if (attributes.ContainsKey(key))
            {
                return false;
            }

            attributes.Add(key, value);

            return true;
        }

        private string GetErrorMessage()
        {
            return "Codice fiscale errato";
        }
    }
}
