﻿namespace Capitolo15.Models
{
    public class Person
    {
        //[BindRequired]
        public string FirstName { get; set; }

        //[BindRequired]
        public string LastName { get; set; }

        //[BindNever]
        public int Age { get; set; }
    }
}