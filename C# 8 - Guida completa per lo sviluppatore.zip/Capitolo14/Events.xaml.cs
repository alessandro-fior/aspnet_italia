﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Capitolo14
{
    /// <summary>
    /// Interaction logic for Events.xaml
    /// </summary>
    public partial class Events : Window
    {
        public Events()
        {
            InitializeComponent();
        }

        private void Window_MouseUp(System.Object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            MessageBox.Show("Pulsante premuto su " + e.OriginalSource.GetType().Name);
        }

        private void Rectangle_MouseUp(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
        }

    }
}
