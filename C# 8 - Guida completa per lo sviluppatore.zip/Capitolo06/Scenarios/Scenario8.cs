﻿using System;

namespace Capitolo6.Scenarios
{
    public static class Scenario8
    {
        /// <summary>
        /// Esempio 6.9, 6.10
        /// </summary>
        public static void Run()
        {
            // la sintassi è equivalente
            var sample = new MyDelegate<DateTime>(DateTimeWriter);
            //var sample = new Func<DateTime, string>(DateTimeWriter);
        }

        public delegate string MyDelegate<T>(T input) where T : struct;

        private static string DateTimeWriter(DateTime input)
        {
            return input.ToShortDateString();
        }
    }
}