﻿using DemoWebAPI.Models;
using System;
using System.Collections.Generic;

namespace DemoWebAPI.Repositories
{
    public interface ICustomerRepository
    {
        IEnumerable<Customer> GetCustomers();
        Customer GetCustomer(Guid id);
        bool CustomerExists(Guid id);
        void AddCustomer(Customer customer);
        void AddCustomers(IEnumerable<Customer> customers);
        void UpdateCustomer(Customer customer);
        void DeleteCustomer(Guid id);
        bool SaveChanges();
    }
}