﻿Namespace Models
    Public Class Customer
        Public Property ID() As Integer
        Public Property CompanyName() As String
    End Class

End Namespace