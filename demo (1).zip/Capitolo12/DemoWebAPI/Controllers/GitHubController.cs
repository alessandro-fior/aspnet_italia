﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebHooks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace DemoWebAPI.Controllers
{
    [ApiVersion("1.0")]
    public class GitHubController : Controller
    {
        private readonly ILogger logger;

        /// <summary>
        /// Crea una nuova istanza della classe <see cref="DemoWebAPI.Controllers.GitHubController" />
        /// </summary>
        /// <param name="logger">Il servizio di logging</param>
        public GitHubController(ILogger<GitHubController> logger)
        {
            this.logger = logger;
        }

        /// <summary>
        /// Gestisce un WebHook per un evento proveniente da GitHub
        /// </summary>
        /// <param name="id">L'identificativo dell'evento</param>
        /// <param name="event">Il nome dell'evento</param>
        /// <param name="data">Il payload relativo all'evento</param>
        /// <returns></returns>
        /// <response code="200">Quando il payoad è stato processato correttamente</response>
        [GitHubWebHook]
        public IActionResult GitHubHandler(string id, string @event, JObject data)
        {
            // TODO: logica personalizzata qui...
            logger.Log(LogLevel.Trace, $"Evento ricevuto {@event}");

            return Ok();
        }
    }
}