﻿Imports System.Linq
Imports System.Xml.XPath
Imports System.Xml



Public Class Sample21

    Public Shared Sub Run()

        Dim doc As New XPathDocument("test.xml")
        Dim navigator = doc.CreateNavigator()

        ' Creo il gestore dei namespace
        Dim nsManager As New XmlNamespaceManager(navigator.NameTable)
        ' Associo il prefisso al namespace
        nsManager.AddNamespace("p", "http://schemas.aspitalia.com/book40/products")

        ' Navigo direttamente sull'attributo
        Dim exp As XPathExpression = navigator.Compile("number(/p:products/p:product[1]/@idCategory)")
        ' Imposto il resolver dei namespace
        exp.SetContext(nsManager)

        ' Leggo il valore
        Dim idCategory As Integer = CInt(navigator.Evaluate(exp))

        Console.WriteLine(idCategory)

    End Sub

End Class
