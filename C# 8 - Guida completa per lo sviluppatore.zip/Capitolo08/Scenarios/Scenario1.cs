﻿using System;
using System.Threading;

namespace Capitolo8.Scenarios
{
    public static class Scenario1
    {
        /// <summary>
        /// Esempio 8.1
        /// </summary>
        public static void Run()
        {
            Thread myThread = new Thread(() =>
            {
                Console.WriteLine("MyThread è iniziato");
                Thread.Sleep(1000);
                Console.WriteLine("MyThread è terminato");
            });

            // Esecuzione di myThread
            myThread.Start();

            Thread.Sleep(500);
            Console.WriteLine("Main Thread");
        }
    }
}