﻿onmessage = function (e)
{
    for (var i = 0; i <= e.data; i++)
        postMessage(i);    
};