﻿Imports System.Data.Entity
Namespace Models
    Public Class NorthwindContext
        Inherits DbContext
        Public Sub New()
            MyBase.New("NorthwindContext")
        End Sub
        Public Property Customers() As DbSet(Of Customer)
    End Class
End Namespace