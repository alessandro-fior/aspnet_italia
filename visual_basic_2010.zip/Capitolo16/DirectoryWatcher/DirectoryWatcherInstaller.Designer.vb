﻿<System.ComponentModel.RunInstaller(True)> Partial Class DirectoryWatcherInstaller
    Inherits System.Configuration.Install.Installer

    'Installer overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DirectoryWatcherServiceProcessInstaller = New System.ServiceProcess.ServiceProcessInstaller()
        Me.DirectoryWatcherServiceInstaller = New System.ServiceProcess.ServiceInstaller()
        '
        'DirectoryWatcherServiceProcessInstaller
        '
        Me.DirectoryWatcherServiceProcessInstaller.Account = System.ServiceProcess.ServiceAccount.LocalSystem
        Me.DirectoryWatcherServiceProcessInstaller.Password = Nothing
        Me.DirectoryWatcherServiceProcessInstaller.Username = Nothing
        '
        'DirectoryWatcherServiceInstaller
        '
        Me.DirectoryWatcherServiceInstaller.Description = "Filesystem directory monitor"
        Me.DirectoryWatcherServiceInstaller.DisplayName = "Directory Watcher"
        Me.DirectoryWatcherServiceInstaller.ServiceName = "Directory Watcher"
        Me.DirectoryWatcherServiceInstaller.StartType = System.ServiceProcess.ServiceStartMode.Automatic
        '
        'DirectoryWatcherInstaller
        '
        Me.Installers.AddRange(New System.Configuration.Install.Installer() {Me.DirectoryWatcherServiceProcessInstaller, Me.DirectoryWatcherServiceInstaller})

    End Sub
    Friend WithEvents DirectoryWatcherServiceProcessInstaller As System.ServiceProcess.ServiceProcessInstaller
    Friend WithEvents DirectoryWatcherServiceInstaller As System.ServiceProcess.ServiceInstaller

End Class
