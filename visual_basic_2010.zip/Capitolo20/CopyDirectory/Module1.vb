﻿Imports System
Imports System.IO
Module Module1

    Sub Main()
        Dim directories() As DirectoryInfo = New DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments)).GetDirectories()
        Try
            Dim directoryInfo As DirectoryInfo
            For Each directoryInfo In directories
                If Not directoryInfo.GetAccessControl().AreAccessRulesProtected Then
                    Dim copyPath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments), String.Format("{0} copia", directoryInfo.Name))
                    Directory.CreateDirectory(copyPath)
                    Console.WriteLine(String.Format("Cartella {0} copiata correttamente", directoryInfo.Name))
                    Dim fileInfo As FileInfo
                    Dim files() As FileInfo = directoryInfo.GetFiles()
                    For Each fileInfo In files
                        fileInfo.CopyTo(Path.Combine(copyPath, String.Format("{0} copia{1} ", Path.GetFileNameWithoutExtension(fileInfo.Name), Path.GetExtension(fileInfo.Name))))
                        Console.WriteLine(String.Format("File {0} copiato correttamente", fileInfo.Name))
                    Next fileInfo
                Else
                    Console.WriteLine(String.Format("Impossibile copiare la cartella {0}", directoryInfo.Name))
                End If
            Next directoryInfo
        Catch ex As Exception
            Console.WriteLine("Si è verificato un errore: {0}", ex.ToString())
        End Try
        Console.ReadLine()

    End Sub
End Module