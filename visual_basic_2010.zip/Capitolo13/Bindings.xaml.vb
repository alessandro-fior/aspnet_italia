﻿Imports System.Windows.Markup

Public Class Bindings

    Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)

        Me.Language = XmlLanguage.GetLanguage("it-IT")

        Dim list As Category() = {
            New Category With {
                .Products = {
                    New Product With {.Description = "Cat 1 - Prodotto 1", .Id = 1},
                    New Product With {.Description = "Cat 2 - Prodotto 2", .Id = 2}},
                .Description = "Categoria 1",
                .Id = 1
            },
            New Category With {
                .Products = {
                    New Product With {.Description = "Cat 2 - Prodotto 3", .Id = 1},
                    New Product With {.Description = "Cat 2 - Prodotto 4", .Id = 2}},
                .Description = "Categoria 2",
                .Id = 2
            }
        }

        Me.DataContext = list
    End Sub
End Class

Public Class Category

    Public Property Id As Int32

    Public Property Description As String

    Public Property Products As Product()
End Class

Public Class Product

    Public Property Id As Int32

    Public Property Description As String

End Class