# Autenticazione basata sui cookie senza usare ASP.NET Core Identity
In questa applicazione dimostrativa usiamo lo scheme di autenticazione basato sui Cookie senza ricorrere ad ASP.NET Identity come sistema di membership. Come conseguenza, siamo noi a dover realizzare:
 * Le maschere di login e registrazione;
 * Il codice necessario alla verifica delle credenziali immesse dall'utente;
 * Il codice per emettere il token contenente la ClaimsIdentity con i claim dell'utente.

 Lo **scheme di autenticazione basato sui cookie** viene aggiunto nel metodo `ConfigureServices`, a partire dalla riga 28 della classe [Startup](Startup.cs).
 Inoltre, non dimentichiamo di usare il **middleware di autenticazione** di ASP.NET Core nel metodo `Configure`, alla riga 44 della classe [Startup](Startup.cs). Senza il middleware, infatti, l'utente non risulterebbe mai autenticato perché l'applicazione non ricreerebbe per lui una `ClaimsIdentity`, neanche se il cookie è stato fornito.

 La classe [HomeController](Controllers/HomeController.cs) contiene invece la logica di verifica le credenziali e di creazione della ClaimsIdentity che verrà serializzata nel cookie. Il cookie viene quindi emesso alla riga 72 grazie all'invocazione di `HttpContext.SignInAsync`.

 ## Esercizio
 Modificare la scadenza del cookie alla riga 35 della classe [Startup](Startup.cs) in modo che sia di 30 secondi ma con sliding expiration (options.SlidingExpiration = true), il che permetterà all'utente di restare loggato per più di 30 secondi, ammesso che continui a inviare richieste prima che il cookie scada. Continuare ad aggiornare la homepage e, usando gli strumenti di sviluppo del browser (tasto F12), verificare che ASP.NET Core emetta automaticamente un nuovo cookie con una scadenza aggiornata nella risposta. L'emissione del nuovo cookie si verifica a ridosso della scadenza del precedente cookie.

 **Importante**: in applicazioni reali, impostare una scadenza ben più lunga, di almeno 1 giorno, altrimenti gli utenti saranno obbligati a rifare il login spesso, dopo brevi periodi di inattività.