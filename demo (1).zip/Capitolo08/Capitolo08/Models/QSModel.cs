using Microsoft.Extensions.Primitives;

namespace Capitolo08.Models
{
	public class QSModel
	{
		public string RequestId { get; set; }

		public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

		public int KeyFromParam { get; internal set; }
		public string VFromParam { get; internal set; }
		public StringValues KeyFromQS { get; internal set; }
		public StringValues VFromQS { get; internal set; }
	}
}