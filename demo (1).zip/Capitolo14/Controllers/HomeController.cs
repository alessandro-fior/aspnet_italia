﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Capitolo14.Filters;
using Capitolo14.Middleware;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;

namespace Capitolo14.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            Stopwatch sw = HttpContext.GetTimer();
            return View();
        }

        public IActionResult RaiseError()
        {
            throw new Exception("Test");
        }
    }
}