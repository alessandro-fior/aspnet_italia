﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Capitolo10.Framework
{
	class Program
	{
		static string connectionString;

		static void Main(string[] args)
		{
			connectionString = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
			Console.ReadLine();
		}

		private static async Task CreaConnessione()
		{
			{
				var conn = new SqlConnection(connectionString);
				try
				{
					await conn.OpenAsync();
				}
				catch (SqlException ex)
				{
				}
				finally
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}

			{
				using (var connection = new SqlConnection(connectionString))
				{
					try
					{
						await connection.OpenAsync();
					}
					catch (SqlException ex)
					{
					}
				}
			}
		}

		private static void CreaStringaConnessione()
		{
			var builder = new SqlConnectionStringBuilder();
			builder.DataSource = "(local)";
			builder.InitialCatalog = "northwind";
			builder.IntegratedSecurity = true;
			Console.WriteLine(builder.ConnectionString);
		}

		private static async Task ExecuteNonQuery()
		{
			// Creazione della connessione
			using (SqlConnection conn = new SqlConnection(connectionString))
			{
				// Apertura della connessione
				await conn.OpenAsync();

				// Creazione del comando
				using (SqlCommand cmd = new SqlCommand("UPDATE Customers SET City='Bergamo' WHERE CustomerID=@CustomerID", conn))
				{
					// Aggiungi un parametro
					cmd.Parameters.AddWithValue("@CustomerID", "MAGAA");

					// Ritorna il numero di righe interessate dal comando di aggiornamento
					int rowsAffected = await cmd.ExecuteNonQueryAsync();

					Console.WriteLine(cmd.CommandText.Replace(cmd.Parameters[0].ParameterName, "'" + cmd.Parameters[0].Value + "'\n"));
					Console.WriteLine(rowsAffected.ToString());

				} // Il comando viene chiuso automaticamente alla fine del blocco Using

			} // La connessione viene chiusa automaticamente alla fine del blocco Using
		}

		private static async Task ExecuteReader()
		{
			StringBuilder builder = new StringBuilder();

			// Creazione della connessione
			using (SqlConnection conn = new SqlConnection(connectionString))
			{
				// Apertura della connessione
				await conn.OpenAsync();

				// Creazione del comando
				using (SqlCommand cmd = new SqlCommand("SELECT TOP (10) CustomerID, CompanyName, ContactName, City FROM Customers", conn))
				{
					// Ritorna un resultset
					using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
					{
						// Ciclo sul risultato della query
						while (reader.Read())
						{
							builder.Append(string.Concat(reader.GetString(0), " - ", reader.GetString(1), " - ", reader.GetString(2), " - ", reader.GetString(3), "\n"));
						}

					}  // Il data reader viene chiuso automaticamente alla fine del blocco Using

					Console.WriteLine(cmd.CommandText + "\n");
					Console.WriteLine(builder.ToString());

				} // Il comando viene chiuso automaticamente alla fine del blocco Using

			} // La connessione viene chiusa automaticamente alla fine del blocco Using
		}

		private static async Task ExecuteScalar()
		{
			// Creazione della connessione
			using (SqlConnection conn = new SqlConnection(connectionString))
			{
				// Apertura della connessione
				await conn.OpenAsync();

				// Creazione del comando
				using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Customers", conn))
				{
					// Ritorna un valore intero
					int count = (int)(await cmd.ExecuteScalarAsync());

					Console.WriteLine(cmd.CommandText + "\n");
					Console.WriteLine(count.ToString());

				} // Il comando viene chiuso automaticamente alla fine del blocco Using

			} // La connessione viene chiusa automaticamente alla fine del blocco Using
		}

		private static async Task DbTransaction()
		{
			using (var connection = new SqlConnection(connectionString))
			{
				await connection.OpenAsync();
				using (var transaction = connection.BeginTransaction())
				{
					try
					{
						using (var command = new SqlCommand("update customers set companyname = 'alfred' where customerid = 'ALFKI'", connection))
						{
							await command.ExecuteNonQueryAsync();
						}
						using (var command = new SqlCommand("update customers set companyname = 'customer2' where customerid = 'AARON'", connection))
						{
							await command.ExecuteNonQueryAsync();
						}
						transaction.Commit();
					}
					catch (SqlException ex)
					{
						transaction.Rollback();
					}
				}
			}
		}

		private static async Task TransactionScope()
		{
			using (var scope = new TransactionScope())
			{
				using (var connection = new SqlConnection(connectionString))
				{
					using (var command = new SqlCommand("update customers set companyname = 'alfred' where customerid = 'ALFKI'", connection))
					{
						await command.ExecuteNonQueryAsync();
					}
					using (var command = new SqlCommand("update customers set companyname = 'customer2' where customerid = 'AARON'", connection))
					{
						await command.ExecuteNonQueryAsync();
					}

					scope.Complete();
				}
			}
		}
	}
}
