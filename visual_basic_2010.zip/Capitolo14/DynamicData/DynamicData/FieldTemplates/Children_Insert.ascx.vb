﻿Imports System.ComponentModel.DataAnnotations
Imports System.Web.DynamicData
Imports System.Web

Class Children_InsertField
    Inherits FieldTemplateUserControl

    
    
End Class
