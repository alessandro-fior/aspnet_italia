﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASPItalia.Books.Chapter4
{
    // specifica di C# >= 6
    public class PersonNew
    {
        public string FirstName { get; set; } = "Daniele";
        public string LastName { get; set; } = "Bochicchio";
        public int Age { get; set; } = 36;
        public bool IsActive { get; } = true;
        public string FullName => $"{FirstName} {LastName}";
    }

}
