using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace UserAdministration.Models.UserAdministrationViewModels
{
    public class UserAdministrationListViewModel {
        public string Id { get; set; }
        public string Email { get; set; }
        public bool LockedOut { get; set; }
    }
}