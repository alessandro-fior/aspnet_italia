﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Threading.Tasks;

namespace DemoSignalR.Hubs
{
    public class ChatHub : Hub
    {
        public void Send(string name, string message)
        {
            Clients.All.SendAsync("broadcastMessage", name, message);
        }

        public override Task OnConnectedAsync()
        {
            Clients.All.SendAsync("broadcastMessage", "system", $"{Context.ConnectionId} è entrato nella chat.");
            return base.OnConnectedAsync();
        }

        public override Task OnDisconnectedAsync(Exception exception)
        {
            Clients.All.SendAsync("broadcastMessage", "system", $"{Context.ConnectionId} è uscito dalla chat.");
            return base.OnDisconnectedAsync(exception);
        }
    }
}