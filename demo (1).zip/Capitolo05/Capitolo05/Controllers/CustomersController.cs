﻿using Capitolo05.Models;
using Capitolo05.Services;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace Capitolo05.Controllers
{
    public class CustomersController : Controller
    {
        private readonly IMyService myService;
        public CustomersController(IMyService myService)
        {
            this.myService = myService;
        }

        public IActionResult Index()
        {
            var model = myService.GetPeople();
            return View(model);
        }
        public IActionResult Search([FromServices]IMyService svc)
        {
            var model = svc.GetPeople();
            return View(model);
        }

        public IActionResult Find(int id)
        {
            Person person = myService.GetPeople().FirstOrDefault(x => x.ID == id);
            if (person == null)
                return NotFound();

            return View(person);
        }

        public IActionResult GetPerson(string firstName, string lastName)
        {
            var result = new Person
            {
                FirstName = firstName,
                LastName = lastName
            };

            return Json(result);
        }

        public Person GetPerson2(string firstName, string lastName)
        {
            return new Person
            {
                FirstName = firstName,
                LastName = lastName
            };
        }

        public IActionResult Details(int id)
        {
            return View(myService.GetPeople().FirstOrDefault(x => x.ID == id));
        }
    }
}