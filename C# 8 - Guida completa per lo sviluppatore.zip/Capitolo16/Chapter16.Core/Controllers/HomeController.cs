﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Chapter16.Core.Models;

namespace Chapter16.Core.Controllers
{
    public class HomeController : Controller
    {
        readonly StoreContext db;
        public HomeController(StoreContext db)
        {
            this.db = db;
        }

        public async Task<IActionResult> Index()
        {
            // EF Core ha bisogno che il database venga creato esplicitamente
            _ = await db.Database.EnsureCreatedAsync();

            var customers = db.Customers.OrderBy(f => f.Id).Take(5);
            return View(customers.ToList());
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
