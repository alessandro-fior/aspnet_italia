﻿using System;

namespace Capitolo7.Scenarios
{
    public static class Scenario2
    {
        /// <summary>
        /// Esempio 7.3
        /// </summary>
        public static void Run()
        {
            try
            {
                var result = Division(5, 0);

                // Questo codice non viene mai eseguito
                Console.WriteLine($"Il risultato è {result}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Si è verificato un errore.Dettagli: {ex.Message}");
            }
        }

        public static int Division(int a, int b)
        {
            int result = a / b;

            // in caso di errore questo codice non viene mai eseguito
            Console.WriteLine("Risultato calcolato con successo");
            return result;
        }
    }
}