﻿Imports System.Linq
Imports System.Xml.XPath



Public Class Sample19

    Public Shared Sub Run()

        Dim doc As New XPathDocument("test.xml")
        Dim navigator = doc.CreateNavigator()
        ' Navigo sulla root <products>
        navigator.MoveToFirstChild()
        ' Navigo sul primo <product>
        navigator.MoveToChild("product", "http://schemas.aspitalia.com/book40/products")
        ' Mi sposto sull'attributo della categoria
        navigator.MoveToAttribute("idCategory", "")
        ' Leggo il valore
        Dim idCategory As Integer = navigator.ValueAsInt

        Console.WriteLine(idCategory)
    End Sub

End Class
