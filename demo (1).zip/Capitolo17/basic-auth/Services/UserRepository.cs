using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BasicAuth.Models;

namespace BasicAuth.Services
{
    //Questa classe attinge l'elenco degli utenti da un oggetto in memoria
    //ed è utilizzata in questo esempio come segnaposto di un vero repository
    //che estae i dati degli utenti da un database o altro tipo di storage persistente

    //Il servizio viene registrato nella classe Startup, al metodo ConfigureServices
    public class UserRepository : IUserRepository
    {
        public User FindByCredentials(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password)) {
                return null;
            }

            return users.Value.SingleOrDefault(user => user.Username == username && user.Password == password);
        }

        //Questo è l'oggetto in memoria che restituisce la lista di utenti
        private static Lazy<List<User>> users = new Lazy<List<User>>(() =>
        {
            return new List<User> {
                new User { Username = "admin", Password = "password", Role = "Administrator", DateOfBirth = new DateTime(1992, 10, 9), FavoriteColor="Blu" },
                new User { Username = "customer1", Password = "password", Role = "Customer", DateOfBirth = new DateTime(2006, 1, 17), FavoriteColor="Rosso" }
            };
        });
    }
}