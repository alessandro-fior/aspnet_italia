﻿using System;
using System.Collections.Generic;
using System.Globalization;
using static System.Console;

namespace Localizzazione
{
    class Program
    {
        static void Main(string[] args)
        {
            // aggiungo un elenco di culture supportate dall'applicazione
            var cultures = new List<CultureInfo>
            {
                new CultureInfo("en-US"), // lingua inglese parlata in America
                new CultureInfo("it-IT"), // lingua italiana parlata in Italia
                new CultureInfo("fi-FI"), // lingua finlandese parlata in Finlandia
            };

            // scorro l'elenco delle culture
            foreach (var culture in cultures)
            {
                // assegno la cultura corrente sia alla Current che alla CurrentUI
                CultureInfo.CurrentCulture = culture;
                CultureInfo.CurrentUICulture = culture;

                // mostro i dettagli della cultura corrente
                DisplayCurrentCulture();

                // mostra la catena di culture
                DisplayCurrentHierarchy();

                // somma di numeri
                SumNumbers();

                // formattazione delle date
                FormatDates();

                // ordinamento di valori
                SortArray();

                WriteLine("****************");
            }

            Console.ReadKey();
        }

        static void DisplayCurrentCulture()
        {
            WriteLine($"CurrentCulture: {CultureInfo.CurrentCulture}");
            WriteLine($"CurrentUICulture: {CultureInfo.CurrentCulture}");
            WriteLine($"Nome: {CultureInfo.CurrentCulture.Name}");
            WriteLine($"Nome completo: {CultureInfo.CurrentCulture.DisplayName}");
        }

        static void DisplayCurrentHierarchy()
        {
            // viene recuperata la cultura corrente
            var currentCulture = CultureInfo.CurrentCulture;

            // si cicla fino ad ottenere la InvariantCulture
            while (currentCulture != CultureInfo.InvariantCulture)
            {
                WriteLine($"CurrentCulture: {currentCulture}");
                WriteLine($"Parent: {currentCulture.Parent}");
                WriteLine($"IsNeutral: {currentCulture.IsNeutralCulture}");

                // si sale la catena delle culture tramite il padre fino alla InvariantCulture
                currentCulture = currentCulture.Parent;
            }

            WriteLine($"Raggiunta la {nameof(CultureInfo.InvariantCulture)}");
        }

        static void SumNumbers()
        {
            var numberAsString = "10,500";
            var numberAsDecimal = decimal.Parse(numberAsString) + 1;
            // FIX: decimal.Parse(numberAsString, new CultureInfo("it")) + 1; 

            WriteLine($"{numberAsString} + 1 = {numberAsDecimal:C}");
        }

        static void FormatDates()
        {
            var dateAsString = "13.01.2018";
            var dateAsDate = DateTime.MinValue;
            var hasParsed =  DateTime.TryParse(dateAsString, out dateAsDate); // FIX: DateTime.TryParse(dateAsString, new CultureInfo("it"), DateTimeStyles.None, out dateAsDate);

            if (hasParsed)
                WriteLine($"La data parsata è: {dateAsDate:D}");
            else
                WriteLine("Non è stato possibile fare il parsing della data.");
        }

        static void SortArray()
        {
            var cities = new string[] { "Washington", "Virginia" };
            Array.Sort(cities); // FIX: Array.Sort(cities, StringComparer.InvariantCulture);

            WriteLine($"Città ordinate per nome: {string.Join(", ", cities)}");
        }
    }
}