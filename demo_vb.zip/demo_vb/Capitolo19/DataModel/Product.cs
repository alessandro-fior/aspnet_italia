﻿namespace DataModel
{
	public class Product
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public double Price { get; set; }
		public string Category { get; set; }

		public new string ToString()
		{
			return string.Format("{0}\n{1}\n{2}\n{3}", Id, Name, Category, Price);
		}
	}
}
