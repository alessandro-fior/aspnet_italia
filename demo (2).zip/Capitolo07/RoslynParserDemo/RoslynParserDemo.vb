﻿Imports Microsoft.CodeAnalysis
Imports Microsoft.CodeAnalysis.VisualBasic

Module RoslynParserDemo

    Sub Main(args As String())
        Dim SyntaxTree = VisualBasicSyntaxTree.ParseText("
Public Class Test
  Public Property MyProperty As String
End Class")

        Dim root = SyntaxTree.GetRoot()
        Dim Nodes = root.DescendantNodes()

    End Sub

End Module
