﻿
Partial Class _07_EntityDataSourceaspx
    Inherits System.Web.UI.Page

End Class
