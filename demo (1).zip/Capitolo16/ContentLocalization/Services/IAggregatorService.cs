﻿namespace ContentLocalization.Services
{
    public interface IAggregatorService
    {
        string GetAllKeys();
    }
}