﻿document.addEventListener('DOMContentLoaded', function () {

    // recupero il messaggio che voglio inviare
    var messageInput = document.getElementById('message');

    // chiedo all'utente il suo nome (utilizzato nella chat).
    var name = prompt('Inserisci il tuo nome:', '');
    messageInput.focus();

    // apro la connessione sul ChatHub
    startConnection('/chat', function (connection) {

        // creo la funzione 'broadcastMessage' invocata dal 'ChatHub'
        connection.on('broadcastMessage', function (name, message) {

            // aggiungo il messaggio come parte dell'elemento 'discussion'
            var liElement = document.createElement('li');
            liElement.innerHTML = '<strong>' + name + '</strong>:&nbsp;&nbsp;' + message;
            document.getElementById('discussion').appendChild(liElement);
        });
    }).then(function (connection) {

        console.log('connection started');

        // recupero il click del pulsante per inviare il messaggio
        document.getElementById('sendmessage').addEventListener('click', function (event) {

            // chiamo il metodo 'Send' all'interno del 'ChatHub'
            connection.invoke('send', name, messageInput.value);

            // resetto i valori di input
            messageInput.value = '';
            messageInput.focus();
            event.preventDefault();
        });
    }).catch(error => {
        console.error(error.message);
    });

    // avvia la connessione tramite websocket
    // se non funziona prova tramite serverSentEvents
    // se non funziona prova tramite long polling,
    // se non funziona rifiuta la connessione
    function startConnection(url, configureConnection) {
        return function start(transport) {

            console.log(`Starting connection using ${signalR.TransportType[transport]} transport`);

            var connection = new signalR.HubConnection(url, { transport: transport });

            if (configureConnection && typeof configureConnection === 'function') {
                configureConnection(connection);
            }

            return connection.start()
                .then(function () {
                    return connection;
                })
                .catch(function (error) {
                    console.log(`Cannot start the connection use ${signalR.TransportType[transport]} transport. ${error.message}`);
                    if (transport !== signalR.TransportType.LongPolling) {
                        return start(transport + 1);
                    }

                    return Promise.reject(error);
                });
        }(signalR.TransportType.WebSockets);
    }
});