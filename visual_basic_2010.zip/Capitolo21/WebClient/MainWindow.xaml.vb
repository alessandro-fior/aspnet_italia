﻿Imports System.Net
Imports System.IO
Imports System.Text

Class MainWindow
  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button1.Click
    Dim client As WebClient = New WebClient()
    Dim dataStream As Stream = client.OpenRead( _
      New UriBuilder("http", "localhost", 1503, TextBox1.Text).Uri)
    Dim reader As StreamReader = New StreamReader(dataStream)
    Dim data As String = reader.ReadToEnd()
    TextBox2.Text = data
  End Sub

  Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button2.Click
    Dim client As WebClient = New WebClient()
    Dim dataToSend As Byte() = Encoding.ASCII.GetBytes(TextBox2.Text)

    Dim dataStream As Stream = client.OpenWrite( _
      String.Format("C:\{0}", TextBox1.Text))

    Dim str As StreamWriter = New StreamWriter(dataStream)
    str.Write(TextBox2.Text)
    str.Close()
    dataStream.Close()
  End Sub
End Class

