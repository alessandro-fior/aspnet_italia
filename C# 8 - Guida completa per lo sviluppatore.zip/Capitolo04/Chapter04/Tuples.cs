﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPItalia.Books.Chapter4
{
    class Tuples
    {
        void Sample_4_28()
        {
            var unnamed = ("a", "b");                    // valori in .Item1, .Item2
            var named = (first: "a", second: "b");       // valori in .first, .second

            var a = "a";
            var b = "b";
            var c = (a, b);                              // valori in .a, .b
            var d = (e: a, f: b);                        // valori in .e, .f
        }

        void Sample_4_29()
        {
            var first = (a: "a", b: "b");
            var second = (a: "a", b: "b");
            bool result = first == second; // true

            // lifted conversion
            (string a, string b)? nullableTuple = second;
            bool result2 = first == nullableTuple; // true

            // altre conversioni implicite
            var a = (first: 5, second: 4);
            (long a, long b) b = (first: 5, second: 4);
            bool result3 = a == b; // true 
        }

        void Sample_4_30()
        {
            static (string[] Results, int Count) GetPagedData(int pageIndex)
            {
                var data = new[] { "a", "b", "c", "d", "e", "f", "g" };
                var results = new[] { data[0], data[1], data[2] }; // finta paginazione
                return (results, data.Length);
            }

            // esempio di utilizzo "classico"
            var data = GetPagedData(0);
            var countFromData = data.Count;
            var dataFromData = data.Results;

            // esempio di utilizzo con deconstruction
            var (results, count) = GetPagedData(0);
        }
    }
}
