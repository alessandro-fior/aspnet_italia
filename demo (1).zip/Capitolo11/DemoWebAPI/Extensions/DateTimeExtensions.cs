﻿using System;

namespace DemoWebAPI.Extensions
{
    public static class DateTimeExtensions
    {
        /// <summary>
        /// Recupera l'età a partire dalla data di nascita
        /// </summary>
        /// <param name="dateOfBirth">Data di nascita</param>
        /// <returns>L'età calcolata a partire dalla data di nascita</returns>
        public static int GetAge(this DateTimeOffset dateOfBirth)
        {
            var currentDate = DateTime.UtcNow;
            var age = currentDate.Year - dateOfBirth.Year;

            if (currentDate < dateOfBirth.AddYears(age))
                age--;

            return age;
        }
    }
}