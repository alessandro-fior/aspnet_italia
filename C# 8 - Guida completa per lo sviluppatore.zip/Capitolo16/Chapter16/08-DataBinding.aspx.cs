﻿using Chapter16.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.ModelBinding;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Chapter16
{
    public partial class _08_DataBinding : System.Web.UI.Page
    {
        NorthwindContext db = new NorthwindContext();

        public IQueryable<Customer> GetCustomers([QueryString("n")] string name)
        {
            var customers = db.Customers.AsQueryable();

            if (!String.IsNullOrEmpty(name))
                customers = customers.Where(f => f.CompanyName.Contains(name));

            return customers;
        }

        public void UpdateCustomer(Customer c)
        {
            // opzione 1: prendiamo il dato dal db e applichiamo le differenze
            var dbItem = db.Customers.First(x => x.ID == c.ID);
            TryUpdateModel<Customer>(dbItem);
            // opzione 2: segniamo tutto come modificato
            //db.Entry(c).State = EntityState.Modified;
            db.SaveChanges();
        }

        public override void Dispose()
        {
            if (db != null)
                db.Dispose();

            base.Dispose();
        }
    }
}