﻿Namespace Aspitalia.Books.Chapter4

    ' Classe astratta che implementa un'interfaccia
    Public MustInherit Class Person
        Implements IWritable

        Private _fullName As String         ' Nome completo
        Private _age As Integer             ' Età

        ' Proprietà
        Public Property FullName() As String
            Get
                Return _fullName
            End Get
            Set(ByVal value As String)
                _fullName = value
            End Set
        End Property

        ' Proprietà
        Public Property Age() As Integer
            Get
                Return _age
            End Get
            Set(ByVal value As Integer)
                _age = value
            End Set
        End Property

        ' Costruttore di default
        Public Sub New()
            _fullName = String.Empty
            _age = 18
        End Sub

        ' Costruttore con parametri
        Public Sub New(ByVal name As String, ByVal age As Integer)
            _fullName = name
            _age = age
        End Sub

        ' Metodo virtuale
        Public Overridable Function GetFirstName() As String
            Return Me._fullName.Split(" "c)(0)
        End Function

        ' Metodo astratto (è il metodo definito nell'interfaccia)
        Public MustOverride Sub Print() Implements IWritable.Write

        ' Override del metodo ToString di Object
        Public Overrides Function ToString() As String
            Return FullName
        End Function

    End Class

End Namespace

