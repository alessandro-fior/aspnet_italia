﻿using System;
using static Capitolo6.Scenarios.Scenario2;
using static Capitolo6.Scenarios.Scenario3;

namespace Capitolo6.Scenarios
{
    public static class Scenario5
    {
        /// <summary>
        /// Esempio 6.6
        /// </summary>
        public static void Run()
        {
            var writer = new FileLogWriter(@"c:\somefile.txt");
            var fileDelegate = new StringLogWriter(writer.Write);
            var consoleDelegate = new StringLogWriter(ConsoleWriter);

            StringLogWriter combinedDelegate = (StringLogWriter)Delegate.Combine(consoleDelegate, fileDelegate);

            foreach (Delegate item in combinedDelegate.GetInvocationList())
            {
                Console.WriteLine(item.Method);
            }
            
            combinedDelegate = (StringLogWriter)Delegate.Remove(combinedDelegate, fileDelegate);
            
            Console.WriteLine("\r\nDopo la rimozione:");
            
            foreach (Delegate item in combinedDelegate.GetInvocationList())
            {
                Console.WriteLine(item.Method);
            }
        }
    }
}