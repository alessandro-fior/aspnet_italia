﻿namespace Aspitalia.Books.Chapter4
{
    public static class Extensions
    {
        public static bool IsNull(this string value)
        {
            return value == null;
        }
    }
}
