﻿using System;
using System.Collections.Generic;

namespace Capitolo6.Scenarios
{
    public static class Scenario1
    {
        /// <summary>
        /// Esempio 6.1
        /// </summary>
        public static void Run()
        {
            var strings = new List<string>();
            strings.Add("This is a test");
            strings.Add("abcdefgh");
            strings.Add("a1234567");

            // Utilizzo del predicate come argomento di Find
            var foundString = strings.Find(FindStringsWithA);
            
            // Stampa abcdefgh sulla console
            Console.WriteLine(foundString);
        }

        private static bool FindStringsWithA(string item)
        {
            return item.StartsWith("a");
        }
    }
}