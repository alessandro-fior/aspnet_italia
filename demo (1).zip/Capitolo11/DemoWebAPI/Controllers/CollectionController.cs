﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using DemoWebAPI.Models;
using DemoWebAPI.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DemoWebAPI.Controllers
{
    [Route("api/customerscollection")]
    public class CollectionController : Controller
    {
        private readonly ICustomerRepository customerRepository;

        /// <summary>
        /// Crea una nuova istanza della classe <see cref="DemoWebAPI.Controllers.CollectionController" />
        /// </summary>
        /// <param name="customerRepository">Il repository per recuperare i clienti</param>
        public CollectionController(ICustomerRepository customerRepository)
        {
            this.customerRepository = customerRepository;
        }

        /// <summary>
        /// Crea una collezione di clienti
        /// </summary>
        /// <param name="customers">L'elenco dei clienti da aggiungere</param>
        /// <returns>N/A</returns>
        [HttpPost]
        public IActionResult CreateCustomerCollection([FromBody] IEnumerable<CustomerForCreate> customers)
        {
            if (customers == null || !customers.Any())
                return BadRequest();

            var mappedCustomer = Mapper.Map<IEnumerable<Customer>>(customers);
            customerRepository.AddCustomers(mappedCustomer);

            if (!customerRepository.SaveChanges())
                return StatusCode(StatusCodes.Status500InternalServerError, "Impossibile salvare le modifiche.");

            return StatusCode(StatusCodes.Status201Created);
        }
    }
}