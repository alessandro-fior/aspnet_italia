﻿Imports NorthwindModel

Partial Class _06_Repeater
	Inherits System.Web.UI.Page


	Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
		Using entities = New NorthwindEntities()
			Dim customers = entities.Customers.OrderBy(Function(c As Customer) c.CompanyName)
			CustomerView.DataSource = customers
			CustomerView.DataBind()
		End Using
	End Sub
End Class
