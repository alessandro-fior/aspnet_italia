﻿using System;

namespace Capitolo7.Scenarios
{
    public static class Scenario13
    {
        /// <summary>
        /// Esempio 7.21
        /// </summary>
        public static void Run()
        {
            // Creazione di un'istanza di Person
            Type personType = Type.GetType("Capitolo7.Scenarios.Scenario12+Person");
            dynamic person = Activator.CreateInstance(personType);
            person.Name = "Matteo Tumiati";
            person.Age = 28;

            // Visualizziamo su Console il risultato di Person.ToString()
            Console.WriteLine(person.ToString());
        }

        public class Person
        {
            public string Name { get; set; }
            public int Age { get; set; }

            public override string ToString() => $"{Name} ha {Age} anni";
        }
    }
}