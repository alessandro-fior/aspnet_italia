﻿Imports System
Imports System.IO
Imports System.Text
Imports System.IO.IsolatedStorage

Module Module1
    Sub Main()
        Try
            Dim isoFile As IsolatedStorageFile = IsolatedStorageFile.GetStore(IsolatedStorageScope.User Or IsolatedStorageScope.Assembly Or IsolatedStorageScope.Domain, GetType(System.Security.Policy.Url), GetType(System.Security.Policy.Url))
            If Not isoFile.DirectoryExists("Documenti") Then
                isoFile.CreateDirectory("Documenti")
            End If
            Dim isoStream As IsolatedStorageFileStream = isoFile.CreateFile("myFile.txt")
            Dim info As Byte() = New UTF8Encoding(True).GetBytes("Un saluto dall'autore di questo capitolo.")
            isoStream.Write(info, 0, info.Length)
            isoStream.Close()
            Dim mySteamiReader As StreamReader = New StreamReader(isoFile.OpenFile("myFile.txt", FileMode.Open))
            Do While mySteamiReader.Peek() >= 0
                Console.WriteLine("il file contiene: {0}", mySteamiReader.ReadLine())
            Loop
            mySteamiReader.Close()
        Catch ex As Exception
            Console.WriteLine("Si è verificato un errore: {0}", ex.ToString())
        End Try
        Console.ReadLine()
    End Sub
End Module
