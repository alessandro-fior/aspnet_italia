﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserAdministration.Models;
using UserAdministration.Models.UserAdministrationViewModels;

namespace UserAdministration.Controllers
{
    public class HomeController : Controller
    {
        public async Task<IActionResult> Index([FromServices] UserManager<ApplicationUser> userManager)
        {
            var administrators = await userManager.GetUsersForClaimAsync(new Claim(ClaimTypes.Role, "Administrator"));
            if (!administrators.Any())
            {
                //Non sono stati creati utenti, reindirizziamo alla creazione dell'amministratore
                return RedirectToAction(nameof(CreateAdministrator));
            }
            return View();
        }

        public IActionResult CreateAdministrator()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateAdministrator(
            CreateAdministratorViewModel model, 
            [FromServices] UserManager<ApplicationUser> userManager,
            [FromServices] SignInManager<ApplicationUser> signInManager)
        {
            if (!ModelState.IsValid) {
                return View(model);
            }

            var utente = await userManager.FindByEmailAsync(model.Email);
            if (utente != null) {
                ModelState.AddModelError("", "A user already exists with this email");
                return View(model);
            }

            var adminUser = new ApplicationUser
            {
                Email = model.Email,
                UserName = model.Email,
                EmailConfirmed = true,
                LockoutEnabled = true
            };
            var result = await userManager.CreateAsync(adminUser, model.Password);
            if (result.Succeeded)
            {
                //Aggiungiamo il claim per il ruolo amministratore
                await userManager.AddClaimAsync(adminUser, new Claim(ClaimTypes.Role, "Administrator"));
                //Ci logghiamo con l'amministratore appena creato
                await signInManager.SignInAsync(adminUser, true, CookieAuthenticationDefaults.AuthenticationScheme);
                return RedirectToAction(nameof(Index));
            }

            foreach (var error in result.Errors) {
                ModelState.AddModelError("", error.Code);
            }
            return View(model);
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
