﻿function refreshClock()
{    
    var time = new Date();
    var h = time.getHours();
    var m = time.getMinutes();
    var s = time.getSeconds();

    var r = parseInt(h / 24 * 255, 10);
    var g = parseInt(m / 60 * 255, 10);
    var b = parseInt(s / 60 * 255, 10);
    
    document.getElementById("h").innerHTML = padDigit(h);
    document.getElementById("m").innerHTML = padDigit(m);
    document.getElementById("s").innerHTML = padDigit(s);

    var background = "#" + padDigit(r.toString(16)) + padDigit(g.toString(16)) + padDigit(b.toString(16));

    document.body.style.backgroundColor = background;
        
    document.getElementById("debug").style.borderColor = background;
    document.getElementById("debug").innerHTML = "Status: <b>" + ((navigator.onLine) ? "Online" : "Offline") + "</b> - R:" + r + ", G:" + g + ", B:" + b + " / " + background;
    
    window.setTimeout(refreshClock, 1000);
};
function padDigit(d)
{
    return(d.toString().length == 1) ? "0" + d : d;
};

window.onload = refreshClock;
