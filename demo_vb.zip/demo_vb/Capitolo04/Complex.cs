﻿namespace ASPItalia.Books.Chapter4
{
    // Definizione di una struttura per i numeri complessi
    public struct Complex
    {
        public float Real { get; set; }     // Parte reale
        public float Imaginary { get; set; } // Parte immaginaria

        // Costruttore con parametri
        public Complex(float r, float i)
            : this()
        {
            this.Real = r;
            this.Imaginary = i;
        }

        // Metodo statico per la somma di due numeri complessi
        public static Complex Sum(Complex x, Complex y)
        {
            return new Complex(x.Real + y.Real, x.Imaginary + y.Imaginary);
        }
    }
}
