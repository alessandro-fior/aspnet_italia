﻿Imports System.Net.Http
Imports System.Net
Imports System.IO
Imports System.Threading.Tasks
Imports System.Threading

Module AsyncAwait

    ' ***************************************************************************************************
    ' Esempio 09.25
    ' ***************************************************************************************************

    Public Sub Download()

        Console.WriteLine("---- Download ----")

        Dim client As WebRequest = HttpWebRequest.Create("http://www.google.com")
        Dim response = client.GetResponse()

        Using reader As New StreamReader(response.GetResponseStream)
            ' esecuzione sincrona della richiesta
            Dim result = reader.ReadToEnd()

            Console.WriteLine(result)
        End Using

    End Sub

    ' ***************************************************************************************************
    ' Esempio 09.26
    ' ***************************************************************************************************

    Public Async Function DownloadAsync() As Task

        Console.WriteLine("---- DownloadAsync ----")

        Dim client As WebRequest = HttpWebRequest.Create("http://www.google.com")
        Dim response = client.GetResponse()

        Using reader As New StreamReader(response.GetResponseStream)
            ' esecuzione asincrona della richiesta
            Dim result = Await reader.ReadToEndAsync()

            Console.WriteLine(result)
        End Using
    End Function

    ' ***************************************************************************************************
    ' Esempio 09.27
    ' ***************************************************************************************************

    Public Async Function SequentialOperations() As Task

        Console.WriteLine("---- SequentialOperations ----")

        Dim client As New HttpClient()

        Dim firstResult = Await client.GetStringAsync("http://www.google.com")
        Console.WriteLine(firstResult)

        Dim secondResult = Await client.GetStringAsync("http://www.yahoo.com")
        Console.WriteLine(secondResult)

        Dim thirdResult = Await client.GetStringAsync("http://www.bing.com")
        Console.WriteLine(thirdResult)

    End Function

    ' ***************************************************************************************************
    ' Esempio 09.28
    ' ***************************************************************************************************

    Public Async Function ParallelOperations() As Task

        Console.WriteLine("---- ParallelOperations ----")

        Dim client As New HttpClient()

        Dim tasks As New List(Of Task(Of String)) From {
            client.GetStringAsync("http://www.google.com"),
            client.GetStringAsync("http://www.yahoo.com"),
            client.GetStringAsync("http://www.bing.com")
            }

        Await Task.WhenAll(tasks)

        For Each task In tasks
            Console.WriteLine(task.Result)
        Next

    End Function

    ' ***************************************************************************************************
    ' Esempio 09.29
    ' ***************************************************************************************************

    Public Function SomeMethodAsync() As Task(Of String)
        Return task.Run(Function() SomeMethod())
    End Function

    Public Function SomeMethod() As String
        ' codice qui...
        Thread.Sleep(3000)

        Return "test"
    End Function

    Public Async Sub Execute()

        AsyncAwait.Download()
        Await AsyncAwait.DownloadAsync()
        Await AsyncAwait.SequentialOperations()
        Await AsyncAwait.ParallelOperations()

        Dim result = Await SomeMethodAsync()

        Console.WriteLine(result)

    End Sub

End Module
