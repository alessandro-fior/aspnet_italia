﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPItalia.Books.Chapter07
{
    public class DisposableObject : IDisposable
    {
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // qui si liberano le risorse gestite
            }

            // qui si liberano le risorse non gestite
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        ~DisposableObject()
        {
            this.Dispose(false);
        }

        internal void SomeMethod()
        {
        }
    }

}
