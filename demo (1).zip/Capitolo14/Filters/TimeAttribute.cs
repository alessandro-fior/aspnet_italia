﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.DependencyInjection;

namespace Capitolo14.Filters
{
    public class TimeAttribute : ActionFilterAttribute
    {
        public int Hour { get; set; } = 6;

        public TimeAttribute()
        {
            
        }

        public TimeAttribute(int hour)
        {
            Hour = hour;
        }

        //public override Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        //{
        //    bool anonymous = !context.HttpContext.User.Identity.IsAuthenticated;
        //    bool outOfTime = DateTime.Now.Hour < Hour;

        //    if (anonymous && outOfTime)
        //    {
        //        context.Result = new ViewResult { ViewName = "OutOfTime" };
        //        return Task.CompletedTask;
        //    }

        //    // Chiamo il prossimo filtro o l'esecuzione della action
        //    return next();
        //}

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            bool anonymous = !context.HttpContext.User.Identity.IsAuthenticated;
            bool outOfTime = DateTime.Now.Hour < Hour;

            if (anonymous && outOfTime)
            {
                context.Result = new ViewResult { ViewName = "OutOfTime" };
            }
        }
    }
}
