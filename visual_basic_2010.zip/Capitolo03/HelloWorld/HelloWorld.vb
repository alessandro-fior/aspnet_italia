﻿Namespace ASPItalia.Books.Chapter3

    Module HelloWorld

        Sub Main()

            ' Scrive "Hello World" a video
            Console.WriteLine("Hello World")
            Console.ReadLine()

        End Sub

    End Module

End Namespace
