﻿using System;
using static Capitolo6.Scenarios.Scenario2;

namespace Capitolo6.Scenarios
{
    public static class Scenario3
    {
        /// <summary>
        /// Esempio 6.4
        /// </summary>
        public static void Run()
        {
            var writer = new FileLogWriter(@"c:\somefile.txt");
            var writerDelegate = new StringLogWriter(writer.Write);

            Console.WriteLine(writerDelegate.Method);
            Console.WriteLine(((FileLogWriter)writerDelegate.Target).FileName);
        }

        public class FileLogWriter
        {
            public string FileName { get; set; }

            public FileLogWriter(string filename)
            {
                this.FileName = filename;
            }

            public void Write(DateTime timestamp, string message)
            {
                // Scrittura messaggio su file...
            }
        }
    }
}