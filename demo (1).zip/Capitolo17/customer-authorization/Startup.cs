﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CustomerAuthorization.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using CustomerAuthorization.Authorization;
using CustomerAuthorization.Models;
using System.Security.Claims;
using CustomerAuthorization.Models.Entities;
using CustomerAuthorization.Services;
using Microsoft.AspNetCore.Authorization;

namespace CustomerAuthorization
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlite(Configuration.GetConnectionString("DefaultConnection")));

            services.AddDefaultIdentity<ApplicationUser>()
                .AddEntityFrameworkStores<ApplicationDbContext>();

            services.AddMvc();
            services.AddTransient<IEmailSender, EmailSender>();
            //services.AddTransient<MinimumPurchaseAuthorizationHandler>();
            //services.AddTransient<SelfOrRoleAuthorizationHandler>();
            services.AddSingleton<IAuthorizationHandler, SelfOrRoleAuthorizationHandler>();
            services.AddScoped<IAuthorizationHandler, MinimumPurchaseAuthorizationHandler>();
            services.AddAuthorization(options =>
            {
                options.AddPolicy("VipCustomers", policy =>
                {
                    //Aggiungiamo il requirement di un importo minimo acquistato
                    policy.Requirements.Add(
                       new MinimumPurchaseRequirement(minimum: 1000)
                    );
                });
                options.AddPolicy("JustForCustomer1", policy =>
                {
                    //Aggiungiamo il requirement di un importo minimo acquistato
                    policy.RequireClaim("Tenant", "Customer1");
                });
                options.AddPolicy("SelfOrAdministrator", policy => {
                    policy.Requirements.Add(new SelfOrRoleRequirement("Administrator"));
                });
            });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(
            IApplicationBuilder app,
            IHostingEnvironment env,
            IApplicationLifetime applicationLifetime,
            IServiceProvider serviceProvider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
