﻿Namespace Aspitalia.Books.Chapter4

    Module Chapter4

        Sub Main()

            ' ****************************************************************************************************
            ' Esempio 4.11
            ' ****************************************************************************************************

            Dim point1 = New With {.X = 21, .Y = 10, .Z = 71}
            Dim point2 = New With {.X = 18, .Y = 8, .Z = 5}

            ' La seconda proprietà di point3 è di tipo String
            Dim point3 = New With {.X = 20, .Y = "1", .Z = 67}

            point1 = point2 ' Assegnazione valida (stesso tipo anonimo) 
            ' point1 = point3 ' Errore (type mismatch)

            ' ****************************************************************************************************
            ' Esempio 4.14
            ' ****************************************************************************************************

            Dim a As String = Nothing     ' Stringa nulla
            Dim b As Boolean = a.IsNull() ' y vale true

            ' ****************************************************************************************************
            ' Esempio 4.20
            ' ****************************************************************************************************

            Dim x As New Employee("Riccardo Golia", 38)
            Dim y As Person = x

            ' Viene comunque eseguito il metodo di Employee
            ' anche se il riferimento è di tipo Person
            Dim z As String = y.GetFirstName()

            ' ****************************************************************************************************
            ' Esempio 4.22
            ' ****************************************************************************************************

            ' Il riferimento è di tipo IWritable, ma l'istanza è di tipo Employee
            Dim x1 As IWritable = New Employee("Riccardo Golia", 38)

            ' Scrive sulla console il nome completo
            x1.Write()

            ' È necessario effettuare il casting per invocare il metodo
            Dim y1 As String = DirectCast(x1, Employee).GetFirstName()

            ' ****************************************************************************************************
            ' Esempio 4.23
            ' ****************************************************************************************************

            Dim u As New Complex()         ' Il numero complesso vale 0.0 + 0.0i
            Dim v As New Complex(1.0, 2.0) ' Il numero complesso vale 1.0 + 2.0i

            Console.ReadLine()

        End Sub

    End Module

End Namespace
