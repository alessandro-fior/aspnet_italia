﻿using System;
using System.IO;

namespace Capitolo7.Scenarios
{
    public static class Scenario5
    {
        /// <summary>
        /// Esempio 7.6, 7.7
        /// </summary>
        public static void Run()
        {
            StreamReader sr = null;

            try
            {
                sr = new StreamReader(@"file-inesistente.txt");
                string content = sr.ReadToEnd();
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine("Errore di I/O:\r\n{0}", ex);
            }
            finally
            {
                if (sr != null)
                    sr.Close();
            }
        }
    }
}