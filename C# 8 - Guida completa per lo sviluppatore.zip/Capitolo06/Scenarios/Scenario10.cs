﻿using System;

namespace Capitolo6.Scenarios
{
    public static class Scenario10
    {
        /// <summary>
        /// Esempio 6.14, 6.15
        /// </summary>
        public static void Run()
        {
            receiver = new PortReceiver();
            receiver.Subscribe(DataReceived);
        }

        private static PortReceiver receiver;
        
        private static void DataReceived()
        {
            Console.WriteLine(receiver.Data);
        }

        public class PortReceiver
        {
            public delegate void DataReceivedCallback();
            private DataReceivedCallback callback;

            public void Subscribe(DataReceivedCallback callback)
            {
                this.callback = callback;
            }
            
            public string Data { get; set; }
            
            public void ReceiveData()
            {
                this.Data = "Data received";
                if (this.callback != null)
                    this.callback();
            }
        }
    }
}