﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ASPItalia.Books.Chapter07
{
    [Serializable]
    public class InvalidCustomerException : ApplicationException
    {
        public Customer Customer { get; set; }

        public InvalidCustomerException(Customer customer)
            : this(customer, "Customer is invalid")
        { }

        public InvalidCustomerException(Customer customer, string message)
            : base(message)
        {
            this.Customer = customer;
        }

        public InvalidCustomerException(Customer customer, string message,
                                        Exception innerException)
            : base(message, innerException)
        {
            this.Customer = customer;
        }

        public InvalidCustomerException(SerializationInfo info,
                                        StreamingContext context)
            : base(info, context)
        { }
    }

}
