using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace BasicAuth.Middlewares {
    //Questo middleware ha il solo scopo di produrre un contenuto di esempio
    //che mostra come leggere i valori dei claim dalla ClaimsPrincipal
    //allegata alla richiesta corrente
    public class ContentMiddleware {

        public ContentMiddleware (RequestDelegate next) {
        }
        public async Task InvokeAsync(HttpContext context)
        {
            //context.User è la nostra ClaimsPrincipal
            //Otteniamo la ClaimsIdentity dalla sua proprietà Identity
            var identity = context.User.Identity as ClaimsIdentity;

            //Ora leggiamo i claims. Il nome è accessibile dalla proprietà Name
            var name = identity.Name;
            var role = identity.FindFirst(ClaimTypes.Role)?.Value;
            var dateOfBirth = identity.FindFirst(ClaimTypes.DateOfBirth)?.Value;
            var favoriteColor = identity.FindFirst("FavoriteColor")?.Value;

            //Componiamo il contenuto della risposta
            var sb = new StringBuilder();
            sb.AppendLine("<!DOCTYPE html><html><body>");
            sb.AppendLine($"Benvenuto {name}, il tuo ruolo &egrave; {role}.<br>");
            sb.AppendLine($"Sei nato il {dateOfBirth} e il tuo colore preferito &egrave; {favoriteColor}.<br>");

            //Solo per gli amministratori, stampiamo un'altra riga:
            if (role == "Administrator") {
                sb.AppendLine("Dato che sei un amministratore, puoi visualizzare anche questa informazione segreta:");
                sb.AppendLine("<strong>la risposta &egrave; 42</strong>.");
            }

            sb.AppendLine("</body></html>");
            await context.Response.WriteAsync(sb.ToString());
        }
    }
}