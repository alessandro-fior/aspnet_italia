namespace Capitolo08.Models
{
	public class HiddenViewModel
	{
		public int Id { get; set; }
	}
}