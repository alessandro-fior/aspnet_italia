﻿Imports Microsoft.Win32

Module Module1
    Sub Main()
        Dim registrykey As RegistryKey = Registry.LocalMachine
        registrykey = registrykey.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0")
        Dim value As Object = registrykey.GetValue("ProcessorNameString")
        Console.WriteLine("Il tuò processore è:" + value)
        Console.ReadLine()
    End Sub
End Module
