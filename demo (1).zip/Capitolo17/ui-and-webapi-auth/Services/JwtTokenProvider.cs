using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using UiAndApiAuth.Models.Configuration;

namespace UiAndApiAuth.Services {
    public class JwtTokenProvider : IJwtTokenProvider {
        private readonly IOptionsMonitor<JwtToken> tokenOptions;
        public JwtTokenProvider(IOptionsMonitor<JwtToken> tokenOptions)
        {
            this.tokenOptions = tokenOptions;
        }

        public TokenValidationParameters GetTokenValidationParameters() {
            return new TokenValidationParameters{
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = tokenOptions.CurrentValue.Issuer,
                    ValidAudience = tokenOptions.CurrentValue.Audience,
                    IssuerSigningKey = new SymmetricSecurityKey(
                        Encoding.UTF8.GetBytes(tokenOptions.CurrentValue.SigningKey)
                    ),
                    ClockSkew = tokenOptions.CurrentValue.ClockSkew
            };
        }

        public string CreateToken(ClaimsIdentity claimsIdentity) {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(tokenOptions.CurrentValue.SigningKey));
		    var creds = new SigningCredentials(key, tokenOptions.CurrentValue.Algorithm);
            var token = new JwtSecurityToken( issuer: tokenOptions.CurrentValue.Issuer,
                                              audience: tokenOptions.CurrentValue.Audience,
                                              claims: claimsIdentity.Claims,
                                			  expires: DateTime.Now.Add(tokenOptions.CurrentValue.Expiration),
                                			  signingCredentials: creds
                                              );
            var tokenHandler = new JwtSecurityTokenHandler();
            var serializedToken = tokenHandler.WriteToken(token);
            return serializedToken;
        }
    }
}