﻿namespace ASPItalia.Books.Chapter4
{
    // Interfaccia
    public interface IWritable
    {
        void Write();
    }
}
