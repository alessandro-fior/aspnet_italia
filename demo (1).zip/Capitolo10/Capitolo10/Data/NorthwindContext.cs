﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace Capitolo10.Data
{
	public partial class NorthwindContext : DbContext
	{
		public NorthwindContext(DbContextOptions<NorthwindContext> o) : base(o) { }

		public virtual DbSet<Customer> Customers { get; set; }
		public virtual DbSet<OrderDetail> OrderDetails { get; set; }
		public virtual DbSet<Order> Orders { get; set; }

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			optionsBuilder
				.ConfigureWarnings(warnings =>
					warnings.Throw(RelationalEventId.QueryClientEvaluationWarning));
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			//modelBuilder.Entity<AddressInfo>(entity =>
			//{
			//	entity.Property(e => e.City).HasMaxLength(15);
			//	entity.Property(e => e.Country).HasMaxLength(15);
			//	entity.Property(e => e.PostalCode).HasMaxLength(10);
			//	entity.Property(e => e.Region).HasMaxLength(15);
			//	entity.Property(e => e.Address).HasMaxLength(60);
			//});

			modelBuilder.Entity<Customer>(entity =>
			{
				entity.HasKey(e => e.CustomerId);
				entity.OwnsOne(e => e.Address).HasIndex(e => e.City).HasName("City");
				entity.HasIndex(e => e.CompanyName).HasName("CompanyName");
				entity.OwnsOne(e => e.Address).HasIndex(e => e.PostalCode).HasName("PostalCode");
				entity.OwnsOne(e => e.Address).HasIndex(e => e.Region).HasName("Region");
				entity.OwnsOne(e => e.Address).Property(e => e.Address).HasColumnName("Address");
				entity.OwnsOne(e => e.Address).Property(e => e.City).HasColumnName("City");
				entity.OwnsOne(e => e.Address).Property(e => e.Country).HasColumnName("Country");
				entity.OwnsOne(e => e.Address).Property(e => e.PostalCode).HasColumnName("PostalCode");
				entity.OwnsOne(e => e.Address).Property(e => e.Region).HasColumnName("Region");
				entity.Property(e => e.CustomerId)
						.HasColumnName("CustomerID")
						.HasColumnType("nchar(5)")
						.ValueGeneratedNever();

				entity.Property(e => e.CompanyName).IsRequired().HasMaxLength(40);

				entity.Property(e => e.ContactName).HasMaxLength(30);
				entity.Property(e => e.ContactTitle).HasMaxLength(30);
				entity.Property(e => e.Fax).HasMaxLength(24);
				entity.Property(e => e.Phone).HasMaxLength(24);
			});

			modelBuilder.Entity<OrderDetail>(entity =>
			{
				entity.HasKey(e => new { e.OrderId, e.ProductId });
				entity.ToTable("Order Details");
				entity.HasIndex(e => e.OrderId).HasName("OrdersOrder_Details");
				entity.HasIndex(e => e.ProductId).HasName("ProductsOrder_Details");
				entity.Property(e => e.OrderId).HasColumnName("OrderID");
				entity.Property(e => e.ProductId).HasColumnName("ProductID");
				entity.Property(e => e.Discount).HasDefaultValueSql("((0))");
				entity.Property(e => e.Quantity).HasDefaultValueSql("((1))");
				entity.Property(e => e.UnitPrice)
									.HasColumnType("money")
									.HasDefaultValueSql("((0))");

				entity.HasOne(d => d.Order)
									.WithMany(p => p.OrderDetails)
									.HasForeignKey(d => d.OrderId)
									.OnDelete(DeleteBehavior.ClientSetNull)
									.HasConstraintName("FK_Order_Details_Orders");
			});

			modelBuilder.Entity<Order>(entity =>
			{
				entity.HasKey(e => e.OrderId);
				entity.HasIndex(e => e.CustomerId).HasName("CustomersOrders");
				entity.HasIndex(e => e.EmployeeId).HasName("EmployeesOrders");
				entity.HasIndex(e => e.OrderDate).HasName("OrderDate");

				entity.OwnsOne(e => e.ShipAddress);
				entity.OwnsOne(e => e.ShipAddress).HasIndex(e => e.PostalCode).HasName("ShipPostalCode");
				entity.OwnsOne(e => e.ShipAddress).Property(e => e.Address).HasColumnName("ShipAddress");
				entity.OwnsOne(e => e.ShipAddress).Property(e => e.City).HasColumnName("ShipCity");
				entity.OwnsOne(e => e.ShipAddress).Property(e => e.Country).HasColumnName("ShipCountry");
				entity.OwnsOne(e => e.ShipAddress).Property(e => e.PostalCode).HasColumnName("ShipPostalCode");
				entity.OwnsOne(e => e.ShipAddress).Property(e => e.Region).HasColumnName("ShipRegion");

				entity.HasIndex(e => e.ShipVia).HasName("ShippersOrders");
				entity.HasIndex(e => e.ShippedDate).HasName("ShippedDate");
				entity.Property(e => e.OrderId).HasColumnName("OrderID");
				entity.Property(e => e.CustomerId)
									.HasColumnName("CustomerID")
									.HasColumnType("nchar(5)");

				entity.Property(e => e.EmployeeId).HasColumnName("EmployeeID");

				entity.Property(e => e.Freight)
									.HasColumnType("money")
									.HasDefaultValueSql("((0))");

				entity.Property(e => e.OrderDate).HasColumnType("datetime");
				entity.Property(e => e.RequiredDate).HasColumnType("datetime");
				entity.Property(e => e.ShipName).HasMaxLength(40);

				entity.Property(e => e.ShippedDate).HasColumnType("datetime");

				entity.HasOne(d => d.Customer)
									.WithMany(p => p.Orders)
									.HasForeignKey(d => d.CustomerId)
									.HasConstraintName("FK_Orders_Customers");
			});
		}
	}
}
