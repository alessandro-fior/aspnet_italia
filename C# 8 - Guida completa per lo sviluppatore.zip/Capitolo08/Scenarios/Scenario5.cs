﻿using System;
using System.Threading;

namespace Capitolo8.Scenarios
{
    public static class Scenario5
    {
        /// <summary>
        /// Esempio 8.5
        /// </summary>
        public static void Run()
        {
            var workerThread = new Thread(() =>
            {
                try
                {
                    Console.WriteLine("Inizio di un thread molto lungo");
                    Thread.Sleep(5000);
                    Console.WriteLine("Termine worker thread");
                }
                catch (ThreadAbortException ex)
                {
                    // qui codice per gestire l'eccezione
                }
            });

            workerThread.Start();
            workerThread.Join(500);
            
            // Se il worker thread è ancora in esecuzione lo si cancella
            if (workerThread.ThreadState != ThreadState.Stopped)
            {
                workerThread.Abort();
            }
            
            Console.WriteLine("Termine applicazione");
        }
    }
}