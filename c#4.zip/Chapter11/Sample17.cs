﻿using System.Linq;
using System.Xml.XPath;
using System.Xml;
using System;

public class Sample17
{

    public static void Run()
    {

        // Carico il documento
        XmlDocument doc = new XmlDocument();
        doc.Load("test.xml");

        // Creo il gestore dei namespace
        XmlNamespaceManager nsManager = new XmlNamespaceManager(doc.NameTable);
        // Associo il prefisso al namespace
        nsManager.AddNamespace("p", "http://schemas.aspitalia.com/book40/products");

        // Creo il navigatore sui XmlNode
        var navigator = doc.CreateNavigator();

        // Ricerco l'attributo
        navigator = navigator.SelectSingleNode("/p:products/p:product[1]/@idCategory", nsManager);
        navigator.SetValue("5");

        Console.WriteLine(navigator.ValueAsInt);
    }

}
