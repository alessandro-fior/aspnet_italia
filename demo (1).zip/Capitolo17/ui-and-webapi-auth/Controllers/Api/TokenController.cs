using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using UiAndApiAuth.Models;
using UiAndApiAuth.Models.Dto;

namespace UiAndApiAuth.Controllers
{
    [Route("api/[controller]")]
    public class TokenController : Controller
    {
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly UserManager<ApplicationUser> userManager;
        public TokenController(
            SignInManager<ApplicationUser> signInManager,
            UserManager<ApplicationUser> userManager)
        {
            this.signInManager = signInManager;
            this.userManager = userManager;
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] TokenRequest request)
        {
            if (!ModelState.IsValid) {
                return BadRequest();
            }
            var user = await userManager.FindByNameAsync(request.Username);
            if (user == null)
                return Unauthorized();

            var result = await signInManager.CheckPasswordSignInAsync(user, request.Password, lockoutOnFailure: false);
            if (!result.Succeeded)
                return Unauthorized();

            //Ci limitiamo a impostare la ClaimsPrincipal
            //Ci penserà poi il JwtTokenMiddleware (definito nella directory /Middlewares)
            //a creare il JWT Token e a inserirlo come intestazione della risposta
            var claimsPrincipal = await signInManager.CreateUserPrincipalAsync(user);
            var claimsIdentity = new ClaimsIdentity((claimsPrincipal.Identity as ClaimsIdentity).Claims, JwtBearerDefaults.AuthenticationScheme);
            claimsPrincipal = new ClaimsPrincipal(claimsIdentity);
            HttpContext.User = claimsPrincipal;
            return NoContent();
        }
    }
}