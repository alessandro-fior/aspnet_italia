﻿Imports System.Runtime.Serialization

Namespace ASPItalia.Books.Chapter07

    <Serializable()>
    Public Class InvalidCustomerException
        Inherits ApplicationException

        Public Property Customer As Customer

        Public Sub New(ByVal customer As Customer)
            Me.New(customer, "Customer is invalid")
        End Sub

        Public Sub New(ByVal customer As Customer, ByVal message As String)
            MyBase.New(message)
            Me.Customer = customer
        End Sub

        Public Sub New(ByVal customer As Customer, ByVal message As String,
                       ByVal innerException As Exception)
            MyBase.New(message, innerException)
            Me.Customer = customer
        End Sub

        Public Sub New(ByVal info As SerializationInfo,
                       ByVal context As StreamingContext)
            MyBase.New(info, context)
        End Sub
    End Class
End Namespace