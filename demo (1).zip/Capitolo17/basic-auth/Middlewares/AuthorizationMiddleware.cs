using System;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using BasicAuth.Models;
using BasicAuth.Services;

namespace BasicAuth.Middlewares
{
    public class AuthorizationMiddleware
    {
        private readonly RequestDelegate next;
        public AuthorizationMiddleware(RequestDelegate next)
        {
            this.next = next;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            //In questa applicazione dimostrativa, il middleware di autorizzazione bloccherà tutte le richieste
            //anonime, cioè quelle per cui non è stata creata una ClaimsPrincipal dal middleware di autenticazione
            if (!context.User.Identity.IsAuthenticated) {
                //Proteggiamo l'applicazione impedendo che la richiesta continui al prossimo middleware
                //Restituiamo all'utente lo status code 401 per indicare all'utente che non è autorizzato
                context.Response.StatusCode = (int) HttpStatusCode.Unauthorized; //401
            } else {
                //Altrimenti, la richiesta può proseguire
                //Eventualmente potremmo ispezionare i claims della ClaimsPrincipal
                //per attuare politiche di autorizzazione più complesse (es. in base al ruolo)
                await next.Invoke(context);
            }
        }
    }
}