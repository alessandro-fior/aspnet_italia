# Configurazione degli endpoint

Questa è un'applicazione ASP.NET Core minimale creata con il comando `dotnet new web`. Le porte in cui l'applicazione è in ascolto sono state configurate nel file [hosting.json](hosting.json).
  * Porta 5001 su tutte le interfacce di rete;
  * In aggiunta, porta 5555 sull'interfaccia di loopback (localhost).

È sufficiente avviare l'applicazione con il comando `dotnet run` e osservare l'output del comando per verificare che le impostazioni abbiano avuto effetto.

Il file [hosting.json](hosting.json) viene indicato come fonte di configurazione alla riga 26 di [Program.cs](Program.cs). Il vantaggio di tenere la configurazione su un file json esterno ci permette di apportare modifiche senza dover ricompilare l'applicazione.

# Esercizi
 * Impostare gli URL valorizzando la variabile d'ambiente ASPNETCORE_URLS e poi riavviare l'applicazione. Notare come il valore della variabile d'ambiente abbia la priorità sull'impostazione da file json, dato che è stata configurata come prioritaria alla riga 28 del file [Program.cs](Program.cs)
 * Provare a rimuovere la chiave "Urls" dal file [hosting.json](hosting.json) e la variabile d'ambiente "ASPNETCORE_URLS". Riaprire il terminale e riavviare l'applicazione per verificare come l'endpoint ora sia localhost:9000, definito in un dizionario a riga 38 del file [Program.cs](Program.cs). Anche gli oggetti in memoria come questo possono essere usati come fonti di configurazione ma è preferibile che siano il meno prioritari possibile, perché i loro valori sono cablati nel codice. Sono consigliabili quando dobbiamo ridefinire i default di ASP.NET Core;
 * Provare ad aggiungere altre chiavi di configurazione del web host nel file [hosting.json](hosting.json), come per esempio la chiave "environment" da impostare su "Development". Riavviare l'applicazione e osservare l'output del comando `dotnet run` per verificare che l'ambiente sia cambiato.

Nota: tutte le chiavi di configurazione supportate dal web host sono indicate nella [documentazione ufficiale Microsoft](https://docs.microsoft.com/en-us/aspnet/core/fundamentals/host/web-host?view=aspnetcore-2.1&tabs=aspnetcore2x), che riporta sia i nomi da usare per i file che per le variabili d'ambiente.