﻿using System.Linq;
using Microsoft.Extensions.Localization;

namespace ContentLocalization.Services
{
    public class AggregatorService : IAggregatorService
    {
        IStringLocalizerFactory factory;

        public AggregatorService(IStringLocalizerFactory factory)
        {
            this.factory = factory;
        }

        public string GetAllKeys()
        {
            // crea un IStringLocalizer al volo in base al tipo richiesto,
            // in questo caso CustomService
            var localizer = factory.Create(typeof(CustomService));

            // recupera tutte le chiavi ed i rispettivi valori localizzati
            var resources = localizer.GetAllStrings();

            // recupera tutte le chiavi
            var keys = resources.Select(x => x.Name);

            return $"Chiavi: {string.Join(",", keys)}";
        }
    }
}