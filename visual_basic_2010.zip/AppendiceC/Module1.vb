﻿Imports Microsoft.Office.Interop.Excel
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.ComponentModel

Module Module1

    <DllImport("user32.dll")>
    Private Function GetSystemMenu(ByVal hWnd As IntPtr, ByVal bRevert As Boolean) As IntPtr
    End Function

    <DllImport("user32.dll")>
    Private Function RemoveMenu(ByVal hWnd As IntPtr, ByVal nPosition As Integer, ByVal wFlags As Integer) As Integer
    End Function

    Const MF_BYPOSITION As Integer = &H400

    Sub Main()
        'Sample1()
        Sample2()

        Console.ReadLine()
    End Sub

    Sub Sample2()
        ' Recupero la finestra della console
        Dim handle As IntPtr = Process.GetCurrentProcess().MainWindowHandle

        ' Recupero il menu
        Dim hMenu As IntPtr = GetSystemMenu(handle, False)
        If hMenu = IntPtr.Zero Then Throw New Win32Exception()

        ' Rimuovo la X posizionata sempre all'indice 6
        RemoveMenu(hMenu, 6, MF_BYPOSITION)

        Console.WriteLine("Pulsante di chiusura rimosso")
    End Sub

    Sub Sample1()
        ' Carico Excel
        Dim app As New Application()
        Try
            ' Creo il file
            Dim workbook As Workbook = app.Workbooks.Add()

            ' Recupero il foglio predefinito
            Dim worksheet As Worksheet = workbook.ActiveSheet

            ' Preparo la prima cella
            Dim range As Range = worksheet.Cells(1, 1)
            range.Value = "ASPItalia.com"
            range.EntireColumn.AutoFit()
            range.Font.Bold = True

            ' Salvo il file
            Dim filename As String = Path.Combine(Environment.CurrentDirectory, "test.xlsx")
            workbook.SaveAs(filename)
        Finally
            ' Chiudo excel
            app.Quit()
        End Try
    End Sub

End Module
