﻿using System.Xml;
using System;

public class Sample7
{
    public static void Run()
    {
        // Impostazioni di caricamento del file
        XmlReaderSettings settings = new XmlReaderSettings();
        settings.IgnoreComments = true;
        settings.IgnoreProcessingInstructions = true;
        settings.IgnoreWhitespace = true;

        // Using per chiudere il file e liberarlo
        using (XmlReader reader = XmlReader.Create("Test.xml", settings))
        {
            // Leggo il prossimo nodo dallo stream
            while (reader.Read())
            {
                // Stampo nome del nodo (attributo o elemento) e tipo
                Console.WriteLine("LocalName: {0} - NodeType: {1}",
                  reader.LocalName, reader.NodeType);

                // Intercetto l'inizio di un nuovo elemento
                if (reader.NodeType == XmlNodeType.Element)
                {
                    // Identifico in che elemento mi trovo
                    switch (reader.LocalName)
                    {
                        case "description":
                            // Controllo che l'elemento non sia vuoto
                            if (!reader.IsEmptyElement)
                                Console.WriteLine("Description: {0}",
                                  reader.ReadElementContentAsString());
                            break;
                        case "product":
                            // Mi sposto sull'attributo idProduct
                            if (reader.MoveToAttribute("idProduct"))
                                // Se è andato a buon fine, leggo il valore
                                Console.WriteLine("idProduct: {0}", reader.Value);
                            break;
                    }
                }
            }
        }
    }

}