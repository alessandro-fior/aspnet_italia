﻿Namespace ASPItalia.Books.Chapter06
    Public Class FileLogWriter
        Public Property FileName As String

        Public Sub New(ByVal filename As String)
            Me.FileName = filename
        End Sub

        Public Sub Write(ByVal timestamp As DateTime,
          ByVal message As String)
            ' scrittura messaggio su file...
        End Sub
    End Class
End Namespace
