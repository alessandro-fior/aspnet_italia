﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPItalia.Books.Chapter06
{
    public class FileLogWriter
    {
        public string FileName { get; set; }

        public FileLogWriter(string filename)
        {
            this.FileName = filename;
        }

        public void Write(DateTime timestamp, string message)
        {
            // Scrittura messaggio su file...
            Console.WriteLine("{0} - Scrivo su {1} il messaggio {2}", timestamp, this.FileName, message);
        }
    }

}
