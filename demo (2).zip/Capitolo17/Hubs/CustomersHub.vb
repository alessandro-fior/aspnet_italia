﻿Imports System.Threading
Imports System.Threading.Tasks
Imports Microsoft.AspNet.SignalR

Public Class CustomersHub
    Inherits Hub
    Public Function ExportData(id As Integer) As Boolean
        Task.Run(Sub()
                     ' Simulo operazione lunga
                     Thread.Sleep(3000)

                     ' Notifico il chiamate dell'avvenuta operazione
                     Clients.Caller.exportDataReady("download/" & id)

                 End Sub)

        ' Esito della richiesta
        Return True
    End Function
End Class

