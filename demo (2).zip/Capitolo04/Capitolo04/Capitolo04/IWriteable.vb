﻿Public Interface IWritable
	Sub Write()
	End Class
