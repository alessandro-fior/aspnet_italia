﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ
{
	class Program
	{
		static List<Ordine> ordini;
		static List<Ordine> ordiniSet;

		static void Main(string[] args)
		{
			ordiniSet = new List<Ordine>() {
				new Ordine { Id = 1, Data = DateTime.Now },
				new Ordine { Id = 2, Data = DateTime.Now },
				new Ordine { Id = 5, Data = DateTime.Now },
				new Ordine { Id = 6, Data = DateTime.Now },
				new Ordine { Id = 6, Data = DateTime.Now }
			};

			ordini = new List<Ordine>() {
				new Ordine { Id = 1, Data = DateTime.Now,
					Dettagli = new List<DettaglioOrdine>() {
						new DettaglioOrdine { Id = 1, Prezzo = 50, Quantita = 10, Prodotto = new Prodotto { Id = 1, Nome = "Scarpe" } },
						new DettaglioOrdine { Id = 2, Prezzo = 30, Quantita = 1, Prodotto = new Prodotto { Id = 2, Nome = "Calzini" } },
						new DettaglioOrdine { Id = 3, Prezzo = 12, Quantita = 13, Prodotto = new Prodotto { Id = 3, Nome = "Cappelli" } },
					}.ToArray()
				},

				new Ordine { Id = 2, Data = DateTime.Now.AddDays(-10),
					Dettagli = new List<DettaglioOrdine>() {
						new DettaglioOrdine { Id = 4, Prezzo = 32, Quantita = 18, Prodotto = new Prodotto { Id = 1, Nome = "Scarpe" } },
						new DettaglioOrdine { Id = 5, Prezzo = 15, Quantita = 4, Prodotto = new Prodotto { Id = 3, Nome = "Cappelli" } },
					}.ToArray()
				},

				new Ordine { Id = 3, Data = DateTime.Now.AddDays(-5),
					Dettagli = new List<DettaglioOrdine>() {
						new DettaglioOrdine { Id = 6, Prezzo = 2, Quantita = 9, Prodotto = new Prodotto { Id = 2, Nome = "Calzini" } },
						new DettaglioOrdine { Id = 7, Prezzo = 15, Quantita = 4, Prodotto = new Prodotto { Id = 4, Nome = "Magliette" } },
						new DettaglioOrdine { Id = 8, Prezzo = 21, Quantita = 150, Prodotto = new Prodotto { Id = 5, Nome = "Occhiali" } },
						new DettaglioOrdine { Id = 9, Prezzo = 1, Quantita = 400, Prodotto = new Prodotto { Id = 6, Nome = "Polsini" } },
						new DettaglioOrdine { Id = 10, Prezzo = 3, Quantita = 84, Prodotto = new Prodotto { Id = 7, Nome = "Pantaloncini" } },
					}.ToArray()
				},

				new OrdineEx { Id = 4, IsInternational = true, Data = DateTime.Now.AddDays(-5),
					Dettagli = new List<DettaglioOrdine>() {
						new DettaglioOrdine { Id = 11, Prezzo = 2, Quantita = 30, Prodotto = new Prodotto { Id = 2, Nome = "Calzini" } },
						new DettaglioOrdine { Id = 12, Prezzo = 2, Quantita = 2, Prodotto = new Prodotto { Id = 7, Nome = "Pantaloncini" } },
					}.ToArray()
				},
			};
			CercaOrdine();
			CercaOrdineConPiuFiltri();
			CercaOrdineConPiuWhere();
			CercaOrdiniConIndicePari();
			CercaOrdiniInternazionali();
			CercaIdOrdini();
			CercaOrdiniConDTO();
			CercaOrdiniConAnonymousType();
			CercaOrdiniConAnonymousTypeNomiCambiati();
			CercaDettagli();
			OrdiniPerData();
			InvertiOrdini();
			RaggruppaOrdiniPerData();
			RaggruppaOrdiniPerDataConOggettoCustom();
			Aggregazioni();
			PaginaOrdini();
			PaginaOrdini2();
			Except();
			Distinct();
			Intersect();
			Union();
			Console.ReadLine();
		}

		static void CercaOrdine()
		{
			var result = ordini.Where(w => w.Id == 1).Select(s => new { s.Data, s.Id });
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void CercaOrdineConPiuFiltri()
		{
			var result = ordini.Where(o => o.Id == 1 && o.Data.Date == DateTime.Now.Date);
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void CercaOrdineConPiuWhere()
		{
			var result = ordini.Where(o => o.Id == 1);
			result.Where(o => o.Data.Date == DateTime.Now.Date);
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void CercaOrdiniConIndicePari()
		{
			var result = ordini.Where((o, i) => i % 2 == 0);
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void CercaOrdiniInternazionali()
		{
			var result = ordini.OfType<OrdineEx>();
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void CercaIdOrdini()
		{
			var result = ordini.Select(o => o.Id);
			foreach (var order in result)
			{
				Console.WriteLine(order);
			}
		}

		static void CercaOrdiniConDTO()
		{
			var result = ordini.Select(o => new OrdineDTO { Id = o.Id, Data = o.Data });
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void CercaOrdiniConAnonymousType()
		{
			var result = ordini.Select(o => new { o.Id, o.Data });
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void CercaOrdiniConAnonymousTypeNomiCambiati()
		{
			var result = ordini.Select(o => new { IdOrdine = o.Id, DataOrdine = o.Data });
			foreach (var order in result)
			{
				Console.WriteLine(order.IdOrdine + " - " + order.DataOrdine);
			}
		}

		static void CercaDettagli()
		{
			var result = ordini.SelectMany(o => o.Dettagli);
			foreach (var detail in result)
			{
				Console.WriteLine(detail.Id + " - " + detail.Prodotto);
			}
		}

		static void OrdiniPerData()
		{
			var result = ordini.OrderBy(o => o.Data);
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void InvertiOrdini()
		{
			var result = ordini.Where(o => typeof(Ordine) == o.GetType()).Reverse();
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void RaggruppaOrdiniPerData()
		{
			var result = ordini.GroupBy(o => o.Data.Date);
			StringBuilder sb = new StringBuilder();
			foreach (var item in result)
			{
				Console.WriteLine(item.Key);
				foreach (var obj in item)
				{
					Console.WriteLine("  " + obj.Id);
				}
			}
		}

		static void RaggruppaOrdiniPerDataConOggettoCustom()
		{
			var result = ordini.GroupBy(o => o.Data.Date, o => new { o.Id, Dettagli = o.Dettagli.Count() });
			foreach (var item in result)
			{
				Console.WriteLine(item.Key);
				foreach (var obj in item)
				{
					Console.WriteLine("  " + obj.Id + " Dettagli " + obj.Dettagli);
				}
			}
		}

		static void Aggregazioni()
		{
			var maxdata = ordini.Max(o => o.Data);
			var mindata = ordini.Min(o => o.Data);
			var avgvendite = ordini.Average(o => o.Dettagli.Count());
			var fatturato = ordini.Sum(o => o.Dettagli.Sum(d => d.Prezzo * d.Quantita));
			Console.WriteLine("Max Data " + maxdata);
			Console.WriteLine("Min Data " + mindata);
			Console.WriteLine("avg dettgli " + avgvendite);
			Console.WriteLine("fatturato " + fatturato);
		}

		static void PaginaOrdini()
		{
			var result = ordini.Take(2);
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void PaginaOrdini2()
		{
			var result = ordini.Skip(2).Take(2);
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void Except()
		{
			var result = ordini.Except(ordiniSet);
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void Distinct()
		{
			var result = ordiniSet.Distinct();
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void Intersect()
		{
			var result = ordini.Intersect(ordiniSet);
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}

		static void Union()
		{
			var result = ordini.Union(ordiniSet);
			foreach (var order in result)
			{
				Console.WriteLine(order.Id + " - " + order.Data);
			}
		}
	}
}
