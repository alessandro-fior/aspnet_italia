using System.Threading.Tasks;
using BasicAuth.Models;

namespace BasicAuth.Services {
    public interface IUserRepository {
        //Con questo metodo, l'implementazione di IUserRepository troverà
        //un utente a partire dallo username e dalla password forniti dall'utente
        User FindByCredentials(string username, string password);
    }
}