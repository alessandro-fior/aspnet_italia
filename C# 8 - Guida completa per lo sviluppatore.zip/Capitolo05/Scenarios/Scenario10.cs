﻿using System;
using System.Collections.Generic;

namespace Capitolo5.Scenarios
{
    public static class Scenario10
    {
        /// <summary>
        /// Esempio 5.14
        /// </summary>
        public static void Run()
        {
            var holidays = new HashSet<DateTime>();
            holidays.Add(new DateTime(2019, 12, 25));
            holidays.Add(new DateTime(2019, 1, 1));
            holidays.Add(new DateTime(2019, 5, 1));

            var summerHolidays = new HashSet<DateTime>();
            summerHolidays.Add(new DateTime(2019, 8, 15));

            holidays.UnionWith(summerHolidays);

            var someDate = new DateTime(2019, 11, 1);
            var willWork = !holidays.Contains(someDate);
            Console.WriteLine($"Lavorerò il giorno 1/11? {willWork}");
        }
    }
}