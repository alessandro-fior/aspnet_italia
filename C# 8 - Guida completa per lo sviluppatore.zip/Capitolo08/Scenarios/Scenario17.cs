﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario17
    {
        /// <summary>
        /// Esempio 8.19
        /// </summary>
        public static void Run()
        {
            var compositeTask = Task.Factory.StartNew(() =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Primo task");
            }).ContinueWith((task) =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Secondo task");
            });

            // Accodamento di una funzione
            var resultTask = compositeTask.ContinueWith((task) =>
            {
                string result = "Funzione del terzo task";
                Console.WriteLine(result);
                return result;
            });
            
            Console.WriteLine("Il risultato è: {0}", resultTask.Result);
        }
    }
}