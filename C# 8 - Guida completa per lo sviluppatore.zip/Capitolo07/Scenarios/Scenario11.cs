﻿using System;

namespace Capitolo7.Scenarios
{
    public static class Scenario11
    {
        /// <summary>
        /// Esempio 7.18
        /// </summary>
        public static void Run()
        {
            Type integerType;

            // Utilizzo dell'istruzione typeof
            integerType = typeof(int);
            Console.WriteLine(integerType);

            // Utilizzo del metodo object.GetType() a partire
            // da un'istanza dell'oggetto
            int value = 5;
            integerType = value.GetType();
            Console.WriteLine(integerType);

            // Utilizzo del metodo Type.GetType() a partire
            // dal nome in formato stringa del tipo
            integerType = Type.GetType("System.Int32");
            Console.WriteLine(integerType);
        }
    }
}