﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPItalia.Books.Chapter07
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class ReportPropertyAttribute : Attribute
    {
        public string Header { get; set; }

        public ReportPropertyAttribute(string header)
        {
            this.Header = header;
        }
    }
}
