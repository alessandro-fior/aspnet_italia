﻿using System;
using System.Threading;

namespace Capitolo8.Scenarios
{
    public static class Scenario7
    {
        /// <summary>
        /// Esempio 8.7
        /// </summary>
        public static void Run()
        {
            string someVariable = "Matteo Tumiati";
            
            ThreadPool.QueueUserWorkItem((argument) =>
            {
                Thread.Sleep(500);
                Console.WriteLine("Saluti da: {0}", argument);
            }, someVariable);

            someVariable = "Daniele Bochicchio";
            Thread.Sleep(2000);
        }
    }
}