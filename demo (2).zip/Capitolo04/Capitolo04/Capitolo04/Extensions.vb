﻿Imports System.Runtime.CompilerServices

Public Module Extensions
	<Extension()>
	Public Function IsNull(ByVal value As String) As Boolean
		Return value Is Nothing
	End Function
End Module
