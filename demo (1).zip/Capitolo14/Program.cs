﻿using System;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;

namespace Capitolo14
{
    public class Program
    {
        public static void Main(string[] args)
        {
            BuildWebHost(args).Build().Run();
        }

        public static IWebHostBuilder BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .UseSetting(WebHostDefaults.HostingStartupAssembliesKey, "Capitolo14.Library")
                .UseShutdownTimeout(TimeSpan.FromSeconds(10));
    }
}
