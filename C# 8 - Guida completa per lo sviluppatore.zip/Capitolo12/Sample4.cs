﻿using System.Xml;
using System.IO;
using System;

public class Sample4
{
    public static void Run()
    {
        var doc = new XmlDocument();

        // Uri: percorso relativo al file
        doc.Load(Path.Combine(Environment.CurrentDirectory, "test.xml"));

        // Rimuovo il terzo prodotto
        doc.DocumentElement.RemoveChild(doc.DocumentElement.LastChild);
        // Tolgo tutti i figli del secondo prodotto
        doc.DocumentElement.LastChild.RemoveAll();

        // Creo l'elemento product
        XmlElement product = doc.CreateElement("",
          "product", "http://schemas.aspitalia.com/book40/products");
        // Imposto l'attributo idProduct
        product.SetAttribute("idProduct", "4");
        // Aggiungo l'elemento prima degli altri prodotti
        doc.DocumentElement.InsertBefore(product,
          doc.DocumentElement.ChildNodes[1]);

        // Commento all'interno del tag product
        XmlComment comment = doc.CreateComment(
          " Nuovo prodotto ");
        product.AppendChild(comment);

        // Sezione CDATA
        XmlCDataSection cdata = doc.CreateCDataSection(
          "Testo libero con <complesso>");
        product.AppendChild(cdata);

        // Creo elemento description
        XmlElement description = doc.CreateElement("",
          "description",
          "http://schemas.aspitalia.com/book40/products");
        // Creo un nodo XmlText con la descrizione
        description.InnerText = "Prodotto 4";
        // Aggiungo l'elemento al tag product
        product.AppendChild(description);

        // Salvo il documento
        var sw = new StringWriter();
        doc.Save(sw);

        Console.WriteLine(sw.ToString());
    }

}