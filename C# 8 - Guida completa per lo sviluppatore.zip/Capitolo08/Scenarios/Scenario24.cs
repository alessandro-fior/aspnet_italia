﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario24
    {
        /// <summary>
        /// Esempio 8.32
        /// </summary>
        public static void Run()
        {
            var myList = new List<string>();
            myList.Add("Elemento di test");

            var firstTask = Task.Factory.StartNew(() =>
            {
                if (myList.Count > 0)
                {
                    // race condition!
                    Console.WriteLine(myList[0]);
                }
            });
            
            var secondTask = Task.Factory.StartNew(() =>
            {
                if (myList.Count > 0)
                    myList.RemoveAt(0);
            });
            
            Task.WaitAll(firstTask, secondTask);
        }
    }
}