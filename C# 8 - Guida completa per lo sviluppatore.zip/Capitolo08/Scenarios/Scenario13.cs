﻿using System;
using System.Threading;

namespace Capitolo8.Scenarios
{
    public static class Scenario13
    {
        /// <summary>
        /// Esempio 8.13
        /// </summary>
        public static void Run()
        {
            var method = new SomeDelegate((parameter) =>
            {
                Thread.Sleep(1000);
                Console.WriteLine("Ciao da {0}", parameter);
                return parameter.Length;
            });

            method.BeginInvoke("Matteo Tumiati", MyCallback, method);
            Console.WriteLine("Esecuzione avviata");
            Console.ReadLine();
        }

        public static void MyCallback(IAsyncResult ar)
        {
            Console.WriteLine("Esecuzione terminata");

            var method = (SomeDelegate)ar.AsyncState;
            int result = method.EndInvoke(ar);
            Console.WriteLine("Il risultato è {0}", result);
        }

        public delegate int SomeDelegate(string parameter);
    }
}