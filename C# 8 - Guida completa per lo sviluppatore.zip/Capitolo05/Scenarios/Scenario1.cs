﻿using System;

namespace Capitolo5.Scenarios
{
    public static class Scenario1
    {
        /// <summary>
        /// Esempio 5.1
        /// </summary>
        public static void Run()
        {
            int[] myIntArray = { 1, 5, 2, 3, 6 };
            int[] anotherArray = new int[5];
            anotherArray[3] = 2;

            // Recupera il numero di elementi
            var length = myIntArray.Length;
            Console.WriteLine($"L'array contiene {length} elementi.");

            // Indice di un elemento
            var index = Array.IndexOf(myIntArray, 2);
            Console.WriteLine($"L'indice dell'elemento 2 è: {index}");

            // Ritorna il quarto elemento
            var item = myIntArray[3];
            Console.WriteLine($"L'elemento in posizione 3 è: {item}");

            // Ordina gli elementi
            Array.Sort(myIntArray);

            Console.WriteLine();
            for (var i = 0; i < length; i++)
                Console.WriteLine($"L'elemento in posizione {i} è: {myIntArray[i]}");
            Console.WriteLine();

            // Modifica il numero di elementi
            Array.Resize(ref myIntArray, 7);
            myIntArray[6] = 11;
            Console.WriteLine($"L'array contiene {myIntArray.Length} elementi.");
        }
    }
}