﻿Class Application

    ' Application-level events, such as Startup, Exit, and DispatcherUnhandledException
    ' can be handled in this file.

  Private Sub Application_Exit(ByVal sender As System.Object, ByVal e As System.Windows.ExitEventArgs)

  End Sub
End Class
