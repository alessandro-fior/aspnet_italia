﻿<DataContract()>
Public Class Product

    <DataMember()>
    Public Property Name As String

    <DataMember()>
    Public Property ID As Integer

End Class
