﻿Imports System.IO

Public Class Upload
  Inherits System.Web.UI.Page

  Protected Sub Page_Load(ByVal sender As Object, _
                          ByVal e As System.EventArgs) _
                        Handles Me.Load
    If Request.QueryString("path") IsNot Nothing Then
      Dim _physicalApplicationPath As String = _
        HttpContext.Current.Request.PhysicalApplicationPath
      Dim _path As String = _
         String.Format("{0}\{1}", _
                       _physicalApplicationPath, _
                       Convert.ToString(Request.QueryString("path")))

      Using stream As FileStream = File.OpenWrite(_path)
        Dim dataByte As Byte() = New Byte(1023) {}
        Dim i As Integer = 0

        Do
          i = Me.Context.Request.InputStream.Read(dataByte, 0, 1024)
          If i > 0 Then
            stream.Write(dataByte, 0, i)
          End If
        Loop While i > 0
      End Using

      Response.Clear()
      Response.Write("ok")
      Response.End()
    Else
      Response.Clear()
      Response.Write("errore")
      Response.End()
    End If
  End Sub

End Class

