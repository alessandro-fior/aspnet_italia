﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Capitolo17.Models;
using Microsoft.AspNet.OData;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;

namespace Capitolo17.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController :  Controller
    {
        [HttpGet]
        [EnableQuery]
        public ActionResult<IQueryable<Customer>> GetCustomers()
        {
            IQueryable<Customer> r = new Customer[]
            {
                FindCustomerOnDatabase(1),
                FindCustomerOnDatabase(2),
            }.AsQueryable();

            return Ok(r);
        }

        [HttpGet("{id}")]
        public ActionResult<Customer> FindCustomer(int id)
        {
            Customer customer = FindCustomerOnDatabase(id);
            if (customer == null)
            {
                return NotFound(); // Ritorna NotFoundResult
            }

            // Header personalizzato
            Response.GetTypedHeaders().CacheControl = new CacheControlHeaderValue
            {
                MaxAge = TimeSpan.FromMinutes(20)
            };

            return Ok(customer); // Ritorna OkNegotiatedContentResult
            // return customer; // Ritorna OkNegotiatedContentResult
        }

        private Customer FindCustomerOnDatabase(int id)
        {
            if (id < 1) return null;

            return new Customer
            {
                FirstName = "Pippo",
                LastName = "Pluto",
            };
        }

        public void Post(Customer customer)
        {
            // Header If-Match
            var tag = Request.GetTypedHeaders().IfMatch?.FirstOrDefault()?.Tag;

            // TODO: chiamata al db
        }

        [HttpPut("/api/customers/confirm/{id}-{code}")]
        public void Confirm(int id, string code)
        {
            // TODO: implementare
        }

        [HttpPatch]
        public void UpdateCustomer(Customer customer)
        {
            // TODO: implementare
        }

    }
}
