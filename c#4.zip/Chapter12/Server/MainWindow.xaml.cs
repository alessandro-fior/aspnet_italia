﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net.Sockets;
using System.Threading;
using System.Net;

namespace Server
{
  public partial class MainWindow : Window
  {
public delegate void PrintDataDelegate(string result);

public MainWindow()
{
  InitializeComponent();
  new Thread(new ThreadStart(this.ReiceveData)).Start();
}

private void Button1_Click(object sender, RoutedEventArgs e)
{
  UdpClient client = new UdpClient();
  client.Connect("localhost", 8080);
  byte[] sendByte = Encoding.ASCII.GetBytes(this.TextBox1.Text);
  client.Send(sendByte, sendByte.Length);
}

private void ReiceveData()
{
  UdpClient server = new UdpClient(0x1f90);
  while (true)
  {
    IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, 0x1f90);
    byte[] reiceveByte = server.Receive(ref endPoint);
    string reiceveString = Encoding.ASCII.GetString(reiceveByte);
    this.Dispatcher.BeginInvoke(new PrintDataDelegate(this.PrintData), new object[] { reiceveString });
  }
}

private void PrintData(string str)
{
  TextBox2.Text += String.Format(" {0}", str);
}
  }
}
