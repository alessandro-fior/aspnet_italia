import React from 'react'

const Forecasts = ({ forecasts }) => {
  return (
    <div>
      <center><h1>Forecasts</h1></center>
      {forecasts.map((forecast) => (
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">{new Date(forecast.date).toLocaleDateString()}</h5>
            <h6 class="card-subtitle mb-2 text-muted">{forecast.temperatureC}</h6>
            <p class="card-text">{forecast.summary}</p>
          </div>
        </div>
      ))}
    </div>
  )
};

export default Forecasts