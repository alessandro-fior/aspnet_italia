﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Interop.Excel;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.ComponentModel;

namespace ASPItalia.Books.AppB
{
    class Program
    {
        [DllImport("user32.dll")]
        private extern static IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        [DllImport("user32.dll")]
        private extern static int RemoveMenu(IntPtr hWnd, int nPosition, int wFlags);

        const int MF_BYPOSITION = 0x400;

        static void Main()
        {
            Sample1();
            //Sample2();

            Console.ReadLine();
        }

        static void Sample2()
        {
            // Recupero la finestra della console
            IntPtr handle = Process.GetCurrentProcess().MainWindowHandle;

            // Recupero il menu
            IntPtr hMenu = GetSystemMenu(handle, false);
            if (hMenu == IntPtr.Zero) throw new Win32Exception();

            // Rimuovo la X posizionata sempre all'indice 6
            RemoveMenu(hMenu, 6, MF_BYPOSITION);

            Console.WriteLine("Pulsante di chiusura rimosso");
        }

        static void Sample1()
        {
            // Carico Excel
            Application app = new Application();
            try
            {
                // Creo il file
                Workbook workbook = app.Workbooks.Add();

                // Recupero il foglio predefinito
                Worksheet worksheet = workbook.ActiveSheet;

                // Preparo la prima cella
                Range range = worksheet.Cells[1, 1];
                range.Value = "ASPItalia.com";
                range.EntireColumn.AutoFit();
                range.Font.Bold = true;

                // Salvo il file
                string filename = Path.Combine(Environment.CurrentDirectory, "test.xlsx");
                workbook.SaveAs(filename);

                Process.Start(filename);
            }
            finally
            {
                // Chiudo excel
                app.Quit();
            }            
        }

    }
}
