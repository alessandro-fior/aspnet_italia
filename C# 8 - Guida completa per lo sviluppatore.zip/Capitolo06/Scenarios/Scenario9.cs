﻿using System.Collections.Generic;

namespace Capitolo6.Scenarios
{
    public static class Scenario9
    {
        /// <summary>
        /// Esempio 6.11, 6.12, 6.13
        /// </summary>
        public static void Run()
        {
            var strings = new List<string>();
            strings.Add("This is a test");
            strings.Add("abcdefgh");
            strings.Add("a1234567");

            var foundString = strings.Find(
                delegate (string item)
                {
                    return item.StartsWith("a");
                });

            // sintassi equivalente
            //var foundString = strings.Find(i => i.StartsWith("a"));

            var searchString = "B";
            var foundStringFromParameter = strings.Find(i => i.StartsWith(searchString));
        }
    }
}