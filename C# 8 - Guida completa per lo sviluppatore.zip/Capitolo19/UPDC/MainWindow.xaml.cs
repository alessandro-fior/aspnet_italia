﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UPDC
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += async (o, e) => await ReiceveDataAsync();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            var client = new UdpClient();
            client.Connect("localhost", 8080);
            byte[] sendByte = Encoding.ASCII.GetBytes(txb1.Text);
            await client.SendAsync(sendByte, sendByte.Length);
        }
        private async Task ReiceveDataAsync()
        {
            var server = new UdpClient(8080);
            while (true)
            {
                var result = await server.ReceiveAsync();
                var reiceveByte = result.Buffer;
                var reiceveString = Encoding.ASCII.GetString(reiceveByte);
                txb2.Text += String.Format(" {0}", reiceveString);
            }
        }
    }
}
