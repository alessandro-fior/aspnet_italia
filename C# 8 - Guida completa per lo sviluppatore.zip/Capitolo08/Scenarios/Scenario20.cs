﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario20
    {
        /// <summary>
        /// Esempio 8.23, 8.24
        /// </summary>
        public static async Task Run()
        {
            // soluzione sincrona
            Download();

            // soluzione asincrona
            // l'appliczione terminerà prima di mostrare l'output
            // questo è corretto, poiché l'operazione è asincrona...
            // se si vuole vedere l'output, bisognerà modificare anche il metodo Main
            // della classe Program per renderlo async Task e fare 
            // l'await del metodo Run
            await DownloadAsync();
        }

        public static void Download()
        {
            Console.WriteLine("---- Download ----");

            WebRequest client = HttpWebRequest.Create("http://www.google.com");
            var response = client.GetResponse();

            using (var reader = new StreamReader(response.GetResponseStream()))
            {
                // esecuzione sincrona della richiesta
                var result = reader.ReadToEnd();
                Console.WriteLine(result);
            }
        }

        public static async Task DownloadAsync()
        {
            Console.WriteLine("---- DownloadAsync ----");

            WebRequest client = HttpWebRequest.Create("http://www.google.com");
            var response = client.GetResponse();
            
            using (var reader = new StreamReader(response.GetResponseStream()))
            {
                // esecuzione asincrona della richiesta
                var result = await reader.ReadToEndAsync();
                Console.WriteLine(result);
            }
        }
    }
}