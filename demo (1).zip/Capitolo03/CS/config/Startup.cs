﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ConfigSample.Middlewares;
using ConfigSample.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ConfigSample
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables("ASPNETCORE_");
            Configuration = builder.Build();
        }
        public IConfigurationRoot Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<SmtpOptions>(Configuration.GetSection("Smtp"));
            services.Configure<ConnectionStringOptions>(Configuration.GetSection("ConnectionStrings"));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                //In ambiente di sviluppo, mostriamo tutti i dettagli tecnici dell'errore
                app.UseDeveloperExceptionPage();
            } else {
                //Altrimenti, mostriamo una pagina di cortesia per l'utente (il file Error.html si trova in /wwwroot)
                app.UseExceptionHandler("/Error.html");
            }

            app.UseStaticFiles();

            //Questi middleware personalizzati sono definiti nella directory /Middlewares

            //EmailErrorsMiddleware ha lo scopo di inviare un'email all'amministratore
            //in caso di errori nell'applicazione. Sarà in grado di catturare gli errori
            //che si verificano in tutti i middleware configurati dopo di lui
            app.UseMiddleware<EmailErrorsMiddleware>();

            //ConfigurationDumpMiddleware stamperà a video i valori di configurazione attuali.
            //Se si verifica un errore in questo middleware, l'EmailErrorsMiddleware potrà
            //intercettarlo per inviare l'email all'amministratore
            app.UseMiddleware<ConfigurationDumpMiddleware>();

            //Non servono altri middleware. In questa demo, l'unica risposta prodotta
            //è quella del ConfigurationDumpMiddleware. Non ha importanza quale URL
            //usiamo per navigare l'applicazione perché sarà sempre lui a fornire risposta.
        }
    }
}
