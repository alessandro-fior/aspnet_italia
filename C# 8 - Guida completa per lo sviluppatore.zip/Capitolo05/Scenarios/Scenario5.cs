﻿using System;
using System.Collections;

namespace Capitolo5.Scenarios
{
    public static class Scenario5
    {
        /// <summary>
        /// Esempio 5.7
        /// </summary>
        public static void Run()
        {
            // creo una array list ed aggiungo parametri
            var dateList = new ArrayList();
            dateList.Add(DateTime.Now);
            dateList.Add(new DateTime(2000, 1, 10));
            dateList.Add(DateTime.Today.AddYears(-1));

            // poiché sono tutti di tipo DateTime, il casting è semplice e funziona sempre
            DateTime firstItem = (DateTime)dateList[0];
            Console.WriteLine($"Il primo elemento è: {firstItem}");
        }
    }
}