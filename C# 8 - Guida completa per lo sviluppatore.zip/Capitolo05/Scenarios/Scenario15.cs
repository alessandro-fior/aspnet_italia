﻿using System;
using System.Collections.Generic;

namespace Capitolo5.Scenarios
{
    public static class Scenario15
    {
        /// <summary>
        /// Esempio 5.20
        /// </summary>
        public static void Run()
        {
            var cars = new List<Car>();
            cars.Add(new Car { PlateNumber = "AAA", Speed = 10 });
            cars.Add(new Car { PlateNumber = "BBB", Speed = 55 });
            cars.Add(new Car { PlateNumber = "CCC", Speed = 24 });
            
            cars.Sort(new SpeedComparer());

            Console.WriteLine($"L'auto più lenta è:  {cars[0].PlateNumber}");
            Console.WriteLine($"L'auto più veloce è:  {cars[cars.Count -1].PlateNumber}");
        }

        public class Vehicle
        {
            public int Speed { get; set; }
        }
        
        public class Car : Vehicle
        {
            public string PlateNumber { get; set; }
        }

        public class SpeedComparer : IComparer<Vehicle>
        {
            public int Compare(Vehicle x, Vehicle y)
            {
                return x.Speed - y.Speed;
            }
        }
    }
}