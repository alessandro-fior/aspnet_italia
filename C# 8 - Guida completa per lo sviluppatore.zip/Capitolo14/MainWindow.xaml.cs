﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Capitolo14
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Resources_Click(System.Object sender, System.Windows.RoutedEventArgs e)
        {
            Resources r = new Resources();
            r.ShowDialog();
        }

        private void Styles_Click(System.Object sender, System.Windows.RoutedEventArgs e)
        {
            Styles s = new Styles();
            s.ShowDialog();
        }


        private void Templates_Click(System.Object sender, System.Windows.RoutedEventArgs e)
        {
            Templates t = new Templates();
            t.ShowDialog();
        }

        private void Bindings_Click(System.Object sender, System.Windows.RoutedEventArgs e)
        {
            Bindings b = new Bindings();
            b.ShowDialog();
        }

        private void Bindings2_Click(System.Object sender, System.Windows.RoutedEventArgs e)
        {
            Bindings2 b = new Bindings2();
            b.ShowDialog();
        }

        private void Events_Click(System.Object sender, System.Windows.RoutedEventArgs e)
        {
            Events ev = new Events();
            ev.ShowDialog();
        }


    }
}
