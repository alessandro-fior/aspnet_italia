﻿Namespace ASPItalia.Books.Chapter07

    <AttributeUsage(AttributeTargets.Property, AllowMultiple:=False)>
    Public Class ReportPropertyAttribute
        Inherits Attribute
        Public Property Header As String

        Public Sub New(ByVal header As String)
            Me.Header = header
        End Sub
    End Class

End Namespace