﻿using Capitolo05.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Diagnostics;
using System.Text;

namespace Capitolo05.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            // ViewData e ViewBag agiscono sul medesimo dizionario
            ViewBag.Message = "Esempio di messaggio";
            ViewData["Message"] = "Sostituisce il messaggio precedente";

            return View();
        }

        public IActionResult ActionWithParams(int id, string search, int value = 0)
        {
            // con il routing standard:
            // {controller}/{action}/{id}
            // id -> route data
            // search e value -> query string o form
            return View();
        }

        public IActionResult About()
        {
            if (DateTime.Today.DayOfWeek == DayOfWeek.Sunday)
                return View("SundayAbout");

            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact(bool embed = false)
        {
            ViewData["Message"] = "Your contact page.";

            if (embed)
                return PartialView();

            return View();
        }

        public IActionResult GoToASPItalia()
        {
            return Redirect("http://www.aspitalia.com");
        }

        public IActionResult BackToIndex()
        {
            return RedirectToAction(nameof(Index));
        }
        public IActionResult ComplexRedirect()
        {
            return RedirectToAction(
                nameof(CustomersController.Details),
                nameof(CustomersController).Replace("Controller", ""),
                new { id = 5 });
        }

        public IActionResult GetSomeText()
        {
            string result = "Lorem ipsum...";
            return Content(result, "text/plain", Encoding.UTF8);
        }

        [RequireHttps]
        public IActionResult SecureAction()
        {
            return Content("Secure content");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
