﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Prodotto
/// </summary>
namespace LINQ {
	public class Prodotto {
		public int Id { get; set; }
		public string Nome { get; set; }
	}
}