﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using System.Threading.Tasks;
using System.Threading;

namespace Capitolo17.Hubs
{
    public class CustomersHub : Hub
    {
        public bool ExportData(int id)
        {
            Task.Run(() =>
            {
                // Simulo operazione lunga
                Thread.Sleep(3000);

                // Notifico il chiamate dell'avvenuta operazione
                Clients.Caller.exportDataReady("download/" + id);
            });

            // Esito della richiesta
            return true;
        }
    }
}