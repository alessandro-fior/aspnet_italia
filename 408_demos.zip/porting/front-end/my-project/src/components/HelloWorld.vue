<template>
  <ul id="example-1">
    <li v-for="item in weather" :key="item.date">
      {{ parseDate(item.date) }}
      {{ item.temperatureC }}
      {{ item.summary }}
    </li>
  </ul>
</template>

<script>
import axios from "axios";
import dayjs from "dayjs";

export default {
  name: 'HelloWorld',
  data () {
    return {
      weather: null
    }
  },
  mounted () {
    console.log("ciao");
    axios
      .get('https://localhost:5001/WeatherForecast')
      .then(response => (this.weather = response.data))
  },
  methods: {  
    parseDate (d) {
      console.log(d)
      return dayjs(d).format('YYYY-MM-DD HH:mm:ss')
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
