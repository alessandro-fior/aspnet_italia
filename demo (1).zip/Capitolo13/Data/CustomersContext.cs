﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace Capitolo13.Data
{
    public class CustomersContext : DbContext
    {
        public DbSet<Customer> Customers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

            optionsBuilder.UseSqlServer("server=(localdb)\\MSSQLLocalDB;Database=Capitolo11;Integrated security=true");
        }
    }

    public class Customer
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }
    }
}
