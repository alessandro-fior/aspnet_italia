﻿using System;
using System.ComponentModel;

namespace Capitolo6.Scenarios
{
    public static class Scenario12
    {
        /// <summary>
        /// Esempio 6.18, 6.19, 6.20
        /// </summary>
        public static void Run()
        {
            var receiver = new PortReceiver();
            receiver.PortDataReceived += PortDataReceived;
            receiver.PortDataReceiving += PortDataReceiving;
        }

        private static void PortDataReceiving(object sender, CancelEventArgs e)
        {
            Console.WriteLine(e.Cancel);
        }

        private static void PortDataReceived(object sender, PortDataReceivedEventArgs e)
        {
            Console.WriteLine(e.Data);
        }

        public class PortDataReceivedEventArgs : EventArgs
        {
            public string Data { get; set; }
        }

        public class PortReceiver
        {
            public delegate void PortDataReceivedEventHandler(object sender, PortDataReceivedEventArgs e);
            public event PortDataReceivedEventHandler PortDataReceived;
            public event CancelEventHandler PortDataReceiving;

            protected virtual void OnPortDataReceived(string data)
            {
                if (this.PortDataReceived != null)
                {
                    var e = new PortDataReceivedEventArgs();
                    e.Data = data;
                    this.PortDataReceived(this, e);
                }
            }

            protected virtual void OnPortDataReceiving(CancelEventArgs e)
            {
                if (this.PortDataReceiving != null)
                    this.PortDataReceiving(this, e);
            }

            public string Data { get; set; }

            public void ReceiveData()
            {
                var e = new CancelEventArgs(false);
                this.OnPortDataReceiving(e);

                // qui verifichiamo se un sottoscrittore
                // ha cancellato la ricezione dati
                if (!e.Cancel)
                {
                    this.Data = "Data received";
                    this.OnPortDataReceived(Data);
                }
            }
            
            // .. codice di interfacciamento con la porta ..
        }
    }
}