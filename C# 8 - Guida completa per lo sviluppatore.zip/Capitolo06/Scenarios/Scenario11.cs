﻿using System;

namespace Capitolo6.Scenarios
{
    public static class Scenario11
    {
        /// <summary>
        /// Esempio 6.16, 6.17
        /// </summary>
        public static void Run()
        {
            var receiver = new PortReceiver();
            receiver.PortDataReceived += DataReceived;
        }

        private static void DataReceived(PortReceiver receiver)
        {
            Console.WriteLine(receiver.Data);
        }

        public class PortReceiver
        {
            public delegate void PortDataReceivedEventHandler(PortReceiver receiver);
            public event PortDataReceivedEventHandler PortDataReceived;

            public string Data { get; set; }
            
            public void ReceiveData()
            {
                this.Data = "Data received";
                if (this.PortDataReceived != null)
                    this.PortDataReceived(this);
            }
            
            // .. codice di interfacciamento con la porta ..
        }
    }
}