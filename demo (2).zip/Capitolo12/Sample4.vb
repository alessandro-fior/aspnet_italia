﻿Imports System.Xml
Imports System.IO

Public Class Sample4

    Public Shared Sub Run()
        Dim doc As New XmlDocument()

        ' Uri: percorso relativo al file
        doc.Load("test.xml")

        ' Rimuovo il terzo prodotto
        doc.DocumentElement.RemoveChild(doc.DocumentElement.LastChild)
        ' Tolgo tutti i figli del secondo prodotto
        doc.DocumentElement.LastChild.RemoveAll()

        ' Creo l'elemento product
        Dim product As XmlElement = doc.CreateElement("",
          "product", "http://schemas.aspitalia.com/book40/products")
        ' Imposto l'attributo idProduct
        product.SetAttribute("idProduct", "4")
        ' Aggiungo l'elemento prima degli altri prodotti
        doc.DocumentElement.InsertBefore(product,
          doc.DocumentElement.ChildNodes(1))

        ' Commento all'interno del tag product
        Dim comment As XmlComment = doc.CreateComment(
          " Nuovo prodotto ")
        product.AppendChild(comment)

        ' Sezione CDATA
        Dim cdata As XmlCDataSection = doc.CreateCDataSection(
          "Testo libero con <complesso>")
        product.AppendChild(cdata)

        ' Creo elemento description
        Dim description As XmlElement = doc.CreateElement("",
          "description",
          "http://schemas.aspitalia.com/book40/products")
        ' Creo un nodo XmlText con la descrizione
        description.InnerText = "Prodotto 4"
        ' Aggiungo l'elemento al tag product
        product.AppendChild(description)

        ' Salvo il documento
        Dim sw As New StringWriter()
        doc.Save(sw)

        Console.WriteLine(sw.ToString())
    End Sub

End Class
