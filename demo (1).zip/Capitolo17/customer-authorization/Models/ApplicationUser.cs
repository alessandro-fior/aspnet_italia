﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CustomerAuthorization.Models.Entities;
using Microsoft.AspNetCore.Identity;

namespace CustomerAuthorization.Models
{
    // Add profile data for application users by adding properties to the ApplicationUser class
    public class ApplicationUser : IdentityUser
    {
        public List<Order> Orders { get; set; }
    }
}
