﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;

namespace Capitolo13
{
    public class Program
    {
        public static void Main(string[] args)
        {
            BuildWebHost(args).Run();
        }

        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .ConfigureLogging(l =>
                {
                    // l.AddConsole(options => options.IncludeScopes = true);
                    l.AddEventSourceLogger();
                    l.AddTraceSource("mySwitch");
                    l.AddEmail();
                    // Superfluo
                    l.AddAzureWebAppDiagnostics();

                    // Imposto il livello minimo
                    l.SetMinimumLevel(LogLevel.Information);

                    l.AddFilter((provider, category, logLevel) =>
                    {
                        // Solo i nostri eventi informativi
                        if (logLevel == LogLevel.Information && category.StartsWith("Capitolo11"))
                        {
                            return true;
                        }

                        return false;
                    });
                })
                .UseStartup<Startup>()
                .Build();
    }
}
