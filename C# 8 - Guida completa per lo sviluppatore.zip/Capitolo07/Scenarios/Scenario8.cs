﻿using System;

namespace Capitolo7.Scenarios
{
    public static class Scenario8
    {
        /// <summary>
        /// Esempio 7.14
        /// </summary>
        public static void Run()
        {
            try
            {
                ReThrowException();
            }
            catch (NotImplementedException ex)
            {
                Console.WriteLine("Il metodo non è implementato");
                Console.WriteLine("StackTrace: ");
                Console.WriteLine(ex.StackTrace);
            }
        }

        private static void ReThrowException()
        {
            try
            {
                var myObject = new SomeClass();
                myObject.SomeProblematicMethod();
            }
            catch (Exception ex)
            {
                // notare che lo stacktrace mostrerà come primo metodo ReThrowException, non dando alcun riferimento
                // a chi ha generato l'eccezione per primo, ovvero SomeProblematicMethod
                //throw ex;

                // notare che lo stacktrace rimane invariato, poiché il primo metodo sarà effettivamente SomeProblematicMethod
                throw; 
            }
        }

        private class SomeClass
        {
            public void SomeProblematicMethod()
            {
                throw new NotImplementedException();
            }
        }
    }
}