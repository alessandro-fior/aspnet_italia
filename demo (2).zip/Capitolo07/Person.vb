﻿Namespace ASPItalia.Books.Chapter07
    Public Class Person
        Public Property Name As String
        Public Property Age As Integer

        Public Overrides Function ToString() As String
            Return String.Format("{0} ha {1} anni", Name, Age)
        End Function
    End Class
End Namespace