# Dimostrazione di autenticazione e autorizzazione
In questa applicazione dimostrativa sono stati usati 3 middleware, tutti definiti nella directory /Middlewares
 1. __BasicAuthenticationMiddleware__ è il middleware di autenticazione ed è configurato all'inizio della pipeline. Il suo scopo è esaminare il contenuto della richiesta alla ricerca dell'intestazione `Authorization` che contiene le credenziali di accesso. Se le credenziali sono presenti e corrispondono ad un utente registrato, allora creerà per lui una `ClaimsPrincipal` contenente vari claim e l'assegnerà alla richiesta corrente, in modo che i middleware successivi la trovino e possano compiere decisioni in base ad essa. Aprendo l'applicazione in un browser qualsiasi, verrà proposta la maschera di login. Inserire queste credenziali:
 - Utente `admin` con password `password` per autenticarsi con un utente che ha il ruolo di amministratore;
 - Utente `customer1` con password `password` per autenticarsi con un utente che ha il ruolo di cliente;
 2. __AuthorizationMiddleware__ è il middleware di autorizzazione e si occupa di bloccare ogni richiesta anonima, cioè alla quale non sia stata associata una `ClaimsPrincipal` autenticata. Questo middleware potrebbe essere sviluppato ulteriormente per applicare politiche di autorizzazione più complesse, che prendano in considerazione i claim trovati nella `ClaimsPrincipal`.
 3. __ContentMiddleware__ è un middleware che produce una semplice risposta per il client. Va in esecuzione solo se l'`AuthorizationMiddleware` non aveva bloccato la richiesta. Se l'utente autenticato aveva il ruolo di amministratore, produrrà del contenuto aggiuntivo riservato ad esso.

 ## Note
 Questa applicazione è puramente dimostrativa delle meccaniche di autenticazione e autorizzazione. In applicazioni reali, **si consiglia caldamente l'uso di ASP.NET Core Identity**.

 Gli utenti `admin` e `customer1` impiegati in questa applicazione sono definiti nel file [Services/UserRepository.cs](Services/UserRepository.cs) che è un segnaposto per un vero repository che legge gli utenti da un database.

 I middleware e i servizi sono registrati, come al solito, nel file [Startup.cs](Startup.cs)

 ## Esercizi
 * Provare a modificare l'`AuthorizationMiddleware` per impedire l'accesso agli utenti minorenni. La data di nascita è situata nel claim `ClaimTypes.DateOfBirth` in formato stringa, quindi bisognerà usare `DateTime.Parse` per riconvertirla al tipo `DateTime`. Sottrarre la data odierna a tale data per verificare se il lasso di tempo trascorso è inferiore a 18 anni. Se lo è, bloccare la richiesta impostando lo status code Unauthorized (401) come è stato fatto per le richieste anonime. Altrimenti, lasciar proseguire la richiesta al prossimo middleware. L'utente `customer1` è minorenne.