﻿using System;
using System.Dynamic;

namespace Capitolo7.Scenarios
{
    public static class Scenario14
    {
        /// <summary>
        /// Esempio 7.22
        /// </summary>
        public static void Run()
        {
            dynamic myObject = new MyDynamicObject();
            Console.WriteLine(myObject.Property1);
            Console.WriteLine(myObject.SomeMethod("Test"));
        }

        public class MyDynamicObject : DynamicObject
        {
            public override bool TryGetMember(GetMemberBinder binder, out object result)
            {
                result = "Property " + binder.Name;
                return true;
            }

            public override bool TryInvokeMember(InvokeMemberBinder binder, object[] args, out object result)
            {
                result = "Method " + binder.Name;
                return true;
            }
        }
    }
}