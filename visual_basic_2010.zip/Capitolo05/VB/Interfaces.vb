﻿Namespace ASPItalia.Books.Chapter05
    Public Interface ICovariant(Of Out T)
        Function SomeCovariantMethod() As T
    End Interface

    Public Interface IContravariant(Of In T)
        Sub SomeContravariantMethod(ByVal arg As T)
    End Interface
End Namespace