﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using Capitolo14.Data;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Capitolo14.Services
{
    public class PingCustomerHostedService : IHostedService, IDisposable
    {
        private readonly IServiceProvider _serviceProvider;
        private System.Timers.Timer _pingTimer;

        public PingCustomerHostedService(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            // Ogni 10 minuti
            int interval = 1000 * 60 * 10;
            _pingTimer = new System.Timers.Timer(interval);
            _pingTimer.Elapsed += OnPingTimer;
            _pingTimer.Start();

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _pingTimer?.Stop();
            return Task.CompletedTask;
        }

        private void OnPingTimer(object sender, ElapsedEventArgs e)
        {
            // Creazione esplicita dello scope
            using (IServiceScope scope = _serviceProvider.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<CustomersContext>();

                // Interrogazione clienti
            }
        }

        public void Dispose()
        {
            _pingTimer?.Dispose();
        }
    }
}
