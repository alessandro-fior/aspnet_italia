﻿Imports System.Xml
Imports System.IO

Public Class Sample12

    Public Shared Sub Run()

        ' Caricamento del documento
        Dim doc As XDocument = XDocument.Load("test.xml")

        Dim productNs As XNamespace = "http://schemas.aspitalia.com/book40/products"
        Dim dns As XNamespace = "http://schemas.aspitalia.com/book40/details"

        ' Rimuovo gli attributi del primo elemento
        doc.Root.Elements().First().RemoveAttributes()
        ' Rimuovo il secondo e il terzo elemento product
        doc.Root.Elements(productNs + "product").Skip(1).Take(2).Remove()

        ' Nuovo tag product dentro products
        Dim product As XElement = New XElement(productNs + "product",
                 New XComment("Nuovo prodotto"),
                 New XAttribute("idProduct", 4),
                 New XElement(productNs + "description", "Prodotto 4"))
        doc.Root.Add(product)

        Console.WriteLine(doc)
    End Sub

End Class
