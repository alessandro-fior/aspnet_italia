﻿Imports System.Net.Sockets
Imports System.Text

Class MainWindow
  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button1.Click
    Dim client As New UdpClient()
    client.Connect("localhost", 8080)
    Dim sendByte As Byte() = Encoding.ASCII.GetBytes(TextBox1.Text)
    client.Send(sendByte, sendByte.Length)
  End Sub
End Class
