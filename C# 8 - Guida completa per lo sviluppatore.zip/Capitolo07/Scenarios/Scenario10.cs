﻿using System;
using System.Reflection;

namespace Capitolo7.Scenarios
{
    public static class Scenario10
    {
        /// <summary>
        /// Esempio 7.16, 7.17
        /// </summary>
        public static void Run()
        {
            // Recupera una reference all'assembly corrente
            Assembly currentAssembly = Assembly.GetExecutingAssembly();

            // Ricerca dei tipi definiti nell'assembly in esecuzione
            foreach (Type type in currentAssembly.GetTypes())
            {
                // Stampa il nome del tipo su console
                Console.WriteLine(type.Name);
            }
            Console.WriteLine();

            Assembly MsCoreLib = Assembly.GetAssembly(typeof(int));
            Console.WriteLine(MsCoreLib.FullName);
            Console.WriteLine(MsCoreLib.Location);
            Console.WriteLine(MsCoreLib.GetName().Version);
        }
    }
}