﻿using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace Capitolo14.Middleware
{
    public class TimerMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<TimerMiddleware> _logger;

        public TimerMiddleware(RequestDelegate next, ILogger<TimerMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();

            ITimerFeature feature = new TimerFeature(stopwatch);
            httpContext.Features.Set(feature);

            try
            {
                await _next(httpContext);
            }
            finally
            {
                stopwatch.Stop();
                if (!httpContext.Response.HasStarted)
                {
                    httpContext.Response.Headers["x-execution-time"] = stopwatch.Elapsed.ToString("g");
                }
            }
        }
    }
}
