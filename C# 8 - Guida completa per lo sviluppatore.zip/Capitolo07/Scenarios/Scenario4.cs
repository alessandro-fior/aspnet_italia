﻿using System;
using System.Data.SqlClient;

namespace Capitolo7.Scenarios
{
    public static class Scenario4
    {
        /// <summary>
        /// Esempio 7.5
        /// </summary>
        public static void Run()
        {
            try
            {
                ExecuteSqlQuery();
            }
            catch (SqlException e) when (e.Class > 19)
            {
                Console.WriteLine("Errore fatale");
            }
            catch (SqlException e)
            {
                Console.WriteLine("Errore durante la query");
            }
        }

        public static void ExecuteSqlQuery()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=.;Database=GUARANTEED_TO_FAIL;Connection Timeout=1");
            conn.Open();
        }
    }
}