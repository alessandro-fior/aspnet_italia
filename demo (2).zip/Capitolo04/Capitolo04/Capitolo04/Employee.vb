﻿Public Class Employee
	Inherits Person      ' Deriva dalla classe base Person
	Implements IWritable ' Implementa l'interfaccia IWritable

	Private _firstName As String

	Public Sub New(ByVal name As String, ByVal age As Integer)
		MyBase.FullName = name
		MyBase.Age = age
		_firstName = MyBase.GetFirstName()
	End Sub

	Public Sub Write() Implements IWritable.Write
		Console.Write(MyBase.FullName)
	End Sub
End Class
