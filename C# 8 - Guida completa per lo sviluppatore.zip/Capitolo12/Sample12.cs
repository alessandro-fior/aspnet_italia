﻿using System.Xml;
using System.IO;
using System.Xml.Linq;
using System.Linq;
using System;

public class Sample12
{

    public static void Run()
    {
        // Caricamento del documento
        var doc = XDocument.Load(Path.Combine(Environment.CurrentDirectory, "test.xml"));

        XNamespace productNs = "http://schemas.aspitalia.com/book40/products";
        XNamespace dns = "http://schemas.aspitalia.com/book40/details";

        // Rimuovo gli attributi del primo elemento
        doc.Root.Elements().First().RemoveAttributes();
        // Rimuovo il secondo e il terzo elemento product
        doc.Root.Elements(productNs + "product").Skip(1).Take(2).Remove();

        // Nuovo tag product dentro products
        var product = new XElement(productNs + "product", new XComment("Nuovo prodotto"), new XAttribute("idProduct", 4), new XElement(productNs + "description", "Prodotto 4"));
        doc.Root.Add(product);

        Console.WriteLine(doc);
    }

}
