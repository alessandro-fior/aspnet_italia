﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Capitolo8.Scenarios
{
    public static class Scenario4
    {
        /// <summary>
        /// Esempio 8.4
        /// </summary>
        public static void Run()
        {
            var list = new List<Thread>();

            // Qui creiamo ed eseguiamo cinque worker thread
            for (int index = 0; index < 5; index++)
            {
                var myThread = new Thread((currentIndex) =>
                {
                    Console.WriteLine("Thread {0} è iniziato", currentIndex);
                    Thread.Sleep(500);
                    Console.WriteLine("Thread {0} è terminato", currentIndex);
                });
            
                myThread.Start(index);
                list.Add(myThread);
            }

            // Attesa del completamento di ognuno dei worker thread
            foreach (Thread thread in list)
            {
                thread.Join();
            }

            Console.WriteLine("Esecuzione di tutti i thread terminata");
        }
    }
}