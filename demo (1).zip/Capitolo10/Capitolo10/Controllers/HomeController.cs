﻿using Capitolo10.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Capitolo10.Controllers
{
	public class HomeController : Controller
	{
		NorthwindContext _ctx;
		public HomeController(NorthwindContext ctx)
		{
			_ctx = ctx;
		}

		public IActionResult Query()
		{
			var customers = _ctx.Customers.Where(c => c.Address.Country == "Italy").ToList();
			return View(customers);

			//	var c1 = _ctx.Orders.Where(o => o.Customer.CustomerId == "ALFKI").Select(c => new { c.Customer.CustomerId, pid = c.OrderDetails.Select(d => d.ProductId) }).ToList();
			//	foreach (var item in c1)
			//	{
			//		foreach (var i in item.pid)
			//		{

			//		}
			//	}

			//	var orders = _ctx.Orders
			//			.FromSql("Select * from dbo.GetOrdersByCustomer {0}", "ALFKI")
			//			.Include(o => o.OrderDetails)
			////.Where(o => o.ShipAddress.City == "Rome")
			//.OrderBy(o => o.OrderDate);


			//	var o1 = _ctx.Orders.Where(o => o.Customer.CustomerId == "ALFKI").ToList();
			//	return View();
		}

		public async Task<IActionResult> Find()
		{
			var c1 = _ctx.Customers.First(c => c.CustomerId == "ALFKI");
			var c2 = _ctx.Customers.Find("ALFKI");
			var c3 = await _ctx.Customers.FindAsync("ALFKI");
			return View(c3);
		}

		public IActionResult SubQuery()
		{
			var orders = _ctx.Orders
			.Where(o => o.Customer.CustomerId == "ALFKI")
			.Select(c => new
			{
				CustomerId = c.Customer.CustomerId,
				Products = c.OrderDetails.Select(d => d.ProductId)
			})
			.ToList(); // query che estrae dati ordine
			foreach (var order in orders)
			{
				foreach (var p in order.Products) // query che estrae prodotti per ordine
				{
				}
			}
			return Content(orders.Count.ToString());
		}

		public IActionResult Include()
		{
			var c1 = _ctx.Orders.Include(o => o.OrderDetails).ToList();
			//var c2 = _ctx.Orders.Include(o => o.OrderDetails).ThenInclude(c => c.Product);
			return View(c1);
		}

		public IActionResult SP()
		{
			var orders = _ctx.Orders
			.FromSql("Select * from dbo.GetOrdersByCustomer {0}", "ALFKI")
			.Include(o => o.OrderDetails)
			.Where(o => o.ShipAddress.City == "Rome")
			.OrderBy(o => o.OrderDate)
			.ToList();

			//var orders = _ctx.Orders
			//.FromSql("EXECUTE dbo.GetOrdersByCustomer {0}", "ALFKI")
			//.ToList();


			return View();
		}

		public IActionResult AddOrder()
		{
			var c = new Customer { CustomerId = "TEST1", CompanyName = "Name", Address = new AddressInfo { Address = "Address1", City = "Rome", Country = "Italy", PostalCode = "00100", Region = "Lazio" } };
			_ctx.Customers.Add(c);
			_ctx.SaveChanges();
			return Content("Ordine creato");
		}

		public IActionResult AddOrderWithDetails()
		{
			var o = new Order
			{
				Customer = new Customer { CustomerId = "ALFKI" },
				OrderDate = DateTime.Now,
				Freight = 10,
				ShipAddress = new AddressInfo { Address = "Address1", City = "Rome", Country = "Italy", PostalCode = "00100", Region = "Lazio" },
				ShipName = "sn",
				//Imposta altre proprietà ordine ma non la chiave perché ordine nuovo
			};
			o.OrderDetails.Add(new OrderDetail
			{
				Discount = 0,
				ProductId = 1,
				Quantity = 10,
				UnitPrice = 24
				//Imposta proprietà dettaglio ma non la chiave perché ordine nuovo
			});
			o.OrderDetails.Add(new OrderDetail
			{
				Discount = 0,
				ProductId = 2,
				Quantity = 10,
				UnitPrice = 24
				//Imposta proprietà dettaglio ma non la chiave perché ordine nuovo
			});
			_ctx.Orders.Attach(o);
			_ctx.SaveChanges();
			return Content("Ordine con dettagli creato");
		}

		public IActionResult UpdateCustomer()
		{
			var cust = _ctx.Customers.Find("ALFKI");
			cust.Address.Address = "Piazza del popolo 1";
			_ctx.SaveChanges();
			return Content("Cliente aggiornato");
		}

		public IActionResult UpdateCustomerOffline()
		{
			var cust = new Customer { CustomerId = "ALFKI", CompanyName = "Nuovo nome" };
			_ctx.Customers.Update(cust);
			_ctx.SaveChanges();
			return Content("Cliente aggiornato");
		}

		public IActionResult DeleteCustomer()
		{
			var cust = _ctx.Customers.Find("ALFKI");
			_ctx.Customers.Remove(cust);
			_ctx.SaveChanges();
			return Content("Cliente eliminato");
		}
	}
}
