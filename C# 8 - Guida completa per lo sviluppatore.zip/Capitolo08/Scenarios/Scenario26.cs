﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario26
    {
        /// <summary>
        /// Esempio 8.34, 8.35
        /// </summary>
        public static void Run()
        {
            List<string> myList = new List<string>
            {
                "Matteo Tumiati", "Daniele Bochicchio", "Stefano Mostarda", "Cristian Civera", "Marco Leoncini"
            };

            // verificare differenze con l'output precedente cambiando il tipo di collezione
            //ConcurrentBag<string> myList = new ConcurrentBag<string>
            //{
            //    "Matteo Tumiati", "Daniele Bochicchio", "Stefano Mostarda", "Cristian Civera", "Marco Leoncini"
            //};

            // Creazione del task che scorre la collection
            var firstTask = Task.Factory.StartNew(() =>
            {
                foreach (string item in myList)
                {
                    Console.WriteLine(item);
                }
            });

            // Creazione del task che modifica la collection
            var secondTask = Task.Factory.StartNew(() =>
            {
                myList.Add("Task element");
            });

            Task.WaitAll(firstTask, secondTask);
        }
    }
}