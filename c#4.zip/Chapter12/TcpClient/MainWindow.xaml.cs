﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Net.Sockets;

namespace TcpClient
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Button1_Click(object sender, RoutedEventArgs e)
    {
      using (Stream fileStream = File.OpenRead(this.TextBlock1.Tag.ToString()))
      {
        System.Net.Sockets.TcpClient client = new System.Net.Sockets.TcpClient();
        client.Connect("localhost", 1234);
        NetworkStream netStream = client.GetStream();
        byte[] sendBuffer = new byte[1024];
        int bytesRead = 0;
        do
        {
          bytesRead = fileStream.Read(sendBuffer, 0, 1024);
          if (bytesRead > 0)
          {
            netStream.Write(sendBuffer, 0, bytesRead);
          }
        }
        while (bytesRead > 0);
        netStream.Close();
      }
    }

    private void Button2_Click(object sender, RoutedEventArgs e)
    {
      OpenFileDialog fileDialog = new OpenFileDialog
      {
        Filter = "immagini (*.jpg)|*.jpg"
      };
      bool? show = fileDialog.ShowDialog();
      if (show.HasValue & show.Value)
      {
        using (Stream fileStream = fileDialog.OpenFile())
        {
          this.TextBlock1.Text = fileDialog.SafeFileName;
          this.TextBlock1.Tag = fileDialog.FileName;
          MemoryStream dataStream = new MemoryStream();
          byte[] dataByte = new byte[1024];
          int i = 0;
          do
          {
            i = fileStream.Read(dataByte, 0, 1024);
            if (i > 0)
            {
              dataStream.Write(dataByte, 0, i);
            }
          }
          while (i > 0);
          dataStream.Seek(0L, SeekOrigin.Begin);
          BitmapImage bmpImage = new BitmapImage();
          bmpImage.BeginInit();
          bmpImage.StreamSource = dataStream;
          bmpImage.EndInit();
          this.Image1.Source = bmpImage;
        }
      }
    }
  }
}
