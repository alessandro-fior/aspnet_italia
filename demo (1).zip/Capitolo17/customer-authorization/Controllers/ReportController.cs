using System.Linq;
using System.Threading.Tasks;
using CustomerAuthorization.Models;
using CustomerAuthorization.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CustomerAuthorization.Controllers
{
    [Authorize]
    public class ReportController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        public ReportController(UserManager<ApplicationUser> userManager)
        {
            this.userManager = userManager;
        }

        [Authorize(Policy = "JustForCustomer1")]
        public async Task<IActionResult> CustomReport()
        {
            var user = await userManager
            .Users
            .Include(u => u.Orders)
            .FirstOrDefaultAsync(u => u.UserName == User.Identity.Name);
            
            if (user == null) {
                return RedirectToAction("Index", "Home");
            }
            var reportData = user.Orders.GroupBy(order => order.CreatedAt.Year)
            .Select(group => new CustomReportViewModel { Year = group.Key, Amount = group.Sum(o => o.Amount) })
            .ToList();
            return View(reportData);
        }

    }

}