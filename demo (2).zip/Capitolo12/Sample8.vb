﻿Imports System.Xml
Imports System.IO

Public Class Sample8

    Public Shared Sub Run()
        ' Impostazioni di scrittura
        Dim settings As New XmlWriterSettings()
        settings.Indent = True
        settings.NewLineOnAttributes = True

        Dim ns As String = "http://schemas.aspitalia.com/book40/products"

        Dim stringWriter As New StringWriter()

        Using writer As XmlWriter = XmlWriter.Create(stringWriter, settings)

            writer.WriteStartDocument()

            ' Nuovo tag products
            writer.WriteStartElement("products", ns)
            writer.WriteComment("Nuovo prodotto")

            ' Nuovo tag product con attributo
            writer.WriteStartElement("product", ns)
            writer.WriteAttributeString("idProduct", "4")

            ' Noto testuale
            writer.WriteElementString("description", ns, "Prodotto 4")

            ' Chiudo i tag
            writer.WriteEndElement()
            writer.WriteEndElement()

            writer.WriteEndDocument()
        End Using

        Console.WriteLine(stringWriter)
    End Sub

End Class
