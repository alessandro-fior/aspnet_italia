﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Capitolo8.Scenarios
{
    public static class Scenario25
    {
        /// <summary>
        /// Esempio 8.33
        /// </summary>
        public static void Run()
        {
            var syncObject = new object();
            var myList = new List<string>();
            myList.Add("Elemento di test");

            var firstTask = Task.Factory.StartNew(() =>
            {
                lock (syncObject)
                {
                    if (myList.Count > 0)
                    {
                        Console.WriteLine(myList[0]);
                    }
                }
            });

            var secondTask = Task.Factory.StartNew(() =>
            {
                lock (syncObject)
                {
                    if (myList.Count > 0)
                    {
                        myList.RemoveAt(0);
                    }
                }
            });

            Task.WaitAll(firstTask, secondTask);
        }
    }
}