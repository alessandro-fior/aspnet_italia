﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Net;

namespace HttpWebRequestApplication
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    Uri uploadUri;
    Stream fileStream;
    public delegate void ManageDataDelegate(string result);

    public MainWindow()
    {
      InitializeComponent();
    }

    private void Button2_Click(object sender, RoutedEventArgs e)
    {
      OpenFileDialog fileDialog = new OpenFileDialog
      {
        Filter = "immagini (*.jpg)|*.jpg"
      };

      bool? show = fileDialog.ShowDialog();
      if (show.HasValue & show.Value)
      {
        using (Stream fileStream = fileDialog.OpenFile())
        {
          this.TextBlock1.Text = fileDialog.SafeFileName;
          this.TextBlock1.Tag = fileDialog.FileName;
          MemoryStream dataStream = new MemoryStream();
          byte[] dataByte = new byte[1024];
          int i = 0;
          do
          {
            i = fileStream.Read(dataByte, 0, 1024);
            if (i > 0)
            {
              dataStream.Write(dataByte, 0, i);
            }
          }
          while (i > 0);
          dataStream.Seek(0, SeekOrigin.Begin);
          BitmapImage bmpImage = new BitmapImage();
          bmpImage.BeginInit();
          bmpImage.StreamSource = dataStream;
          bmpImage.EndInit();
          this.Image1.Source = bmpImage;
          this.uploadUri = new Uri(string.Format("http://localhost:1503/Upload.aspx?path={0}", fileDialog.SafeFileName));
        }
      }
    }

    private async void Button1_Click(object sender, RoutedEventArgs e)
    {
      fileStream = File.OpenRead(TextBlock1.Tag.ToString());

      var request = WebRequest.Create(uploadUri) as HttpWebRequest;
      request.Method = "POST";

      var postStream = await request.GetRequestStreamAsync();

      var sendBuffer = new byte[1024];
      int bytesRead = 0;
      do
      {
        bytesRead = await this.fileStream.ReadAsync(sendBuffer, 0, 1024);
        if (bytesRead > 0)
        {
          postStream.Write(sendBuffer, 0, bytesRead);
        }
      }
      while (bytesRead > 0);

      var response = await request.GetResponseAsync();
      var streamResponse = response.GetResponseStream();

      var streamRead = new StreamReader(streamResponse);
      var responseString = streamRead.ReadToEnd();

      TextBlock1.Text = responseString;

      streamResponse.Close();
      streamRead.Close();
      response.Close();
      fileStream.Close();
    }
  }
}
