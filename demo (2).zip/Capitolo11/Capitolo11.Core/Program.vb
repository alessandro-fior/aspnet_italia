﻿Imports Microsoft.EntityFrameworkCore
Imports Microsoft.Extensions.Configuration
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Text
Imports System.Threading.Tasks
Imports System.Transactions

Module Program

	Dim connectionString As String

	Sub Main(args As String())
		Dim config = New ConfigurationBuilder().AddJsonFile("appsettings.json", True, True).Build()
		connectionString = config.GetConnectionString("db")
		QueryLista()
		Console.ReadLine()
	End Sub


	Private Sub DeleteCustomerDisconnected()
		Dim custToDelete As Customer

		Using ctx = New NorthwindContext
			custToDelete = ctx.Customers.Find("STEMO")
		End Using

		Using ctx = New NorthwindContext
			ctx.Customers.Attach(custToDelete)
			ctx.Customers.Remove(custToDelete)
		End Using
	End Sub

	Private Sub DeleteCustomerConnected()
		Using ctx = New NorthwindContext
			Dim cust = ctx.Customers.Find("STEMO")
			ctx.Customers.Remove(cust)
		End Using
	End Sub

	Private Sub UpdateCustomerDisconnected()
		Dim cust As Customer

		Using ctx = New NorthwindContext
			cust = ctx.Customers.Find("STEMO")
		End Using

		cust.Address = "Piazza Venezia 10"

		Using ctx = New NorthwindContext
			ctx.Customers.Attach(cust)
			ctx.Entry(cust).State = EntityState.Modified
			ctx.SaveChanges()
		End Using
	End Sub

	Private Sub UpdateCustomerConnected()
		Using ctx As NorthwindContext = New NorthwindContext
			Dim cust = ctx.Customers.Find("STEMO")
			cust.Address = "Piazza del popolo 1"
			ctx.SaveChanges()
		End Using
	End Sub

	Private Sub InsertCustomer()
		Using ctx As NorthwindContext = New NorthwindContext
			Dim c = New Customer With {
																.CustomerID = "STEMO",
																.CompanyName = "Stefano Mostarda",
																.ContactName = "Stefano Mostarda",
																.Address = "Via Del Corso 14",
																.City = "Roma",
																.Country = "Italy",
																.PostalCode = "00100",
																.Region = "Lazio",
																.ContactTitle = "Sig",
																.Phone = "00000",
																.Fax = "00000"
												}
			ctx.Customers.Add(c)
			ctx.SaveChanges()
		End Using
	End Sub

	Private Sub QueryInclude()
		Using ctx = New NorthwindContext
			Dim orders = ctx.Orders.Include(Function(o) o.Order_Details)

			For Each o In orders
				Console.WriteLine($"{o.OrderID}-{o.Order_Details.Count}")
			Next
		End Using
	End Sub

	Private Sub QueryProjection()
		Using ctx = New NorthwindContext
			Dim customers = ctx.Customers.[Select](Function(c) New With {c.CustomerID, c.CompanyName
												})

			For Each cust In customers
				Console.WriteLine($"{cust.CustomerID}-{cust.CompanyName}")
			Next
		End Using
	End Sub

	Private Sub QuerySingolo()
		Using ctx = New NorthwindContext
			Dim item1 = ctx.Customers.First(Function(c) c.CustomerID = "ALFKI")
			Dim item2 = ctx.Customers.Find("ALFKI")
			Console.WriteLine(item1.CustomerID)
		End Using
	End Sub

	Private Sub QueryLista()
		Dim it = "Italy"
		Using ctx = New NorthwindContext
			Dim customers1 = From c In ctx.Customers Where c.Country.Equals(it) Select c
			Dim customers2 = ctx.Customers.Where(Function(c) c.Country.Equals(it))
			Console.WriteLine(customers1.Count())
			Console.WriteLine(customers2.Count())
		End Using
	End Sub

End Module
