﻿using System;
using static Capitolo6.Scenarios.Scenario2;
using static Capitolo6.Scenarios.Scenario3;

namespace Capitolo6.Scenarios
{
    public static class Scenario4
    {
        /// <summary>
        /// Esempio 6.5
        /// </summary>
        public static void Run()
        {
            // Definizione del primo delegate
            var writer = new FileLogWriter(@"c:\somefile.txt");
            var fileDelegate = new StringLogWriter(writer.Write);

            // Definizione del secondo delegate
            var consoleDelegate = new StringLogWriter(ConsoleWriter);
            
            // Combinazione dei delegate
            StringLogWriter combinedDelegate = (StringLogWriter)Delegate.Combine(consoleDelegate, fileDelegate);
            var myLogger = new Logger(combinedDelegate);

            // Scrive sulla console e su file il messaggio in basso
            myLogger.Log("Messaggio di esempio");
        }
    }
}