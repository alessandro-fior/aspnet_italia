﻿
Imports System.Net
Imports System.Net.Http
Imports System.Net.Http.Headers
Imports System.Threading.Tasks
Imports System.Web.Http

Public Class CustomersController
    Inherits ApiController
    'public Customer Get(int id, bool withDetails)
    '{
    '    return new Customer
    '    {
    '        FirstName = "Pippo",
    '        LastName = "Pluto",
    '    };
    '}

    Public Sub Post(customer As Customer)
        ' TODO: chiamata al db
    End Sub

    <Route("api/customers/confirm/{id}-{code}")>
    <HttpPut>
    Public Sub Confirm(id As Integer, code As String)

    End Sub

    Public Async Function [Get](request As HttpRequestMessage) As Task(Of HttpResponseMessage)
        ' Header If-Match
        Dim tag = request.Headers.IfMatch.First().Tag
        ' Leggo il contenuto come testo
        Dim text = Await request.Content.ReadAsStringAsync()

        Return request.CreateResponse(HttpStatusCode.OK)
    End Function

    Public Function [Get](id As Integer) As HttpResponseMessage
        ' Risposta 200
        Dim response As HttpResponseMessage = Request.CreateResponse(HttpStatusCode.OK)
        ' Imposto il contenuto della risposta
        response.Content = New StringContent("hello", Encoding.Unicode)
        ' Controllo l'header di cache
        response.Headers.CacheControl = New CacheControlHeaderValue() With {
            .MaxAge = TimeSpan.FromMinutes(20)
        }
        Return response
    End Function


    'public IHttpActionResult Get(int id)
    '{
    '    Customer customer = FindCustomerOnDatabase(id);
    '    if (customer == null)
    '    {
    '        return NotFound(); // Ritorna NotFoundResult
    '    }
    '    return Ok(customer);  // Ritorna OkNegotiatedContentResult
    '}

    Private Function FindCustomerOnDatabase(id As Integer) As Customer
        Return Nothing
    End Function

    '[HttpGet]
    'public Customer FindCustomer(int id)
    '{
    '    return new Customer();
    '}

    '[HttpPut]
    'public void UpdateCustomer(Customer customer)
    '{

    '}
End Class
