﻿using System.Linq;
using System.Xml.XPath;
using System.Xml;
using System.Xml.Xsl;
using System;



public class Sample20
{

    public static void Run()
    {

        XslCompiledTransform xslt = new XslCompiledTransform();
        // Carico la trasformazione XSLT
        xslt.Load("test.xslt");

        // Trasformo l'XML e lo mostro nella finestra di Output
        xslt.Transform("test.xml", null, Console.Out);
    }

}
