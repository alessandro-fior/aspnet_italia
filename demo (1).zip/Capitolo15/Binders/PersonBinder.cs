﻿using Capitolo15.Helpers;
using Capitolo15.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Newtonsoft.Json;
using System.IO;
using System.Threading.Tasks;

namespace Capitolo15.Binders
{
    public class PersonBinder : IModelBinder
    {
        public async Task BindModelAsync(ModelBindingContext bindingContext)
        {
            // verifico che il modello di binding sia quello che si è in grado di gestire, ovvero Person
            if (bindingContext.ModelType != typeof(Person))
                return;

            var body = string.Empty;

            // recupero del body come stringa
            using (var bodyStream = new StreamReader(bindingContext.HttpContext.Request.Body))
            {
                body = await bodyStream.ReadToEndAsync();
            }

            // se il body vuoto, non ha senso continuare
            if (string.IsNullOrEmpty(body))
                return;

            // cerco di recuperare il contenuto come json dal jwt ricevuto nel body
            var jsonPerson = JWTHelper.DecodeToken(body);

            if (!string.IsNullOrEmpty(jsonPerson))
            {
                // deserializzo e faccio validazione del modello
                var person = JsonConvert.DeserializeObject<Person>(jsonPerson);

                // faccio una validazione
                if (string.IsNullOrEmpty(person.FirstName) || string.IsNullOrEmpty(person.LastName))
                    return;
                
                // assegno il risultato del binding
                bindingContext.Result = ModelBindingResult.Success(person);
                return;
            }
        }
    }
}