﻿using System;

namespace Capitolo5.Scenarios
{
    public static class Scenario16
    {
        /// <summary>
        /// Esempio 5.22, 5.23, 5.24
        /// </summary>
        public static void Run()
        {
            var peopleArray = new string[]
            {
                "Daniele Bochicchio",
                "Stefano Mostarda",
                "Matteo Tumiati",
                "Cristian Civera",
                "Marco Leoncini"
            };

            var last = peopleArray[^1]; // ultimo
            var twoFromLast = peopleArray[^3]; //terzultimo

            // sintassi alternativa
            //Index lastIndex = ^1;
            //Index twoFromLastIndex = ^3;
            //var last = peopleArray[lastIndex];
            //var twoFromLast = peopleArray[twoFromLastIndex];

            Console.WriteLine($"L'ultimo nome della lista è: {last}");
            Console.WriteLine($"Il terzultimo nome della lista è: {twoFromLast}");
            Console.WriteLine();

            var peopleFiltered = peopleArray[1..3];

            // sintassi alternativa
            //Range range = 1..3;
            //var peopleFiltered = peopleArray[range];

            foreach (var person in peopleFiltered)
                Console.WriteLine(person);

            // stamperà tutti (compreso l'ultimo) ad esclusione di Daniele Bochicchio
            peopleFiltered = peopleArray[1..];

            Console.WriteLine();
            foreach (var person in peopleFiltered)
                Console.WriteLine(person);

            // stamperà tutti perché entrambi gli indici sono inclusivi
            peopleFiltered = peopleArray[..];

            Console.WriteLine();
            foreach (var person in peopleFiltered)
                Console.WriteLine(person);
        }
    }
}