﻿Option Strict Off

Imports System.IO
Imports System.Data.SqlClient
Imports System.Security
Imports System.Reflection
Imports System.Dynamic

Namespace ASPItalia.Books.Chapter07

    Module Chapter07

        Sub Main()
            ' ***************************************************************************************************
            ' Esempio 7.1
            ' ***************************************************************************************************
            Dim result = Division(5, 0)

            ' Questo codice non viene mai eseguito
            Console.WriteLine("Il risultato è " + result.ToString())

            ' ***************************************************************************************************
            ' Esempio 7.3
            ' ***************************************************************************************************
            Try
                Dim result1 = Division(5, 0)

                ' Questo codice non viene mai eseguito
                Console.WriteLine("Il risultato è " + result1.ToString())
            Catch ex As Exception
                Console.WriteLine("Si è verificato un errore")
            End Try

            Console.WriteLine("Esecuzione terminata")

            ' ***************************************************************************************************
            ' Esempio 7.4
            ' ***************************************************************************************************
            Try
                Dim result2 = Division(5, 0)

                ' Questo codice non viene mai eseguito
                Console.WriteLine("Il risultato è " + result2.ToString())

            Catch ex As DivideByZeroException
                Console.WriteLine("Errore: non si può dividere per zero")
            Catch ex As OutOfMemoryException
                Console.WriteLine("Memoria terminata")
            Catch ex As Exception
                Console.WriteLine("Si è verificato un errore generico")

            End Try

            ' ***************************************************************************************************
            ' Esempio 7.5
            ' ***************************************************************************************************
            Try
                ' ExecuteSqlQuery()
            Catch e As SqlException When (e.Class > 19)
                Console.WriteLine("Errore fatale")
            Catch e As SqlException
                Console.WriteLine("Errore durante la query")
            End Try


            ' ***************************************************************************************************
            ' Esempio 7.6
            ' ***************************************************************************************************
            Dim sr As New StreamReader("c:\test.txt")
            Try
                Dim content As String =
                    sr.ReadToEnd()
            Finally
                sr.Close()
            End Try

            ' ***************************************************************************************************
            ' Esempio 7.7
            ' ***************************************************************************************************
            Dim sr1 As New StreamReader("c:\test.txt")
            Try
                Dim content As String =
                    sr1.ReadToEnd()
            Catch ex As IOException
                Console.WriteLine("Errore di I/O:")
                Console.WriteLine(ex.Message)
            Finally
                sr1.Close()
            End Try

            ' ***************************************************************************************************
            ' Esempio 7.9
            ' ***************************************************************************************************
            Dim myObject As New DisposableObject

            Try
                myObject.SomeMethod()
            Finally
                myObject.Dispose()
            End Try

            ' ***************************************************************************************************
            ' Esempio 7.10
            ' ***************************************************************************************************
            Using myObject3 As New DisposableObject
                myObject3.SomeMethod()
            End Using

            ' ***************************************************************************************************
            ' Esempio 7.13
            ' ***************************************************************************************************
            Try
                Dim myObject4 As New SomeClass
                myObject4.SomeProblematicMethod()
            Catch ex As Exception
                ' logger.Log(ex.ToString)
                Throw
            End Try

            ' ***************************************************************************************************
            ' Esempio 7.15
            ' ***************************************************************************************************
            ' Recupera una reference all'assembly corrente
            Dim currentAssembly As Assembly = Assembly.GetExecutingAssembly()

            ' Ricerca dei tipi definiti nell'assembly in esecuzione
            For Each type As Type In currentAssembly.GetTypes()
                ' Stampa il nome del tipo su console
                Console.WriteLine(type.Name)
            Next

            ' ***************************************************************************************************
            ' Esempio 7.16
            ' ***************************************************************************************************
            Dim MsCoreLib As Assembly = Assembly.GetAssembly(GetType(Integer))

            Console.WriteLine(MsCoreLib.FullName)
            Console.WriteLine(MsCoreLib.Location)
            Console.WriteLine(MsCoreLib.GetName().Version)

            ' ***************************************************************************************************
            ' Esempio 7.17
            ' ***************************************************************************************************
            Dim integerType As Type

            ' Utilizzo dell'istruzione GetType
            integerType = GetType(Integer)

            ' Utilizzo del metodo Object.GetType() a partire
            ' da un'istanza dell'oggetto
            Dim value As Integer = 5
            integerType = value.GetType()

            ' Utilizzo del metodo Type.GetType a partire
            ' dal nome in formato stringa del tipo
            integerType = Type.GetType("System.Int32")

            ' ***************************************************************************************************
            ' Esempio 7.19
            ' ***************************************************************************************************
            ' Recuperiamo un riferimento al tipo
            Dim personType As Type =
              Type.GetType("ClassLibrary.Person, ClassLibrary")

            ' Tramite il costruttore di default (senza parametri)
            ' ne costruiamo un'istanza
            Dim constructor As ConstructorInfo =
              personType.GetConstructor(Type.EmptyTypes)
            Dim person As Object = constructor.Invoke(Nothing)

            ' Tramite PropertyInfo valorizziamo Name e Age
            Dim nameProperty As PropertyInfo =
              personType.GetProperty("Name")
            nameProperty.SetValue(person, "Matteo Tumiati", Nothing)

            Dim ageProperty As PropertyInfo =
              personType.GetProperty("Age")
            ageProperty.SetValue(person, 28, Nothing)

            ' Visualizziamo su Console il risultato di Person.ToString()
            Console.WriteLine(person.ToString())

            ' ***************************************************************************************************
            ' Esempio 7.20
            ' ***************************************************************************************************
            ' Creazione di un'istanza di person
            Dim personType1 As Type =
              Type.GetType("ClassLibrary.Person, ClassLibrary")
            Dim person1 As Object = Activator.CreateInstance(personType1)

            ' Utilizzo dell'oggetto
            person1.Name = "Matteo Tumiati"
            person1.Age = 28
            Console.WriteLine(person.ToString())

            ' ***************************************************************************************************
            ' Esempio 7.21
            ' ***************************************************************************************************
            Dim myObject1 As Object = New MyDynamicObject()
            Console.WriteLine(myObject1.Property1)
            Console.WriteLine(myObject1.SomeMethod("Test"))

            ' ***************************************************************************************************
            ' Esempio 7.22
            ' ***************************************************************************************************
            Dim myObject2 As Object = New ExpandoObject()
            myObject2.ToText = Function() _
              String.Format("{0} ha {1} anni", myObject2.Name, myObject2.Age)
            myObject2.Name = "Matteo Tumiati"
            myObject2.Age = 28

            Console.WriteLine(myObject2.ToText.Invoke)


        End Sub

        Public Function Division(ByVal a As Integer, ByVal b As Integer) As Integer

            Dim result As Integer = a \ b

            'In caso di errore questo codice non viene mai eseguito
            Console.WriteLine("Risultato calcolato con successo")

            Return result
        End Function

        ' ***************************************************************************************************
        ' Esempio 7.12
        ' ***************************************************************************************************
        Public Function ValidateCredentials(ByVal username As String, ByVal password As String) As Boolean
            Try
                ' codice per validare username e password su database
                Return True
            Catch ex As SqlException
                Throw New SecurityException(
                    "Non è stato possibile validare le credenziali", ex)
            End Try
        End Function

        ' ***************************************************************************************************
        ' Esempio 7.25
        ' ***************************************************************************************************
        Public Function BuildReport(Of T)(ByVal items As IEnumerable(Of T)) As String

            Dim headers As New Dictionary(Of PropertyInfo, String)

            For Each prop As PropertyInfo In GetType(T).GetProperties()
                Dim attributes() As Object =
                  prop.GetCustomAttributes(GetType(ReportPropertyAttribute), True)

                If (attributes.Length > 0) Then
                    Dim reportAttribute As ReportPropertyAttribute =
                      DirectCast(attributes(0), ReportPropertyAttribute)

                    headers.Add(prop, reportAttribute.Header)
                End If

            Next

            ' ... Qui logica per produrre il report in base 
            ' al contenuto del dictionary headers ...
            Return Nothing
        End Function


    End Module

End Namespace