﻿Public Class _02_Form
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub ShowFirstName(sender As Object, e As EventArgs)
        EntryForm.Visible = False
        Results.Visible = True
        SelectedFirstName.Text = FirstName.Text
    End Sub

End Class