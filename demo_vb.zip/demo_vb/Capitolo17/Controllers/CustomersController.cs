﻿using Capitolo17.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace Capitolo17.Controllers
{
    public class CustomersController : ApiController
    {
        //public Customer Get(int id, bool withDetails)
        //{
        //    return new Customer
        //    {
        //        FirstName = "Pippo",
        //        LastName = "Pluto",
        //    };
        //}

        public void Post(Customer customer)
        {
            // TODO: chiamata al db
        }

        [Route("api/customers/confirm/{id}-{code}")]
        [HttpPut]
        public void Confirm(int id, string code)
        {

        }

        public async Task<HttpResponseMessage> Get(HttpRequestMessage request)
        {
            // Header If-Match
            var tag = request.Headers.IfMatch.First().Tag;
            // Leggo il contenuto come testo
            var text = await request.Content.ReadAsStringAsync();

            return request.CreateResponse(HttpStatusCode.OK);
        }

        public HttpResponseMessage Get(int id)
        {
            // Risposta 200
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK);
            // Imposto il contenuto della risposta
            response.Content = new StringContent("hello", Encoding.Unicode);
            // Controllo l'header di cache
            response.Headers.CacheControl = new CacheControlHeaderValue()
            {
                MaxAge = TimeSpan.FromMinutes(20)
            };
            return response;
        }


        //public IHttpActionResult Get(int id)
        //{
        //    Customer customer = FindCustomerOnDatabase(id);
        //    if (customer == null)
        //    {
        //        return NotFound(); // Ritorna NotFoundResult
        //    }
        //    return Ok(customer);  // Ritorna OkNegotiatedContentResult
        //}

        private Customer FindCustomerOnDatabase(int id)
        {
            return null;
        }

        //[HttpGet]
        //public Customer FindCustomer(int id)
        //{
        //    return new Customer();
        //}

        //[HttpPut]
        //public void UpdateCustomer(Customer customer)
        //{

        //}
    }

}
