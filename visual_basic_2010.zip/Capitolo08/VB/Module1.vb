﻿Module Module1
	Dim ordini As List(Of Ordine)
	Dim ordiniSet As List(Of Ordine)

    Sub Main()
		Dim dettagli1() As DettaglioOrdine = {
		 New DettaglioOrdine With {.Id = 1, .Prezzo = 50, .Quantita = 10, .Prodotto = New Prodotto With {.Id = 1, .Nome = "Scarpe"}},
		 New DettaglioOrdine With {.Id = 2, .Prezzo = 30, .Quantita = 1, .Prodotto = New Prodotto With {.Id = 2, .Nome = "Calzini"}},
		 New DettaglioOrdine With {.Id = 3, .Prezzo = 12, .Quantita = 13, .Prodotto = New Prodotto With {.Id = 3, .Nome = "Cappelli"}}
		}

		Dim dettagli2() As DettaglioOrdine = {
		 New DettaglioOrdine With {.Id = 4, .Prezzo = 32, .Quantita = 18, .Prodotto = New Prodotto With {.Id = 1, .Nome = "Scarpe"}},
		 New DettaglioOrdine With {.Id = 5, .Prezzo = 15, .Quantita = 4, .Prodotto = New Prodotto With {.Id = 3, .Nome = "Cappelli"}}
		}

		Dim dettagli3() As DettaglioOrdine = {
		 New DettaglioOrdine With {.Id = 6, .Prezzo = 2, .Quantita = 9, .Prodotto = New Prodotto With {.Id = 2, .Nome = "Calzini"}},
		 New DettaglioOrdine With {.Id = 7, .Prezzo = 15, .Quantita = 4, .Prodotto = New Prodotto With {.Id = 4, .Nome = "Magliette"}},
		 New DettaglioOrdine With {.Id = 8, .Prezzo = 21, .Quantita = 150, .Prodotto = New Prodotto With {.Id = 5, .Nome = "Occhiali"}},
		 New DettaglioOrdine With {.Id = 9, .Prezzo = 1, .Quantita = 400, .Prodotto = New Prodotto With {.Id = 6, .Nome = "Polsini"}},
		 New DettaglioOrdine With {.Id = 10, .Prezzo = 3, .Quantita = 84, .Prodotto = New Prodotto With {.Id = 7, .Nome = "Pantaloncini"}}
		}

		Dim dettagli4() As DettaglioOrdine = {
		 New DettaglioOrdine With {.Id = 11, .Prezzo = 2, .Quantita = 30, .Prodotto = New Prodotto With {.Id = 2, .Nome = "Calzini"}},
		 New DettaglioOrdine With {.Id = 12, .Prezzo = 2, .Quantita = 2, .Prodotto = New Prodotto With {.Id = 7, .Nome = "Pantaloncini"}}
		}

		Dim ordini1 As New List(Of Ordine)
		ordini1.Add(New Ordine With {.Id = 1, .Data = DateTime.Now, .Dettagli = dettagli1})
		ordini1.Add(New Ordine With {.Id = 2, .Data = DateTime.Now.AddDays(-10), .Dettagli = dettagli2})
		ordini1.Add(New Ordine With {.Id = 3, .Data = DateTime.Now.AddDays(-5), .Dettagli = dettagli3})
		ordini1.Add(New OrdineEx With {.Id = 4, .IsInternational = True, .Data = DateTime.Now.AddDays(-5), .Dettagli = dettagli4})

		ordini = ordini1

		Dim ordini2 As New List(Of Ordine)
		ordini2.Add(New Ordine With {.Id = 1, .Data = DateTime.Now})
		ordini2.Add(New Ordine With {.Id = 2, .Data = DateTime.Now})
		ordini2.Add(New Ordine With {.Id = 5, .Data = DateTime.Now})
		ordini2.Add(New Ordine With {.Id = 6, .Data = DateTime.Now})
		ordini2.Add(New Ordine With {.Id = 6, .Data = DateTime.Now})
		ordiniSet = ordini2

		CercaOrdine()
		CercaOrdineConPiuFiltri()
		CercaOrdineConPiuWhere()
		CercaOrdiniConIndicePari()
		CercaOrdiniInternazionali()
		CercaIdOrdini()
		CercaOrdiniConDTO()
		CercaOrdiniConAnonymousType()
		CercaOrdiniConAnonymousTypeNomiCambiati()
		CercaDettagli()
		OrdiniPerData()
		InvertiOrdini()
		RaggruppaOrdiniPerData()
		RaggruppaOrdiniPerDataConOggettoCustom()
		Aggregazioni()
		PaginaOrdini()
		PaginaOrdini2()
		Except()
		Distinct()
		Intersect()
		Union()
		Console.ReadLine()
	End Sub

	Private Sub CercaOrdine()
		Dim result = ordini.Where(Function(w) w.Id = 1).Select(Function(s) New With {s.Data, s.Id})
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub CercaOrdineConPiuFiltri()
		Dim result = ordini.Where(Function(o) o.Id = 1 AndAlso o.Data.Date = DateTime.Now.Date)
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub CercaOrdineConPiuWhere()
		Dim result = ordini.Where(Function(o) o.Id = 1)
		result.Where(Function(o) o.Data.Date = DateTime.Now.Date)
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub CercaOrdiniConIndicePari()
		Dim result = ordini.Where(Function(o, i) i Mod 2 = 0)
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub CercaOrdiniInternazionali()
		Dim result = ordini.OfType(Of OrdineEx)()
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub CercaIdOrdini()
		Dim result = ordini.Select(Function(o) o.Id)
		For Each order In result
			Console.WriteLine(order)
		Next
	End Sub

	Private Sub CercaOrdiniConDTO()
		Dim result = ordini.Select(Function(o) New OrdineDTO())
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub CercaOrdiniConAnonymousType()
		Dim result = ordini.Select(Function(o) New With {o.Id, o.Data})
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub CercaOrdiniConAnonymousTypeNomiCambiati()
		Dim result = ordini.Select(Function(o) New With {.IdOrdine = o.Id, .DataOrdine = o.Data})
		For Each order In result
			Console.WriteLine((order.IdOrdine & " - ") + order.DataOrdine)
		Next
	End Sub

	Private Sub CercaDettagli()
		Dim result = ordini.SelectMany(Function(o) o.Dettagli)
		For Each detail In result
			Console.WriteLine(detail.Id & " - " & detail.Prodotto.Nome
							 )
		Next
	End Sub

	Private Sub OrdiniPerData()
		Dim result = ordini.OrderBy(Function(o) o.Data)
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub InvertiOrdini()
		Dim result = ordini.Where(Function(o) GetType(Ordine) Is o.GetType()).Reverse()
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub RaggruppaOrdiniPerData()
		Dim result = ordini.GroupBy(Function(o) o.Data.Date)
		For Each item In result
			Console.WriteLine(item.Key)
			For Each obj In item
				Console.WriteLine("  " & obj.Id)
			Next
		Next
	End Sub

	Private Sub RaggruppaOrdiniPerDataConOggettoCustom()
		Dim result = ordini.GroupBy(Function(o) o.Data.Date, Function(o) New With {o.Id, .Dettagli = o.Dettagli.Count()})
		For Each item In result
			Console.WriteLine(item.Key)
			For Each obj In item
				Console.WriteLine(("  " & obj.Id & " Dettagli ") + Convert.ToString(obj.Dettagli))
			Next
		Next
	End Sub

	Private Sub Aggregazioni()
		Dim maxdata = ordini.Max(Function(o) o.Data)
		Dim mindata = ordini.Min(Function(o) o.Data)
		Dim avgvendite = ordini.Average(Function(o) o.Dettagli.Count())
		Dim fatturato = ordini.Sum(Function(o) o.Dettagli.Sum(Function(d) d.Prezzo * d.Quantita))
		Console.WriteLine("Max Data " & maxdata)
		Console.WriteLine("Min Data " & mindata)
		Console.WriteLine("avg dettgli " & avgvendite)
		Console.WriteLine("fatturato " & fatturato)
	End Sub

	Private Sub PaginaOrdini()
		Dim result = ordini.Take(2)
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub PaginaOrdini2()
		Dim result = ordini.Skip(2).Take(2)
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub Except()
		Dim result = ordini.Except(ordiniSet)
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub Distinct()
		Dim result = ordiniSet.Distinct()
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub Intersect()
		Dim result = ordini.Intersect(ordiniSet)
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

	Private Sub Union()
		Dim result = ordini.Union(ordiniSet)
		For Each order In result
			Console.WriteLine((order.Id & " - ") + order.Data)
		Next
	End Sub

End Module
