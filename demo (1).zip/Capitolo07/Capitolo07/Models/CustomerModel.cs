﻿using Capitolo07.Validation;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Capitolo07.Models
{
    public class CustomerModel
    {
        public int Id { get; set; }

        [Remote(action: "IsNameValid", controller: "Customers")]
        [Display(Name = "Nome")]
        public string Name { get; set; }

        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        [Display(Name = "Data registrazione")]
        public DateTime RegistrationDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:n2}", ApplyFormatInEditMode = true)]
        [Display(Name = "Sconto")]
        public decimal DiscountPercentage { get; set; }

        [Display(Name = "Attivo")]
        public bool IsActive { get; set; }

        [Display(Name = "Indirizzo")]
        public string Address { get; set; }

        [Display(Name = "Stato")]
        public int CountryId { get; set; }

        [MinLength(10)]
        [MaxLength(1000)]
        public string Notes { get; set; }

        [CodiceFiscale]
        public string FiscalCode { get; set; }

        public List<CountryModel> Countries { get; set; } = new List<CountryModel>();
        public List<ContactModel> Contacts { get; set; } = new List<ContactModel>();
    }

    public class CountryModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class ContactModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
