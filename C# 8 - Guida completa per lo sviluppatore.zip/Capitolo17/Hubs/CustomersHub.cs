﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.DependencyInjection;

namespace Capitolo17.Hubs
{
    public class CustomersHub : Hub
    {
        private readonly IServiceScopeFactory _scopeFactory;

        public CustomersHub(IServiceScopeFactory scopeFactory)
        {
            _scopeFactory = scopeFactory;
        }

        public Task Hello()
        {
            return Clients.All.SendAsync("hello", "my message");
        }

        public bool ExportData(int id)
        {
            string connectionId = Context.ConnectionId;

            // Avvio in asincrono
            Task.Run(async () =>
            {
                // Simulo operazione lunga
                Thread.Sleep(3000);

                // Creo uno scope apposito perché in questa fase l'hub e tutti i suoi oggetti
                // sono già stati distrutti
                using var scope = _scopeFactory.CreateScope();
                // Ottengo il context che mi permette di usare l'hub
                var hubContext = scope.ServiceProvider.GetRequiredService<IHubContext<CustomersHub>>();

                // Notifico il chiamate dell'avvenuta operazione
                await hubContext.Clients.Client(connectionId).SendAsync("exportDataReady", "download/" + id);
            });

            // Esito della richiesta
            // Rispondo subito senza aspettare l'operazione
            return true;
        }

    }

}
