﻿using System; // namespace
using static System.Console; // classe statica esempio 4.16

namespace ASPItalia.Books.Chapter4
{
    // questo codice è compatibile anche con .NET Framework 4.8
    // per provarlo con .NET Framework, è sufficiente creare un nuovo progetto e copiarlo
    class Program
    {
        static void Main(string[] args)
        {
            // ****************************************************************************************************
            // Esempio 4.5
            // ****************************************************************************************************
            var pNew = new PersonNew();
            var newName = pNew.FullName;

            // ****************************************************************************************************
            // Esempio 4.11
            // ****************************************************************************************************

            var point1 = new { X = 21, Y = 10, Z = 71 };
            var point2 = new { X = 18, Y = 8, Z = 5 };

            // La seconda proprietà di point3 è di tipo string
            var point3 = new { X = 20, Y = "1", Z = 67 };

            point1 = point2;    // Assegnazione valida (stesso tipo anonimo) 
            // point1 = point3; // Errore (type mismatch)

            // ****************************************************************************************************
            // Esempio 4.14
            // ****************************************************************************************************

            string a = null;     // Stringa nulla
            bool b = a.IsNull(); // y vale true

            // ****************************************************************************************************
            // Esempio 4.16
            // ****************************************************************************************************
            WriteLine("Hello world"); // equivale a Console.WriteLine

            // ****************************************************************************************************
            // Esempio 4.24
            // ****************************************************************************************************
            Employee x = new Employee("Cristian Civera", 35);
            Person y = x;

            // Viene comunque eseguito il metodo di Employee
            // anche se il riferimento è di tipo Person
            string z = y.GetFirstName();

            // Il riferimento è di tipo IWritable, ma l'istanza è di tipo Employee
            IWritable x1 = new Employee("Cristian Civera", 35);

            // Scrive sulla console il nome completo
            x1.Write();

            // È necessario effettuare il casting per invocare il metodo
            string y1 = ((Employee)x1).GetFirstName();

            // ****************************************************************************************************
            // Esempio 4.25
            // ****************************************************************************************************

            Complex u = new Complex();           // Il numero complesso vale 0.0 + 0.0i
            Complex v = new Complex(1.0F, 2.0F); // Il numero complesso vale 1.0 + 2.0i

            Console.ReadLine();
        }
    }
}
