﻿Namespace ASPItalia.Books.Chapter05
    Public Class Utils

        Public Shared Sub Swap(Of T)(ByRef first As T, ByRef second As T)

            Dim temp As T = first
            first = second
            second = temp

        End Sub

        Public Shared Function Max(Of T As IComparable)(ByVal list As IEnumerable(Of T)) As T
            Dim isFirst As Boolean = True
            Dim res As T
            For Each item As T In list
                If isFirst Then
                    res = item
                    isFirst = False
                End If

                If res.CompareTo(item) < 0 Then res = item
            Next

            Return res
        End Function

    End Class
End Namespace