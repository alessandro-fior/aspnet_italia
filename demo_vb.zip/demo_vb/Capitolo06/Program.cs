﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ASPItalia.Books.Chapter06
{
    class Program
    {
        static void Main(string[] args)
        {
            // ************************************************************************************
            // Esempio 6.1
            // ************************************************************************************
            var strings = new List<string>();

            strings.Add("This is a test");
            strings.Add("abcdefgh");
            strings.Add("a1234567");

            // Utilizzo del predicate come argomento di Find
            var foundString = strings.Find(FindStringsWithA);

            // Stampa abcdefgh sulla console
            Console.WriteLine(foundString);

            // ************************************************************************************
            // Esempio 6.3
            // ************************************************************************************
            var myLogger = new Logger(ConsoleWriter);

            // Stampa sulla console il messaggio in basso
            myLogger.Log("Messaggio di esempio");

            // ************************************************************************************
            // Esempio 6.4
            // ************************************************************************************
            var writer = new FileLogWriter(@"c:\somefile.txt");
            var writerDelegate = new StringLogWriter(writer.Write);

            Console.WriteLine(writerDelegate.Method);

            Console.WriteLine(
              ((FileLogWriter)writerDelegate.Target).FileName);

            // ************************************************************************************
            // Esempio 6.5
            // ************************************************************************************
            // Definizione del primo delegate
            var writer1 = new FileLogWriter(@"c:\somefile.txt");
            var fileDelegate = new StringLogWriter(writer1.Write);

            // Definizione del secondo delegate
            var consoleDelegate = new StringLogWriter(ConsoleWriter);

            // Combinazione dei delegate
            StringLogWriter combinedDelegate =
              (StringLogWriter)Delegate.Combine(consoleDelegate, fileDelegate);

            var myLogger1 = new Logger(combinedDelegate);

            // Scrive sulla console e su file il messaggio in basso
            myLogger1.Log("Messaggio di esempio");

            // ************************************************************************************
            // Esempio 6.6
            // ************************************************************************************
            StringLogWriter combinedDelegate1 = (StringLogWriter)
                Delegate.Combine(consoleDelegate, fileDelegate);

            foreach (Delegate item in combinedDelegate1.GetInvocationList())
            {
                Console.WriteLine(item.Method);
            }

            combinedDelegate1 = (StringLogWriter)
              Delegate.Remove(combinedDelegate1, fileDelegate);

            Console.WriteLine("\r\nDopo la rimozione:");

            foreach (Delegate item in combinedDelegate1.GetInvocationList())
            {
                Console.WriteLine(item.Method);
            }

            // ************************************************************************************
            // Esempio 6.7
            // ************************************************************************************
            var myEcho = new SampleDelegate(VeryLongEchoFunction);

            Console.WriteLine(myEcho("Marco"));
            Console.WriteLine(myEcho("Daniele"));
            Console.WriteLine(myEcho("Riccardo"));

            // ************************************************************************************
            // Esempio 6.8
            // ************************************************************************************
            var results = new List<IAsyncResult>();

            results.Add(myEcho.BeginInvoke("Marco", null, null));
            results.Add(myEcho.BeginInvoke("Daniele", null, null));
            results.Add(myEcho.BeginInvoke("Riccardo", null, null));

            // Recupero dei risultati e stampa sulla console.
            foreach (IAsyncResult result in results)
            {
                Console.WriteLine(myEcho.EndInvoke(result));
            }

            // ************************************************************************************
            // Esempio 6.9
            // ************************************************************************************
            var sample = new MyDelegate<DateTime>(DateTimeWriter);

            // ************************************************************************************
            // Esempio 6.10
            // ************************************************************************************
            var sample1 = new Func<DateTime, string>(DateTimeWriter);

            // ************************************************************************************
            // Esempio 6.11
            // ************************************************************************************
            var foundString1 = strings.Find(
                delegate(string item)
                {
                    return item.StartsWith("a");
                });

            // ************************************************************************************
            // Esempio 6.12
            // ************************************************************************************
            var foundString2 = strings.Find(i => i.StartsWith("a"));

            // ************************************************************************************
            // Esempio 6.13
            // ************************************************************************************
            var searchString = "B";
            var foundString3 = strings.Find(i => i.StartsWith(searchString));
        }

        private static bool FindStringsWithA(string item)
        {
            return item.StartsWith("a");
        }

        private static void ConsoleWriter(DateTime timestamp, string message)
        {
            Console.WriteLine("{0} - {1}", timestamp, message);
        }

        delegate string SampleDelegate(string input);
        public static string VeryLongEchoFunction(string input)
        {
            Thread.Sleep(3000);
            return "Hello " + input;
        }

        public delegate string MyDelegate<T>(T input) where T : struct;

        private static string DateTimeWriter(DateTime input)
        {
            return input.ToShortDateString();
        }

    }
}
