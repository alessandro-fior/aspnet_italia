﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.IO;

namespace WebClient1
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Button1_Click(object sender, RoutedEventArgs e)
    {
      WebClient client = new WebClient();
      string data = new StreamReader(client.OpenRead(new UriBuilder("http", "localhost", 1503, this.TextBox1.Text).Uri)).ReadToEnd();
      this.TextBox2.Text = data;
    }

    private void Button2_Click(object sender, RoutedEventArgs e)
    {
      WebClient client = new WebClient();
      byte[] dataToSend = Encoding.ASCII.GetBytes(this.TextBox2.Text);
      Stream dataStream = client.OpenWrite(string.Format(@"C:\{0}", this.TextBox1.Text));
      StreamWriter str = new StreamWriter(dataStream);
      str.Write(this.TextBox2.Text);
      str.Close();
      dataStream.Close();
    }
  }
}
