﻿using System; // namespace
using static System.Console; // classe statica esempio 4.16

namespace ASPItalia.Books.Chapter4
{
    class Chapter4
    {

    }
}
