﻿using System.Xml;
using System.IO;
using System;

public class Sample3
{
    public static void Run()
    {
        var doc = new XmlDocument();

        // Uri: percorso relativo al file
        doc.Load(Path.Combine(Environment.CurrentDirectory, "test.xml"));

        // Nome del tag e namespace dell'ultimo figlio
        Console.WriteLine($"LocalName: {doc.DocumentElement.LastChild.LocalName} - Namespace: {doc.DocumentElement.LastChild.NamespaceURI}");

        // Attributo idProduct sull'ultimo figlio (tag product)
        var product = (XmlElement)doc.DocumentElement.LastChild;
        Console.WriteLine($"idProduct: {product.Attributes["idProduct"].Value}");
        Console.WriteLine($"idProduct: {product.GetAttribute("idProduct")}");

        // XML del primo figlio di products (il commento)
        Console.WriteLine($"Comment: {doc.DocumentElement.FirstChild.OuterXml}");

        // Tag description del secondo figlio (tag product)
        XmlElement description =
          doc.DocumentElement.ChildNodes[1]["description",
          "http://schemas.aspitalia.com/book40/products"];

        // InnerText interroga direttamente il value dei figli
        Console.WriteLine($"Description: {description.InnerText}");
        // Entro direttamente nel figlio che è un XmlText
        Console.WriteLine($"Description: {description.FirstChild.Value}");

    }

}