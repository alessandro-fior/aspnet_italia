﻿using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlazorConf21.Demo.Library.Services
{
    public class MediaService : IAsyncDisposable
    {
        private IJSRuntime _jsRuntime;
        private IJSObjectReference _module;

        public MediaService(IJSRuntime jsRuntime)
        {
            _jsRuntime = jsRuntime;
        }

        public async Task InitializeAsync()
        {
            _module = await _jsRuntime.InvokeAsync<IJSObjectReference>("import", "./_content/BlazorConf21.Demo.Library/media.js");
        }

        public ValueTask StartVideo(ElementReference videoElement)
        {
            return _module.InvokeVoidAsync("startVideo", videoElement);
        }

        public ValueTask<string> TakeSnapshot(ElementReference videoElement, ElementReference canvasElement)
        {
            return _module.InvokeAsync<string>("takeSnapshot", videoElement, canvasElement);
        }

        public ValueTask DisposeAsync()
        {
            return _module.DisposeAsync();
        }
    }
}
