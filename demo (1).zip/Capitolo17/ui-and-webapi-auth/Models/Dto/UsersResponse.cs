namespace UiAndApiAuth.Models.Dto
{
    public class UsersResponse {
        public string[] Users { get; set; }
    }
}