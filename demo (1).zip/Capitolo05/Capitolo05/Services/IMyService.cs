﻿using Capitolo05.Models;
using System.Collections.Generic;

namespace Capitolo05.Services
{
    public interface IMyService
    {
        IEnumerable<Person> GetPeople();
    }
}
