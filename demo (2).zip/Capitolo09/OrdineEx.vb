﻿Imports Microsoft.VisualBasic

Public Class OrdineEx
    Inherits Ordine
	Public Property IsInternational As Boolean
End Class
