﻿using System;

namespace DemoWebAPI.Models
{
    public class CustomerForCreate
    {
        public string FirstName { get; set; }        
        public string LastName { get; set; }        
        public DateTimeOffset DateOfBirth { get; set; }
    }
}