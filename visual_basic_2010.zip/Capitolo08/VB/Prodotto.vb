﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web

Public Class Prodotto
	Public Property Id As Int32
	Public Property Nome As String
End Class
