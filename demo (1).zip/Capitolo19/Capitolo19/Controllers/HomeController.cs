﻿using Capitolo19.Models;
using Microsoft.AspNetCore.Mvc;

namespace Capitolo19.Controllers
{
	public class HomeController : Controller
	{
		public IActionResult Index()
		{
			var model = new IndexViewModel();
			return View(model);
		}
		public IActionResult Ajax(int userId)
		{
			return Ok();
		}
		public IActionResult JqueryUI()
		{
			return View();
		}
		public IActionResult Vue()
		{
			return View(new VueViewModel { Name = "Stefano" });
		}
	}
}
