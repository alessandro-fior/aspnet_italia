﻿Namespace ASPItalia.Books.Chapter06
    Public Delegate Sub StringLogWriter(
      ByVal timestamp As DateTime, ByVal message As String)

    Public Class Logger
        Private writer As StringLogWriter

        Public Sub New(ByVal writer As StringLogWriter)
            Me.writer = writer
        End Sub

        Public Sub Log(ByVal message As String)
            If Not Me.writer Is Nothing Then
                Me.writer(DateTime.Now, message)
            End If
        End Sub
    End Class
End Namespace
