namespace Capitolo19.Models
{
	public class IndexViewModel
	{
		public string Name { get; set; }
	}
}