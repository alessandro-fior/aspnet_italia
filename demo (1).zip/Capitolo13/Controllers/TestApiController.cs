﻿using System;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace Capitolo13.Controllers
{
    public class TestApiController : Controller
    {
        [HttpGet("api/testerror")]
        public IActionResult TestError()
        {
            throw new ApplicationException("test");
        }

        [HttpGet("api/testnotfound")]
        public IActionResult TestNotFound()
        {
            // Disattivo il middleware per gli status page
            var statusCodePagesFeature = HttpContext.Features.Get<IStatusCodePagesFeature>();
            statusCodePagesFeature.Enabled = false;

            return NotFound();
        }
    }
}
