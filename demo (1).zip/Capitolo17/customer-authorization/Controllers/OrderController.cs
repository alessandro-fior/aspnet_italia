using System;
using System.Linq;
using System.Threading.Tasks;
using CustomerAuthorization.Data;
using CustomerAuthorization.Models;
using CustomerAuthorization.Models.Entities;
using CustomerAuthorization.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CustomerAuthorization.Controllers
{
    [Authorize]
    public class OrderController : Controller
    {
        private readonly ApplicationDbContext ctx;
        private readonly UserManager<ApplicationUser> userManager;
        public OrderController(ApplicationDbContext ctx, UserManager<ApplicationUser> userManager)
        {
            this.ctx = ctx;
            this.userManager = userManager;
        }

        [HttpPost, Authorize(Roles = "Customer")]
        public async Task<IActionResult> Create(OrderViewModel orderModel) {
            if (ModelState.IsValid) {
                var customer = await userManager.FindByNameAsync(User.Identity.Name);
                var order = new Order {
                    Amount = orderModel.Amount,
                    CreatedAt = DateTime.Now,
                    Customer = customer
                };
                ctx.Orders.Add(order);
                await ctx.SaveChangesAsync();
            }
            return RedirectToAction("Detail", "Customer", new { name = User.Identity.Name });
        }

        [HttpPost]
        public async Task<IActionResult> Delete(
          int id,
          [FromServices] IAuthorizationService authService)
        {
            //Usiamo l'orderId che ci viene valorizzato dal Model Binder
            Order order = await ctx.Orders.FindAsync(id);
            var customer = await userManager.FindByIdAsync(order.CustomerId);

            //Autorizziamo fornendo l'utente, la risorsa e la policy
            //In questo esempio, solo chi ha inviato l'ordine può eliminarlo
            AuthorizationResult result = await authService.AuthorizeAsync(User, customer.UserName, "SelfOrAdministrator");
            if (result.Succeeded)
            {
                //L'autorizzazione ha avuto successo, eliminiamo l'ordine
                ctx.Orders.Remove(order);
                await ctx.SaveChangesAsync();
                return RedirectToAction("Detail", "Customer", new { name = customer.UserName });
            } else {
                return RedirectToAction("AccessDenied", "Account");
            }
        }
    }
}