﻿using System;
using System.Threading;

namespace Capitolo8.Scenarios
{
    public static class Scenario2
    {
        /// <summary>
        /// Esempio 8.2
        /// </summary>
        public static void Run()
        {
            string someVariable = "Matteo Tumiati";

            var workerThread = new Thread((o) =>
            {
                Console.WriteLine("Saluti da: {0}", o);
            });

            workerThread.Start(someVariable);
        }
    }
}