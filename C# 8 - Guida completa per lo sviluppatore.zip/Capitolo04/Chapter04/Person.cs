﻿namespace ASPItalia.Books.Chapter4
{
    // Classe astratta che implementa un'interfaccia
    public abstract class Person : IWritable
    {
        // Proprietà
        public string FullName
        {
            get;
            set;
        }

        // Proprietà
        public int Age
        {
            get; set;
        }

        // Costruttore di default
        public Person()
        {
            this.FullName = string.Empty;
            this.Age = 18;
        }

        // Costruttore con parametri
        public Person(string name, int age)
        {
            this.FullName = name;
            this.Age = age;
        }

        // Metodo virtuale
        public virtual string GetFirstName()
        {
            return this.FullName.Split(' ')[0];
        }

        // Metodo astratto (è il metodo definito nell'interfaccia)
        public abstract void Write();

        // Override del metodo ToString di Object
        public override string ToString()
        {
            return FullName;
        }
    }
}
