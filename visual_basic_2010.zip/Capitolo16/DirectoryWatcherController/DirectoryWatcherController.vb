﻿Imports System.ServiceProcess

Module DirectoryWatcherController
    Sub Main()
        Using controller As New ServiceController("Directory Watcher")

            If (controller.Status = ServiceControllerStatus.Running) Then
                controller.Stop()
            End If

            While (controller.Status <> ServiceControllerStatus.Stopped)
                controller.Refresh()
            End While

            controller.Start()

        End Using
    End Sub
End Module
