# Gestione di utenti con la classe UserManager&lt;TUser&gt;
Questa applicazione dimostra l'uso della classe `UserManager<TUser>` per creare e modificare utenti locali.

All'avvio, l'applicazione chiederà di creare un utente amministratore. Questa operazione viene svolta dallo [UserAdministrationController](Controrllers/UserAdministrationController.cs), che si avvale dello `UserManager<TUser>` e del suo metodo `CreateAsync` per creare l'utente. Poi, gli viene assegnato il ruolo di amministratore aggiungendo il relativo claim con il metodo `AddClaimAsync`.
A creazione avvenuta,  viene fatto il login con la classe `SignInManager<TUser>`. 

A questo punto si è autorizzati a visitare la pagina https://localhost:5001/UserAdministration per creare nuovi utenti. In particolare, esaminare il codice dello [UserAdministrationController](Controllers/UserAdministrationController.cs).

La pagina permette di creare un nuovo utente indicando l'email e la password. A creazione avvenuta, è possibile modificare l'utente e associargli dei claim. 

L'aggiornamento della password può avvenire in due passaggi: prima si ottiene un token dal metodo `GeneratePasswordResetTokenAsync` e poi lo si fornisce al metodo `GeneratePasswordResetTokenAsync` a completamento dell'operazione. Il token è una misura di sicurezza che è indispensabile soprattutto quando si vuol inviare un messaggio e-mail all'utente per invitarlo a cambiare la password. Il token viene quindi incluso in un link presente nell'e-mail che l'utente cliccherà per portare a termine la procedura.

In alternativa, possiamo aggiornare la password impostando direttamente la proprietà `PasswordHash` dell'utente, come si vede a riga 129 dello [UserAdministrationController](Controllers/UserAdministrationController.cs). La password, infatti, non viene memorizzata in chiaro nel database e per questo è necessario crearne un hash con il password hasher.
Con il metodo `UpdateAsync` dello user manager, la modifica viene persistita.

## Esercizi
 * Creare un nuovo utente che abbia il claim Role (`http://schemas.microsoft.com/ws/2008/06/identity/claims/role`) impostato su `Administrator`. Fare il login con questo nuovo utente per verificare di avere l'autorizzazione ad accedere alla pagina di gestione degli utenti.
 * Creare un utente e, dalla pagina di modifica, impostarlo come "bloccato". Verificare che ASP.NET Core Identity non gli consente di accedere, nonostante credenziali corrette. Bloccare un utente è utile per sospendere (anche temporaneamente) un utente.