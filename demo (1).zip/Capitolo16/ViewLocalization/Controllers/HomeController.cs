﻿using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using ViewsLocalization.Models.Home;
using System.Globalization;

namespace ViewsLocalization.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Contact(ContactModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            return View("ContactConfirmed", model.Comment);
        }

        public IActionResult SetCulture(string uiCulture)
        {
            IRequestCultureFeature feature = HttpContext.Features.Get<IRequestCultureFeature>();
            RequestCulture requestCulture = new RequestCulture(feature.RequestCulture.Culture, new CultureInfo(uiCulture));

            string cookieValue = CookieRequestCultureProvider.MakeCookieValue(requestCulture);
            string cookieName = CookieRequestCultureProvider.DefaultCookieName;

            Response.Cookies.Append(cookieName, cookieValue);

            return Ok();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
