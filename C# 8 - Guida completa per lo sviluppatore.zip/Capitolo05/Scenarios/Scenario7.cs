﻿using System;
using System.Collections.Generic;

namespace Capitolo5.Scenarios
{
    public static class Scenario7
    {
        /// <summary>
        /// Esempio 5.9
        /// </summary>
        public static void Run()
        {
            // Inizializzazione di List<T> (lista generica di stringhe, in questo caso)
            var strings = new List<string>();
            strings.Add("Matteo Tumiati");
            strings.Add("C# 8");
            strings.Insert(0, "Primo elemento");

            // recupero l'indice dell'elemento "Matteo Tumiati"
            var index = strings.IndexOf("Matteo Tumiati");
            Console.WriteLine($"L'elemento è stato trovato in posizione: {index}");

            // Già string: cast non necessario
            var mySubstring = strings[0].Substring(5); // possiamo effettuare anche operazioni sulle stringhe
            Console.WriteLine(mySubstring);

            // osservare come decommentando la riga successiva
            // viene generato un errore a compile-time, in quanto non è possibile
            // aggiungere ad una lista tipizzata di stringhe oggetti di tipo DateTime
            //strings.Add(DateTime.Now);
        }
    }
}