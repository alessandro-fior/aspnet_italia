﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace DemoSignalR.Hubs
{
    public class StreamingHub : Hub
    {
        public ChannelReader<string> StartStreaming()
        {
            var channel = Channel.CreateUnbounded<string>();

            _ = WriteToChannelAsync(channel.Writer);

            return channel.Reader;

            async Task WriteToChannelAsync(ChannelWriter<string> writer)
            {
                for (var i = 0; ; i++)
                {
                    await writer.WriteAsync($"Messaggio {i}...");
                    await Task.Delay(1000);
                }
            }
        }
    }
}