﻿using Capitolo6.Scenarios;

namespace Capitolo6
{
    class Program
    {
        static void Main(string[] args)
        {
            Scenario9.Run();
        }
    }
}