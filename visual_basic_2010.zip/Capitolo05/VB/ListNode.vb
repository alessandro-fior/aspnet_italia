﻿Namespace ASPItalia.Books.Chapter05

    Public Class ListNode(Of T)

        Public Property Value As T

        Public Property NextNode As ListNode(Of T)

    End Class

End Namespace