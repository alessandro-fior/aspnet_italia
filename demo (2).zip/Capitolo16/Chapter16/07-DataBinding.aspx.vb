﻿Imports System.Web.ModelBinding
Imports Chapter16.Models

Public Class _07_DataBinding
    Inherits System.Web.UI.Page
    Private db As New NorthwindContext()

    Public Function GetCustomers(<QueryString("n")> name As String) As IQueryable(Of Customer)
        Dim customers = db.Customers.AsQueryable()

        If Not String.IsNullOrEmpty(name) Then
            customers = customers.Where(Function(f) f.CompanyName.Contains(name))
        End If

        Return customers
    End Function


    Public Overrides Sub Dispose()

        If db IsNot Nothing Then
            db.Dispose()
        End If

        MyBase.Dispose()
    End Sub
End Class