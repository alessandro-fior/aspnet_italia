﻿Namespace Aspitalia.Books.Chapter4

    ' Interfaccia
    Public Interface IWritable
        Sub Write()
    End Interface

End Namespace

