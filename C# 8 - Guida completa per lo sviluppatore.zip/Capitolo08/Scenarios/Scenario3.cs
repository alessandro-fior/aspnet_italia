﻿using System;
using System.Threading;

namespace Capitolo8.Scenarios
{
    public static class Scenario3
    {
        /// <summary>
        /// Esempio 8.3
        /// </summary>
        public static void Run()
        {
            string someVariable = "Matteo Tumiati";

            var workerThread = new Thread(() =>
            {
                Thread.Sleep(500);
                Console.WriteLine("Saluti da: {0}", someVariable);
            });

            workerThread.Start();

            someVariable = "Daniele Bochicchio";
        }
    }
}