﻿Namespace ASPItalia.Books.Chapter07

    Public Class DisposableObject
        Implements IDisposable

        Protected Overridable Sub Dispose(ByVal disposing As Boolean)
            If disposing Then
                ' qui si liberano le risorse gestite
            End If

            'qui si liberano le risorse non gestite
        End Sub

        Public Sub Dispose() Implements IDisposable.Dispose
            Me.Dispose(True)
            GC.SuppressFinalize(Me)
        End Sub

        Protected Overrides Sub Finalize()
            Me.Dispose(False)
            MyBase.Finalize()
        End Sub

        Public Sub SomeMethod()
            ' Codice del metodo qui
        End Sub

        Public Sub SomeMethod(ByVal items As List(Of Integer))
            If items Is Nothing Then
                ' Si solleva l'eccezione indicando il nome dell'argomento non
                ' correttamente valorizzato
                Throw New ArgumentNullException("items")
            End If

            ' Codice del metodo qui
        End Sub

    End Class

End Namespace