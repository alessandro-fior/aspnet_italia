Imports System

Module Program
	Sub Main(args As String())
		' ****************************************************************************************************
		' Esempio 4.6
		' ****************************************************************************************************
		Dim x As New Person()
		Dim y As New Person("Daniele Bochicchio", 40)

		' ****************************************************************************************************
		' Esempio 4.7
		' ****************************************************************************************************
		Dim y2 As String = y.GetFirstName()        ' y2 vale "Daniele"

		' ****************************************************************************************************
		' Esempio 4.8
		' ****************************************************************************************************
		' Sintassi di creazione con inizializzazione delle propriet�
		Dim x3 As New Person With {.FullName = "Daniele Bochicchio", .Age = 40}

		' Sintassi equivalente: costruttore di default ed inizializzazione
		Dim y3 As New Person()
		y3.FullName = "Daniele Bochicchio"
		y3.Age = 36

		' ****************************************************************************************************
		' Esempio 4.9
		' ****************************************************************************************************
		Dim persons As Person() =
		{
		  New Person With {.FullName = "Cristian Civera", .Age = 34},
		  New Person With {.FullName = "Daniele Bochicchio", .Age = 36}
		}

		' ****************************************************************************************************
		' Esempio 4.11
		' ****************************************************************************************************
		Dim point1 = New With {.X = 21, .Y = 10, .Z = 71}
		Dim point2 = New With {.X = 18, .Y = 8, .Z = 5}

		' La seconda propriet� di point3 � di tipo String
		Dim point3 = New With {.X = 20, .Y = "1", .Z = 67}

		point1 = point2 ' Assegnazione valida (stesso tipo anonimo) 
		point1 = point3 ' Errore (type mismatch)

		' ****************************************************************************************************
		' Esempio 4.12
		' ****************************************************************************************************
		Dim x4 As String = Person.GetFirstName("Stefano Mostarda")

		' ****************************************************************************************************
		' Esempio 4.13
		' ****************************************************************************************************
		Dim i As Integer = Calculator.Sum(18, 8)
		Dim j As Integer = Calculator.Divide(18, 8)

		' ****************************************************************************************************
		' Esempio 4.14
		' ****************************************************************************************************
		Dim Ax As String = Nothing     ' Stringa nulla
		Dim Ay As Boolean = Ax.IsNull() ' Ay vale true

		' ****************************************************************************************************
		' Esempio 4.22
		' ****************************************************************************************************
		' Il riferimento � di tipo IWritable, ma l'istanza � di tipo Employee
		Dim xE As IWritable = New Employee("Alessio Leoncini", 41)

		' Scrive sulla console il nome completo
		xE.Write()

		' � necessario effettuare il casting per invocare il metodo
		Dim yE As String = DirectCast(xE, Employee).GetFirstName()

		' ****************************************************************************************************
		' Esempio 4.23
		' ****************************************************************************************************
		Dim u As New Complex()         ' Il numero complesso vale 0.0 + 0.0i
		Dim v As New Complex(1.0, 2.0) ' Il numero complesso vale 1.0 + 2.0i

		' ****************************************************************************************************
		' Esempio 4.24
		' ****************************************************************************************************
		Dim a As New Complex()         ' vale 0.0 + 0.0i
		Dim b As New Complex(1.0, 2.0) ' vale 1.0 + 2.0i
		Dim c = a + b

		' ****************************************************************************************************
		' Esempio 4.25
		' ****************************************************************************************************
		Dim unnamed = ("a", "b")                    ' valori in .Item1, .Item2
		Dim named = (first:= "a", second:= "b")     ' valori in .first, .second

		Dim Ta = "a"
		Dim Tb = "b"
		Dim Tc = (Ta, Tb)                            ' valori in .a, .b
		Dim d = (e:=Ta, f:=Tb)                       ' valori in .e, .f

	End Sub
End Module
