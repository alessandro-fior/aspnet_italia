﻿using System.Linq;
using System.Xml.XPath;
using System.Xml;
using System;

public class Sample18
{

    public static void Run()
    {

        var doc = new XmlDocument();
        XPathNavigator navigator = doc.CreateNavigator();

        // Creo il tag <products>
        navigator.AppendChildElement("p", "products", "http://schemas.aspitalia.com/book40/products", "");
        navigator.MoveToFirstChild();

        // Creo l'attributo count
        navigator.CreateAttribute("", "count", "", "5");

        Console.WriteLine(doc.OuterXml);
    }

}
