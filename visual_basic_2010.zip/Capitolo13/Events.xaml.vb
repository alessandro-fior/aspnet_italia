﻿Public Class Events

    Private Sub Window_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Input.MouseButtonEventArgs)
        MessageBox.Show("Pulsante premuto su " &
                        e.OriginalSource.GetType().Name)
    End Sub

    Private Sub Window_PreviewMouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Input.MouseButtonEventArgs)
        If e.OriginalSource.GetType() Is GetType(Rectangle) Then
            e.Handled = True
        End If
    End Sub
End Class
