﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Capitolo13.Controllers
{
    public class LoggingController : Controller
    {
        private ILogger<LoggingController> _logger;

        public LoggingController(ILogger<LoggingController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index(string mode, int type)
        {
            _logger.LogInformation("Index with {modeValue} and {typeValue}", mode, type);

            Exception exception = new Exception("test");

            using (_logger.BeginScope("Nuovo scope {mode}", mode))
            {
                _logger.LogTrace("Linea dettagliata con potenziali informazioni sensibili");
                _logger.LogDebug(1001, "Informazioni di debug, utili per diagnostica");
                _logger.LogInformation("Dati generici e descrittivi");
                _logger.LogWarning("Avviso non bloccante");
                _logger.LogError(5001, exception, "Si è verificato un errore, bloccante");
                _logger.LogCritical(exception, "Errore catastrofico, perdita di dati");
            }
            return Ok();
        }
    }
}